/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_UTIL_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_UTIL_H_
#include <chrono>

#include "boost/algorithm/clamp.hpp"
#include "amr_common/amr_enum_type.h"
#include "amr_common/math.h"
#include "amr_navigation/navigation_options.h"

namespace amr_navigation {
constexpr double kNoneAvoidRatio = 1.0;
constexpr double kLevel3AvoidRatio = 0;
constexpr double kDecCNT = 50.0;

/*
 *   calculate the SCurve result
 *   flexible:
 * 代表S曲线区间（越大代表压缩的最厉害，中间（x坐标0点周围）加速度越大；越小越接近匀加速。理想的S曲线的取值为4-6
 */
static double SCurveCalculate(int i, double cycle, double cur, double end,
                              double accdec, double flexible) {
  double deno;
  double melo;
  double len;
  if (std::fabs(cur - end) > 0.5) {
    len = 2 * std::fabs(cur - end) / accdec * cycle;
  } else {
    len = 1 / accdec * cycle;
  }
  melo = flexible * (i - len) / (len);
  deno = cur + ((end - cur) / (1 + expf(-melo)));

  LOG_DEBUG("cur:%f, end:%f, accdec:%f, flexible:%f, len:%f, melo:%f, deno:%f",
            cur, end, accdec, flexible, len, melo, deno);
  return deno;
}

template <typename T>
void SmoothStep(T &from, T to, double delta = 0.01) {
  from += delta;
  if (delta > 0.) {
    if (from >= to) from = to;
  } else {
    if (from <= to) from = to;
  }
}

enum SpeedFormulaType { FROM, DISTANCE, OPTIMAL, MAXSPEED };

/**
 * \class SpeedFormula
 */
template <SpeedFormulaType DISTANCE>
class SpeedFormula {
 public:
  SpeedFormula(double from, double to, double acc)
      : from_(from), to_(to), acc_(acc) {}

  double get() {
    return std::fabs((std::pow(to_, 2) - std::pow(from_, 2)) / acc_ / 2.0);
  }

 private:
  double from_;
  double to_;
  double acc_;
};

template <>
class SpeedFormula<FROM> {
 public:
  SpeedFormula(double to, double acc, double distance)
      : to_(to), acc_(acc), distance_(distance) {}

  double get() {
    float to2 = std::pow(to_, 2) + 2 * acc_ * distance_;
    return to2 >= 0.0 ? std::sqrt(to2) : 0.0;
  }

 private:
  double to_;
  double acc_;
  double distance_;
};

template <>
class SpeedFormula<OPTIMAL> {
 public:
  SpeedFormula(double from, double to, double acc, double dec, double distance)
      : from_(from), to_(to), acc_(acc), dec_(dec), distance_(distance) {}

  double get() {
    float to2 =
        2 * acc_ * dec_ * distance_ / (acc_ + dec_) +
        (dec_ * std::pow(from_, 2) + acc_ * std::pow(to_, 2)) / (acc_ + dec_);
    // float to2 = std::pow(to_, 2) + 2 * dec_ * distance_;
    return to2 >= 0.0 ? std::sqrt(to2) : 0.0;
  }

 private:
  double from_;
  double to_;
  double acc_;
  double dec_;
  double distance_;
};

//计算系统所能达到的最大速度
template <>
class SpeedFormula<MAXSPEED> {
 public:
  SpeedFormula(double from, double to, double accdec, double distance)
      : from_(from), to_(to), accdec_(accdec), distance_(distance) {}

  double get() {
    float max =
        ((std::pow(from_, 2) + std::pow(to_, 2)) - 2 * accdec_ * distance_) / 2;
    return max >= 0.0 ? std::sqrt(max) : 0.0;
  }

 private:
  double from_;
  double to_;
  double accdec_;
  double distance_;
};

template <typename T>
T LinearSmoothEase(T t, T b, T c, T d) {
  return c * (1 - t / d) + (b - c);
}

static double GetAvoidRatio(AvoidRatio option, AvoidLevel avoid_level) {
  static int cnt1, cnt2;
  static double speed_ratio, temp_ratio;
  switch (avoid_level) {
    case AvoidLevel::NONE: {
      cnt1 = 0;
      cnt2 = 0;
      speed_ratio = kNoneAvoidRatio;
      temp_ratio = kNoneAvoidRatio;
      break;
    }
    case AvoidLevel::LEVEL_I: {
      cnt1++;
      cnt1 = cnt1 > kDecCNT ? kDecCNT : cnt1;
      speed_ratio = LinearSmoothEase(
          static_cast<double>(cnt1), kNoneAvoidRatio,
          kNoneAvoidRatio - option.slow_level1_decel_ratio, kDecCNT);
      temp_ratio = speed_ratio;
      break;
    }
    case AvoidLevel::LEVEL_II: {
      cnt2++;
      cnt2 = cnt2 > kDecCNT ? kDecCNT : cnt2;
      speed_ratio = LinearSmoothEase(
          static_cast<double>(cnt2), temp_ratio,
          temp_ratio - option.slow_level2_decel_ratio, kDecCNT);
      break;
    }
    case AvoidLevel::LEVEL_III: {
      cnt1 = 0;
      cnt2 = 0;
      temp_ratio = option.slow_level2_decel_ratio;
      speed_ratio = kLevel3AvoidRatio;
      break;
    }
    default:
      return 0.;
  }
  return speed_ratio;
}

static void AvoidProcess(AvoidRatio option, AvoidLevel avoid_level, double &dec,
                         double &tar_v, double &end_dis) {
  switch (avoid_level) {
    case AvoidLevel::NONE: {
      break;
    }
    case AvoidLevel::LEVEL_I: {
      tar_v *= option.slow_level1_decel_ratio;
      if (tar_v > 0.3) {
        tar_v = 0.3;
      }
      break;
    }
    case AvoidLevel::LEVEL_II: {
      tar_v *= option.slow_level2_decel_ratio;
      if (tar_v > 0.1) {
        tar_v = 0.1;
      }
      break;
    }
    case AvoidLevel::LEVEL_III: {
      tar_v = 0;
      end_dis = 0;
      break;
    }
    default:
      return;
  }
}

static double CalAvoidVel(const AvoidRatio &option,
                          const AvoidLevel &avoid_level, const double &tar_v) {
  switch (avoid_level) {
    case AvoidLevel::NONE: {
      return tar_v;
    }
    case AvoidLevel::LEVEL_I: {
      double v = tar_v * option.slow_level2_decel_ratio;
      return v;
    }
    case AvoidLevel::LEVEL_II: {
      return 0.;
    }
    case AvoidLevel::LEVEL_III: {
      LOG_WARN_THROTTLE(1, "[AvoidLevel::LEVEL_III]");
      return 0.;
    }
    default: {
      return tar_v;
    }
  }
}

static double CalMaxVel(const AvoidRatio &option, const AvoidLevel &avoid_level,
                        const double &max_v) {
  switch (avoid_level) {
    case AvoidLevel::NONE: {
      return max_v;
    }
    case AvoidLevel::LEVEL_I: {
      double v = max_v * option.slow_level1_decel_ratio;
      return v;
    }
    case AvoidLevel::LEVEL_II: {
      double v = max_v * option.slow_level2_decel_ratio;
      return v;
    }
    case AvoidLevel::LEVEL_III: {
      return 0.;
    }
    default: {
      return 0.;
    }
  }
}

static double GetFreeLinearSpeed(double cur, double tar, double max,
                                 double last, double dist,
                                 const VelocityParamer &option,
                                 const float &controller_frequency) {
  double time_cycle = 1. / controller_frequency;
  double min_v = option.min_v;
  double max_v = std::min(option.max_v, max);

  if (std::abs(min_v) > std::abs(max_v)) {
    min_v = max_v;
  }

  if (cur * dist > 0 && cur * math::Sign(dist) * tar < 0) {
    LOG_ERROR(
        "No speed strategy can handle this situation. (from: %f, to: %f, "
        "distance: %f)",
        cur, tar, dist);
    return 0.0;
  }

  // 接近停止点 低速行驶
  if (std::fabs(dist) < option.margin && tar == 0.) {
    auto final_v =
        math::Sign(dist) * math::Clamp(std::fabs(dist) * 0.3, min_v, 0.1);
    return final_v;
  }
  // 平滑驶入低速点
  dist = tar == 0. ? dist - math::Sign(dist) * option.margin : dist;
  tar = tar == 0. ? std::fabs(option.margin) * 0.3 : tar;

  if (SpeedFormula<OPTIMAL>(std::fabs(cur), std::fabs(tar), option.acceleration,
                            option.deceleration, std::fabs(dist))
          .get() <= (std::fabs(cur))) {
    // T Curve decelerate
    double ret =
        math::Sign(dist) *
        math::Clamp(
            SpeedFormula<FROM>(tar, option.deceleration, std::fabs(dist)).get(),
            std::fabs(min_v), std::fabs(last));
    LOG_DEBUG("dist:%f, cur:%f, tar:%f, set:%f, dec:%f", dist, cur, tar, ret,
              option.deceleration);

    // TODO(@ssh) 与上次速度做均值滤波处理
    return (std::fabs(last) - std::fabs(ret)) > 0.1 ? (last + ret) / 2 : ret;
  } else {
    // T Curve acceleration
    auto v =
        math::Clamp(std::fabs(cur) + 2.5 * option.acceleration * time_cycle,
                    std::fabs(min_v), std::fabs(max_v));
    auto optimal_v = math::Clamp(
        SpeedFormula<OPTIMAL>(std::fabs(cur), std::fabs(tar),
                              option.acceleration, option.deceleration,
                              std::fabs(dist))
            .get(),
        std::fabs(3 * min_v) /*叉车起步需要较大速度*/, std::fabs(max_v));
    auto final_v = math::Sign(dist) * std::min(v, optimal_v);
    return final_v;
  }
}

// TODO(@ssh) 物流版本 倒车卸货不能起步太快
static double GetFreeLinearSpeed1(double cur, double tar, double max,
                                  double last, double dist,
                                  const VelocityParamer &option,
                                  const float &controller_frequency) {
  double time_cycle = 1. / controller_frequency;
  double min_v = option.min_v;
  double max_v = std::min(option.max_v, max);

  if (std::abs(min_v) > std::abs(max_v)) {
    min_v = max_v;
  }

  if (cur * dist > 0 && cur * math::Sign(dist) * tar < 0) {
    LOG_ERROR(
        "No speed strategy can handle this situation. (from: %f, to: %f, "
        "distance: %f)",
        cur, tar, dist);
    return 0.0;
  }

  // 接近停止点 低速行驶
  if (std::fabs(dist) < option.margin && tar == 0.) {
    auto final_v =
        math::Sign(dist) * math::Clamp(std::fabs(dist) * 0.3, min_v, 0.1);
    return final_v;
  }
  // 平滑驶入低速点
  dist = tar == 0. ? dist - math::Sign(dist) * option.margin : dist;
  tar = tar == 0. ? std::fabs(option.margin) * 0.3 : tar;

  if (SpeedFormula<OPTIMAL>(std::fabs(cur), std::fabs(tar), option.acceleration,
                            option.deceleration, std::fabs(dist))
          .get() <= (std::fabs(cur))) {
    // T Curve decelerate
    double ret =
        math::Sign(dist) *
        math::Clamp(
            SpeedFormula<FROM>(tar, option.deceleration, std::fabs(dist)).get(),
            std::fabs(min_v), std::fabs(last));
    LOG_DEBUG("dist:%f, cur:%f, tar:%f, set:%f, dec:%f", dist, cur, tar, ret,
              option.deceleration);

    // TODO(@ssh) 与上次速度做均值滤波处理
    return (std::fabs(last) - std::fabs(ret)) > 0.1 ? (last + ret) / 2 : ret;
  } else {
    // T Curve acceleration
    auto v = math::Clamp(std::fabs(cur) + option.acceleration * time_cycle,
                         std::fabs(min_v), std::fabs(max_v));
    auto optimal_v =
        math::Clamp(SpeedFormula<OPTIMAL>(std::fabs(cur), std::fabs(tar),
                                          option.acceleration,
                                          option.deceleration, std::fabs(dist))
                        .get(),
                    std::fabs(min_v), std::fabs(max_v));
    auto final_v = math::Sign(dist) * std::min(v, optimal_v);
    return final_v;
  }
}

/*
param:
cur:当前速度
set:规划速度
dist:剩余距离
option:参数(加减速)
controller_frequency:控制频率

return:
修正速度值
*/
static double InertialCorrect(const double cur, const double set,
                              const double dist, const VelocityParamer &option,
                              const float &controller_frequency) {
  double K1 = 0.35;
  double K2 = 10;
  // double acc_pre = -K1 * std::fabs(dist) - K2 * (set - cur);
  double acc_pre = K2 * (set - cur);

  return set + acc_pre / controller_frequency;
}

static double GetQrLinearSpeed(double cur, double tar, double max, double last,
                               double dist, const VelocityParamer &option,
                               const float &controller_frequency,
                               AvoidLevel avoid_level, bool &rst) {
  static int acc_num = 0;
  static int dec_num = 0;
  static double last_tar_v = 0.f;
  static double last_set_v = 0.f;
  static int last_dist_sign = 0;
  static int atonce_dec = 0;
  static int avoid_atonce_dec = 0;

  static std::deque<double> last_v;
  double time_cycle = 1. / controller_frequency;
  if (rst) {
    rst = false;
    dec_num = 0;
    acc_num = 0;
    atonce_dec = 0;
    avoid_atonce_dec = 0;
    last_set_v = 0.f;
    last_tar_v = 0.f;
    last_dist_sign = 0;
    last_v.clear();
  }

  if (!math::NearZero(last_tar_v - tar)) {
    atonce_dec = 0;
  }

  double min_v = option.min_v;
  double max_v = std::min(option.max_v, max);

  if (std::fabs(min_v) > std::fabs(max_v)) {
    min_v = max_v;
  }
  if (std::fabs(last_tar_v) != std::fabs(tar) ||
      last_dist_sign != math::Sign(dist)) {
    dec_num = 0;
    acc_num = 0;
  }

  if (cur * dist > 0 && cur * math::Sign(dist) * tar < 0) {
    acc_num = 0;
    dec_num = 0;
    LOG_ERROR(
        "No speed strategy can handle this situation. (from: %f, to: %f, "
        "distance: %f)",
        cur, tar, dist);
    last_set_v = 0.f;
    last_tar_v = tar;
    atonce_dec = 0;
    avoid_atonce_dec = 0;
    last_dist_sign = math::Sign(dist);
    return 0.0;
  }

  double ret;
  // DEC At Once 提前0.15的速度减速
  double delta_v = 0.;
  if (std::fabs(cur) > 0.7) {
    delta_v = 0.05;
  } else {
    delta_v = 0.01;
  }
  if (((SpeedFormula<OPTIMAL>(std::fabs(cur), 0, option.acceleration,
                              option.deceleration, std::fabs(dist))
            .get() -
        delta_v) <= std::fabs(cur) &&
       math::NearZero(tar)) ||
      ((std::fabs(dist) < 0.01) && avoid_level == AvoidLevel::NONE) ||
      atonce_dec) {
    acc_num = 0;
    dec_num = 0;
    static double start_dec_v = 0.f;
    static int s_dec_num = 0;
    if (atonce_dec == 0) {
      start_dec_v = last_set_v;
    }

    if (start_dec_v > 1.0) {
      s_dec_num = 35;
    } else if (start_dec_v > 0.8) {
      s_dec_num = 30;
    } else if (start_dec_v > 0.5) {
      s_dec_num = 25;
    } else {
      s_dec_num = 20;
    }

    if (std::fabs(last_set_v -
                  SpeedFormula<FROM>(tar, option.deceleration, std::fabs(dist))
                      .get()) < 0.1) {
      s_dec_num = 0;
    }
    // 三级避障
    if (math::NearZero(tar) && math::NearZero(dist)) {
      atonce_dec = 0;
      ret = 0.f;
    }
    //前20个周期，s型减速过度
    else if (atonce_dec < s_dec_num) {
      ret = math::Sign(dist) * SCurveCalculate(atonce_dec, controller_frequency,
                                               std::fabs(start_dec_v), 0,
                                               std::fabs(option.acceleration),
                                               std::fabs(option.s_curve_flex));
      LOG_DEBUG_THROTTLE(0.2,
                         "[DEC At Once---S Dec](atonce_dec:%d)dist:%f, cur:%f, "
                         "tar:%f, set:%f, "
                         "last_set_v:%f,start_dec_v:%f",
                         atonce_dec, dist, cur, tar, ret, last_set_v,
                         start_dec_v);
      atonce_dec++;
    } else {
      ret = math::Sign(dist) *
            math::Clamp(
                SpeedFormula<FROM>(tar, option.deceleration, std::fabs(dist))
                    .get(),
                std::fabs(min_v), std::fabs(option.max_v));
      LOG_DEBUG_THROTTLE(0.01,
                         "T Curve tar:%f, deceleration:%f, dist:%f, ret:%f",
                         tar, option.deceleration, dist, ret);
    }

    double ret_pre =
        InertialCorrect(cur, ret, dist, option, controller_frequency);
    // ret = ret_pre;
    if (last_v.size() > 0) {
      if (std::fabs(last_v.back() - ret) > 0.04) {
        double sum = ret;
        for (int i = 0; i < last_v.size(); i++) {
          sum += last_v.at(i);
        }
        ret = sum / (last_v.size() + 1);
      }
    }

    // 减速时，速度不能大于于上一次值，
    if (std::fabs(ret) > std::fabs(last_set_v) &&
        math::Sign(ret) == math::Sign(last_set_v)) {
      //上一次规划速度>0.4时
      if (std::fabs(last_set_v) > 0.4) {
        ret = math::Sign(last_set_v) *
              (std::fabs(last_set_v) - option.deceleration * time_cycle / 2);
      } else if (std::fabs(last_set_v) > 0.1) {
        ret = math::Sign(last_set_v) *
              (std::fabs(last_set_v) - option.deceleration * time_cycle / 5);
      }
    }
    //目标距离<0.01时，特殊处理
    if (std::fabs(dist) < 0.005) {
      ret = dist * 4;
    } else if (std::fabs(dist) < 0.002) {
      ret = dist * 2;
    }

    LOG_DEBUG_THROTTLE(0.2,
                       "[DEC At Once]dist:%f, cur:%f, tar:%f, set:%f, "
                       "ret_pre:%f, last_set_v:%f",
                       dist, cur, tar, ret, ret_pre, last_set_v);
  } else {
    // DEC:
    // 当前速度>当前路段最大速度
    // 当前速度>目标速度(目标速度不等于最后一段路径tar恒等于0)
    if (std::fabs(cur) > std::fabs(max_v) ||
        (std::fabs(cur) > std::fabs(tar) && !math::NearZero(tar))) {
      acc_num = 0;
#if 0
      // T Curve dec
      ret = math::Sign(dist) *
                   (std::fabs(cur) - option.deceleration * time_cycle);
      ROS_DEBUG("[T Curve dec]last:%f, ret:%f", last, ret);
#else

      static double start_dec_v1 = 0.f;
      if (dec_num == 0) {
        start_dec_v1 = last_set_v;
      }
      // 前30个周期一定s型过渡
      // S Curve dec --
      // 使用加速度作为减速度（避障时减速度加倍）---速度较快时避障传感器相应变慢
      double dec = (avoid_level != AvoidLevel::NONE) ? (option.acceleration * 2)
                                                     : option.acceleration;

      ret = math::Sign(dist) * SCurveCalculate(dec_num, controller_frequency,
                                               std::fabs(start_dec_v1),
                                               std::fabs(tar), std::fabs(dec),
                                               std::fabs(option.s_curve_flex));
      double avoid_v = ret;
      if (dec_num > 30 && avoid_level != AvoidLevel::NONE) {
        //避障时 需要在指定剩余距离减到tar速度--
        if (SpeedFormula<OPTIMAL>(std::fabs(last_set_v), std::fabs(tar),
                                  option.acceleration, option.deceleration,
                                  std::fabs(dist))
                .get() <= std::fabs(cur)) {
          avoid_v =
              SpeedFormula<FROM>(tar, option.deceleration, std::fabs(dist))
                  .get();
        }

        ret = math::Sign(dist) * std::min(std::fabs(ret), std::fabs(avoid_v));
      }
#endif
      if (last_v.size() > 0) {
        if (std::fabs(last_v.back() - ret) > 0.1) {
          double sum = ret;
          for (int i = 0; i < last_v.size(); i++) {
            sum += last_v.at(i);
          }
          ret = sum / (last_v.size() + 1);
        }
      }

      // 减速时，速度不能大于于上一次值
      if (std::fabs(ret) > std::fabs(last_set_v) && std::fabs(ret) > 0.2) {
        ret = last_set_v;
      }
      LOG_DEBUG_THROTTLE(
          0.2,
          "[S Curve dec]:%d, dist:%f, tar:%f(%f), cur:%f, ret:%f, "
          "last_set_v:%f, start_dec_v1:%f",
          dec_num, dist, tar, max_v, cur, ret, last_set_v, start_dec_v1);
      dec_num++;
      last_set_v = ret;
    } else {
      // ACC
      dec_num = 0;
#if 0
    // T Curve ACC
    auto v = math::Clamp(std::fabs(cur) + option.acceleration * time_cycle,
                         std::fabs(min_v), std::fabs(max_v));
    if (math::Nearby(cur, 0.f, 0.3)) {
      v = math::Clamp(std::fabs(cur) + option.acceleration * time_cycle / 3.f,
                      std::fabs(min_v), std::fabs(max_v));
    }
#else

      static double start_acc_v = 0.f;
      if (acc_num == 0) {
        start_acc_v = last_set_v;
      }
      // S Curve ACC
      ret = math::Clamp(
          SCurveCalculate(acc_num, controller_frequency, std::fabs(start_acc_v),
                          std::fabs(math::NearZero(tar) ? max : tar),
                          std::fabs(option.acceleration),
                          std::fabs(option.s_curve_flex)),
          std::fabs(min_v), std::fabs(max_v));
#endif
      ret = math::Sign(dist) * ret;
      if (last_v.size() > 0) {
        if (std::fabs(last_v.back() - ret) > 0.1) {
          double sum = ret;
          for (int i = 0; i < last_v.size(); i++) {
            sum += last_v.at(i);
          }
          ret = sum / (last_v.size() + 1);
        }
      }
      // 加速时，速度不能小于上一次值
      if (std::fabs(ret) < std::fabs(last_set_v)) {
        ret = last_set_v;
      }
      LOG_DEBUG_THROTTLE(0.2,
                         "[S Curve ACC]%d, dist:%f, tar:%f(%f), cur:%f, ret:%f,"
                         "last_set_v:%f, start_acc_v:%f",
                         acc_num, dist, tar, max_v, cur, ret, last_set_v,
                         start_acc_v);

      acc_num++;
    }
  }

  last_tar_v = tar;
  last_dist_sign = math::Sign(dist);
  last_v.push_back(ret);
  if (last_v.size() > 2) {
    last_v.pop_front();
  }
  last_set_v = ret;
  return ret;
}

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_UTIL_H_
