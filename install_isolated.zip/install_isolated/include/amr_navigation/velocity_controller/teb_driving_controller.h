/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_TEB_DRIVING_CONTROLLER_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_TEB_DRIVING_CONTROLLER_H_

#include "amr_navigation/velocity_controller/velocity_controller_interface.h"

// 避免PI宏定义冲突
#undef PI

#include <actionlib/client/simple_action_client.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <costmap_2d/costmap_2d_ros.h>
#include <tf2_ros/buffer.h>
#include <tf2/utils.h>
#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Twist.h>

namespace amr_navigation {
using Client = actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction>;
using Goal  = move_base_msgs::MoveBaseGoal;
using State = actionlib::SimpleClientGoalState;
class TebDrivingController : public VelocityControllerInterface {
 public:
  TebDrivingController();
  ~TebDrivingController() = default;

  void Init(const NavigationOption &option) override;
  
  void Reset(const std::shared_ptr<StateManager> state,
             const std::shared_ptr<GoalManager> goal) override;

  // 规划偏差, 规划剩余路径
  void UpdateProcess(const std::shared_ptr<StateManager> state,
                     const std::shared_ptr<GoalManager> goal) override;

  // 到达判断
  bool Arrived(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal) override;

  // 出轨判断
  bool OffTheTrack(const std::shared_ptr<StateManager> state,
                   const std::shared_ptr<GoalManager> goal) override;

  // 错误判断
  bool IsError(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal) override;

  // 使用TEB算法计算 v, w
  amr_msgs::move_cmd GetVelocity(const std::shared_ptr<StateManager> state,
                                 const std::shared_ptr<GoalManager> goal) override;

 private:
  // TEB相关参数和状态变量
  double x_distance_to_end_;
  MotionType motion_type_;
  

  
  // TEB内部状态
  bool teb_initialized_;
  ros::Time last_update_time_;

  
  // TF缓冲区
  tf2_ros::Buffer* tf_buffer_;
  tf2_ros::TransformListener* listener_;
  // 代价地图
  costmap_2d::Costmap2DROS* costmap_ros_;
  
  // TEB算法相关辅助函数
  bool InitializeTebPlanner(const std::shared_ptr<StateManager> state,
                            const std::shared_ptr<GoalManager> goal);
  
  bool PlanTrajectory(const std::shared_ptr<StateManager> state,
                      const std::shared_ptr<GoalManager> goal,
                      amr_msgs::move_cmd& cmd);
  
  bool CheckTebFeasibility(const std::shared_ptr<StateManager> state,
                           const std::shared_ptr<GoalManager> goal);
  
    std::shared_ptr<Client> ac_ptr;
    // 异步结果回调：真正到达/失败时会进这里
    void doneCb(const State& state,
                const move_base_msgs::MoveBaseResultConstPtr& result)
    {
        ROS_INFO(">>> move_base DONE! state = %s", state.toString().c_str());
        // 根据 state 做后续业务
        if (state == State::SUCCEEDED)
            ROS_INFO("Goal reached successfully!");
        else
            ROS_WARN("Goal failed! state = %s", state.toString().c_str());
    }

    // 可选：反馈回调，可打印剩余距离等
    void feedbackCb(const move_base_msgs::MoveBaseFeedbackConstPtr& fb)
    {
        // fb->base_position 是当前机器人位姿
        // 这里仅演示打印一次，可按需计算到目标距离
        static int cnt = 0;
        if (++cnt % 50 == 0)  // 降低打印频率
            ROS_INFO("feedback: robot at (%.2f, %.2f)",
                    fb->base_position.pose.position.x,
                    fb->base_position.pose.position.y);
    }

    // 活跃回调（目标被服务器接受瞬间）
    void activeCb()
    {
        ROS_INFO("Goal just went active!");
    }
};

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_TEB_DRIVING_CONTROLLER_H_