/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_STRAIGHT_STABLIZER_CONTROLLER_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_STRAIGHT_STABLIZER_CONTROLLER_H_

#include "amr_common/amr_topic_name.h"
#include "amr_msgs/request_pallet_center.h"
#include "amr_navigation/velocity_controller/velocity_controller_interface.h"
namespace amr_navigation {

enum PscSubGoalState {
  NONE = 0,
  FIRST_GOAL = 1,
  SECOND_GOAL = 2,
  THIRD_GOAL = 3
};
class PscSubGoal {
 public:
  PscSubGoal() : vaild_(false), dist_(0.) {}
  ~PscSubGoal() {}

  bool GenerateSubGoal(const NavigationOption& option, const Pose& current_pose,
                       const Pose& start_pose, const Pose& pallet_pose,
                       const Pose& orign_end_pose, const Pose& end_pose);

  bool GenerateSubGoal(const NavigationOption& option, const Pose& start_pose,
                       const Pose& end_pose);

  bool IsGoalVaild() const { return vaild_; }

  bool Arrived(const Pose& current_pose);

  NavigationDeviation GetDeviation(const Pose& current_pose);
  Pose GetGoalPose(const Pose& current_pose);

  PscSubGoalState GetGoalState();

  void Reset();

  double GetDistance(const Pose& current_pose) { return dist_; }

  Pose GetEndPose() { return end_pose_; }

 private:
  double ComputeCurvePoseScore(const Pose& middle_pose, const Pose& start_pose);
  Pose GenerateCurvePose(const Pose& start_pose, const Pose& pallet_pose);

  std::vector<Pose> GenerateCurveControlPoints(const Pose& start_pose,
                                               const Pose& end_pose);

  std::shared_ptr<PathInterface> first_path_interface_;  // 第一段路径 直线
  std::shared_ptr<PathInterface> second_path_interface_;  // 第二段路径 曲线
  std::shared_ptr<PathInterface> third_path_interface_;  // 第二段路径 直线

  Pose start_pose_;
  Pose curve_pose_;
  Pose pallet_pose_;
  Pose goal_start_pose_;
  Pose goal_end_pose_;
  Pose end_pose_;
  bool first_goal_finished_;
  bool second_goal_finished_;
  bool third_goal_finished_;
  double dist_;

  bool vaild_;
};

class StraightStablierController : public VelocityControllerInterface {
 public:
  StraightStablierController() : x_distance_to_end_(0.), init_(false) {}
  ~StraightStablierController() = default;

  // 规划偏差, 规划剩余路经
  void UpdateProcess(const std::shared_ptr<StateManager> state,
                     const std::shared_ptr<GoalManager> goal);

  // 到达判断
  bool Arrived(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);

  // 出轨判断
  bool OffTheTrack(const std::shared_ptr<StateManager> state,
                   const std::shared_ptr<GoalManager> goal);

  // 错误判断
  bool IsError(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);

  // 计算 v, w
  amr_msgs::move_cmd GetVelocity(const std::shared_ptr<StateManager> state,
                                   const std::shared_ptr<GoalManager> goal);

  void Reset(const std::shared_ptr<StateManager> state,
             const std::shared_ptr<GoalManager> goal) override;

 private:
  Pose ExtendPose(const Pose& pose, double extend_dist);
  double GetOmega(const double& dy, const double& dw1, const double& dw2,
                  const double& v, const double& last_cmd_w,
                  const PathDeviationGain& option);

  MotionType motion_type_;
  double x_distance_to_end_;
  Pose start_pose_;
  Pose pallet_pose_;
  Pose goal_end_pose_;
  Pose end_pose_;
  bool init_;

  PscSubGoal psc_goal_;
};

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_STRAIGHT_STABLIZER_CONTROLLER_H_