/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_VELOCITY_CONTROLLER_VELOCITY_CONTROLLER_FACTORY_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_VELOCITY_CONTROLLER_VELOCITY_CONTROLLER_FACTORY_H_

#include "amr_common/util/factory.h"
#include "amr_common/util/singleton.h"
#include "amr_navigation/navigation_enum.h"
#include "amr_navigation/velocity_controller/bcurve_stablizer_controller.h"
#include "amr_navigation/velocity_controller/car_back_controller.h"
#include "amr_navigation/velocity_controller/charge_controller.h"
#include "amr_navigation/velocity_controller/docking_controller.h"
#include "amr_navigation/velocity_controller/driving_controller.h"
#include "amr_navigation/velocity_controller/fork_pallet_stablizer_controller.h"
#include "amr_navigation/velocity_controller/free_driving_controller.h"
#include "amr_navigation/velocity_controller/lat_driving_controller.h"
#include "amr_navigation/velocity_controller/qr_controller.h"
#include "amr_navigation/velocity_controller/roatate_controller.h"
#include "amr_navigation/velocity_controller/fork_roatate_controller.h"
#include "amr_navigation/velocity_controller/shaking_controller.h"
#include "amr_navigation/velocity_controller/stabilize_down_controller.h"
#include "amr_navigation/velocity_controller/stabilize_down_norotate_controller.h"
#include "amr_navigation/velocity_controller/stabilize_up_controller.h"
#include "amr_navigation/velocity_controller/straight_stablizer_controller.h"
#include "amr_navigation/velocity_controller/jackup_straight_stablizer_controller.h"
#include "amr_navigation/velocity_controller/prestablizer_controller.h"
#include "amr_navigation/velocity_controller/track_column_controller.h"
#include "amr_navigation/velocity_controller/forbid_un_load_controller.h"
#include "amr_navigation/velocity_controller/velocity_controller_interface.h"
#include "amr_navigation/velocity_controller/teb_driving_controller.h"

namespace amr_navigation {
class VelocityControllerFactory
    : public util::Factory<VelocityControllerType,
                           VelocityControllerInterface> {
 public:
  void RegisterVelocityControllers();

  std::unique_ptr<VelocityControllerInterface> CreateVelocityController(
      const VelocityControllerType& type, const NavigationOption& option);

 private:
  DECLARE_SINGLETON(VelocityControllerFactory)
  VelocityControllerFactory() {}
};
}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_VELOCITY_CONTROLLER_VELOCITY_CONTROLLER_FACTORY_H_