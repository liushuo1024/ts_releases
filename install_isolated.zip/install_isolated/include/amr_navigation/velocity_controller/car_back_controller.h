/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_CAR_BACK_CONTROLLER_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_CAR_BACK_CONTROLLER_H_

#include "amr_navigation/velocity_controller/velocity_controller_interface.h"

namespace amr_navigation {

class CarBackController : public VelocityControllerInterface {
 public:
  CarBackController()
      : x_distance_to_end_(0.), rotate_finish_(false), rst_(true) {}
  ~CarBackController() = default;

  void Reset() { rotate_finish_ = false; }
  // 规划偏差, 规划剩余路经
  void UpdateProcess(const std::shared_ptr<StateManager> state,
                     const std::shared_ptr<GoalManager> goal);

  // 到达判断
  bool Arrived(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);
  // 出轨判断
  bool OffTheTrack(const std::shared_ptr<StateManager> state,
                   const std::shared_ptr<GoalManager> goal);

  // 错误判断
  bool IsError(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);

  // 计算 v, w
  amr_msgs::move_cmd GetVelocity(const std::shared_ptr<StateManager> state,
                                   const std::shared_ptr<GoalManager> goal);

  double GetStraightLineOmega(double dy, double dw, double v);

  double GetDeltaY(const Pose& current_pose);

  double GetYawBias(const Pose& current_pose);

 private:
  double x_distance_to_end_;
  double dist_;
  Pose start_pose_;
  Pose end_pose_;
  bool rotate_finish_;
  bool rst_;
};

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_STABLILIZE_UP_CONTROLLER_H_
