/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_SHAKING_CONTROLLER_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_SHAKING_CONTROLLER_H_

#include "amr_navigation/velocity_controller/velocity_controller_interface.h"
#include "tf/tf.h"

namespace amr_navigation {
class ShakingVelocityController : public VelocityControllerInterface {
 public:
  ShakingVelocityController() : init_start_(ros::Time::now()), init_cnt_(0) {}
  ~ShakingVelocityController() = default;

  // 规划偏差, 规划剩余路经
  void UpdateProcess(const std::shared_ptr<StateManager> state,
                     const std::shared_ptr<GoalManager> goal);

  // 到达判断
  bool Arrived(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);
  // 出轨判断
  bool OffTheTrack(const std::shared_ptr<StateManager> state,
                   const std::shared_ptr<GoalManager> goal);

  // 错误判断
  bool IsError(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);

  void Reset(const std::shared_ptr<StateManager> state,
                             const std::shared_ptr<GoalManager> goal) { init_cnt_ = 0; }

  // 计算 v, w
  amr_msgs::move_cmd GetVelocity(const std::shared_ptr<StateManager> state,
                                   const std::shared_ptr<GoalManager> goal);

 private:
  int init_cnt_;
  ros::Time init_start_;
};
}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_SHAKING_CONTROLLER_H_