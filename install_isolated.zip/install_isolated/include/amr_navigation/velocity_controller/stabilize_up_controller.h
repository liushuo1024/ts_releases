/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_STABLILIZE_UP_CONTROLLER_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_STABLILIZE_UP_CONTROLLER_H_

#include "amr_common/amr_topic_name.h"
#include "amr_msgs/adjust_up.h"
#include "amr_navigation/velocity_controller/velocity_controller_interface.h"
namespace amr_navigation {

class StabilizeUpVelocityController : public VelocityControllerInterface {
 public:
  StabilizeUpVelocityController()
      : dis_(0.), rst_(true), stabilize_cnt_(0), first_in_(true) {
    ros::NodeHandle nh1;
    stabilize_pub_ =
        nh1.advertise<amr_msgs::adjust_up>(amr_topic::kAdjustUpTopic, 10);
  }
  ~StabilizeUpVelocityController() = default;

  void Reset(const std::shared_ptr<StateManager> state,
                             const std::shared_ptr<GoalManager> goal){};
  // 规划偏差, 规划剩余路经
  void UpdateProcess(const std::shared_ptr<StateManager> state,
                     const std::shared_ptr<GoalManager> goal);

  // 到达判断
  bool Arrived(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);
  // 出轨判断
  bool OffTheTrack(const std::shared_ptr<StateManager> state,
                   const std::shared_ptr<GoalManager> goal);

  // 错误判断
  bool IsError(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);

  // 计算 v, w
  amr_msgs::move_cmd GetVelocity(const std::shared_ptr<StateManager> state,
                                   const std::shared_ptr<GoalManager> goal);

  double GetYawBias(const double& agv_yaw, const double& shelf_yaw);

  double NearestShelfAngle(const double& end_yaw, const double& shelf_yaw);

 private:
  double dif_yaw_;
  double x_rela_;
  double y_rela_;
  double dis_;
  bool rst_;
  int stabilize_cnt_;
  ros::Publisher stabilize_pub_;

  // 增加整定超时处理
  ros::Time start_time_;
  bool first_in_;
};

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_STABLILIZE_UP_CONTROLLER_H_
