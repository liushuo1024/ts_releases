
/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_DOCKING_CONTROLLER_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_DOCKING_CONTROLLER_H_

#include <algorithm>
#include <memory>

#include "amr_common/amr_enum_type.h"
#include "amr_navigation/velocity_controller/velocity_controller_interface.h"

namespace amr_navigation {

class DockingVelocityController : public VelocityControllerInterface {
 public:
  DockingVelocityController()
      : is_on_qr_tag_(false),
        docking_step_(DockState::FRONTING),
        first_in_(true) {}
  ~DockingVelocityController() = default;

  // 规划偏差, 规划剩余路经
  void UpdateProcess(const std::shared_ptr<StateManager> state,
                     const std::shared_ptr<GoalManager> goal);

  // 到达判断
  bool Arrived(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);
  // 出轨判断
  bool OffTheTrack(const std::shared_ptr<StateManager> state,
                   const std::shared_ptr<GoalManager> goal);

  // 错误判断
  bool IsError(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);

  // 计算 v, w
  amr_msgs::move_cmd GetVelocity(const std::shared_ptr<StateManager> state,
                                   const std::shared_ptr<GoalManager> goal);

 private:
  bool is_on_qr_tag_;
  DockState docking_step_;
  ros::Time start_time_;
  bool first_in_;
};

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_DOCKING_CONTROL_H_
