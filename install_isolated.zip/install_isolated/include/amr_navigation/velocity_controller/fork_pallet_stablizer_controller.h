/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_FORK_PALLET_STABLIZER_CONTROLLER_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_FORK_PALLET_STABLIZER_CONTROLLER_H_

#include "amr_navigation/velocity_controller/velocity_controller_interface.h"
namespace amr_navigation {

class ForkPalletStablizerController : public VelocityControllerInterface {
 public:
  ForkPalletStablizerController() : x_distance_to_end_(0.), is_init_(false) {}
  ~ForkPalletStablizerController() = default;

  // 规划偏差, 规划剩余路经
  void UpdateProcess(const std::shared_ptr<StateManager> state,
                     const std::shared_ptr<GoalManager> goal);

  // 到达判断
  bool Arrived(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);

  // 出轨判断
  bool OffTheTrack(const std::shared_ptr<StateManager> state,
                   const std::shared_ptr<GoalManager> goal);

  // 错误判断
  bool IsError(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);

  // 计算 v, w
  amr_msgs::move_cmd GetVelocity(const std::shared_ptr<StateManager> state,
                                   const std::shared_ptr<GoalManager> goal);

  void Reset(const std::shared_ptr<StateManager> state,
             const std::shared_ptr<GoalManager> goal) {
    is_init_ = false;
  }

 private:
  double GetDeltaY(const Pose& current_pose);
  double GetYawBias(const Pose& current_pose);
  double GetYawBias2(const Pose& current_pose);

  double GetOmega(const double& dy, const double& dw1, const double& dw2,
                  const double& v, const double& last_cmd_w,
                  const PathDeviationGain& option);
  MotionType motion_type_;
  double x_distance_to_end_;
  Pose final_pose_;
  Pose start_pose_;
  bool is_init_;
};

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_FORK_PALLET_STABLIZER_CONTROLLER_H_