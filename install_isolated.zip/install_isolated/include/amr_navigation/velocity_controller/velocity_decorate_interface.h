/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_VELOCITY_DECORATE_INTERFACE_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_VELOCITY_DECORATE_INTERFACE_H_

#include <memory>

#include "amr_navigation/velocity_controller/velocity_controller_interface.h"
namespace amr_navigation {

class VelocityDecorateInterface : public VelocityControllerInterface {
 public:
  VelocityDecorateInterface() = default;
  explicit VelocityDecorateInterface(
      std::shared_ptr<VelocityControllerInterface> controller_ptr)
      : velocity_controller_ptr_(controller_ptr) {}
  virtual ~VelocityDecorateInterface() = default;

  // 规划偏差, 规划剩余路经
  virtual void UpdateProcess(const std::shared_ptr<StateManager> state,
                             const std::shared_ptr<GoalManager> goal) = 0;

  // 到达判断
  virtual bool Arrived(const std::shared_ptr<StateManager> state,
                       const std::shared_ptr<GoalManager> goal) = 0;
  // 出轨判断
  virtual bool OffTheTrack(const std::shared_ptr<StateManager> state,
                           const std::shared_ptr<GoalManager> goal) = 0;

  // 错误判断
  virtual bool IsError(const std::shared_ptr<StateManager> state,
                       const std::shared_ptr<GoalManager> goal) = 0;

  // 计算 v, w
  virtual amr_msgs::move_cmd GetVelocity(
      const std::shared_ptr<StateManager> state,
      const std::shared_ptr<GoalManager> goal) = 0;

  virtual void Reset(const std::shared_ptr<StateManager> state,
                             const std::shared_ptr<GoalManager> goal) {}

 protected:
  std::shared_ptr<VelocityControllerInterface> velocity_controller_ptr_;
};

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_VELOCITY_DECORATE_INTERFACE_H_