/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_TRANSPLANT_ROTATE_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_TRANSPLANT_ROTATE_H_

#include "amr_navigation/velocity_controller/velocity_controller_interface.h"
#include "amr_msgs/request_pallet_center.h"
#include "amr_common/amr_topic_name.h"


namespace amr_navigation {

class TransPlantController : public VelocityControllerInterface {
 public:
  TransPlantController() {
    ros::NodeHandle nh;
  request_april_tag_pub_ = nh.advertise<amr_msgs::request_pallet_center>(
        amr_topic::kRequestPalletCenterTopic, 2);
  }
  
  ~TransPlantController() = default;

  // 规划偏差, 规划剩余路经
  void UpdateProcess(const std::shared_ptr<StateManager> state,
                     const std::shared_ptr<GoalManager> goal);

  // 到达判断
  bool Arrived(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);
  // 出轨判断
  bool OffTheTrack(const std::shared_ptr<StateManager> state,
                   const std::shared_ptr<GoalManager> goal);

  // 错误判断
  bool IsError(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);

  // const float TransPlantController::GetForkMoveSpeed(const double &target_height,
  //                                                const double &current_height,
  //                                                const double &current_speed);

  // 计算 v, w
  amr_msgs::move_cmd GetVelocity(const std::shared_ptr<StateManager> state,
                                   const std::shared_ptr<GoalManager> goal);

 private: 
 void PublishPalletCenterRequest(const Pose& pose);
   double GetOmega(const double& dy, const double& dw1, const double& dw2,
                  const double& v, const double& last_cmd_w,
                  const PathDeviationGain& option);

  NavigationDeviation GetStablizerDeviation(const Pose& current_pose,
                                            const Pose& target_pallet_pose);

  double GetDeltaY(const Pose& current_pose, const Pose& target_pallet_pose);

  double GetYawBias(const Pose& current_pose, const Pose& target_pallet_pose);

  double GetYawBias2(const Pose& current_pose, const Pose& target_pallet_pose);

  MotionType motion_type_;
  double x_distance_to_end_;
  ros::Publisher request_april_tag_pub_;
  Pose start_pose_;
  Pose end_pose_;
  bool extend_step_;
};

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_TRANSPLANT_ROTATE_H_
