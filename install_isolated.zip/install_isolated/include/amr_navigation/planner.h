/**
 * Copyright (c) 2018 amr Inc. All rights reserved.
 */

#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_PLANNER_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_PLANNER_H_

#include "amr_msgs/pose_deviation.h"
#include "amr_navigation/goal_manager.h"
#include "amr_navigation/navigation_options.h"
#include "amr_navigation/state_manager.h"
#include "amr_navigation/velocity_controller/velocity_controller_factory.h"

namespace amr_navigation {
using NaviType = dispacth::NaviType;
using MotionType = navigation::MotionType;

class Planner {
 public:
  Planner() = delete;

  explicit Planner(const NavigationOption &option);

  bool Update(const std::shared_ptr<StateManager> state,
              const std::shared_ptr<GoalManager> goal);

  amr_msgs::move_cmd Plan(const std::shared_ptr<StateManager> state,
                            const std::shared_ptr<GoalManager> goal);

  const NavigationDeviation GetDeviation() {
    return velocity_controller_interface_->GetDeviation();
  }

  bool UpdateOption(const NavigationOption &option) {
    option_ = option;
    if (nullptr == velocity_controller_interface_) {
      return false;
    }
    velocity_controller_interface_->UpdateOption(option);
    return true;
  }

 private:
  void UpdateController(const std::shared_ptr<StateManager> state,
                        const std::shared_ptr<GoalManager> goal);

  VelocityControllerType velocity_controller_type_;
  MotionType last_motion_type_;
  std::shared_ptr<VelocityControllerInterface> velocity_controller_interface_;
  NavigationOption option_;
  ros::Publisher pose_deviation_pub_;
};

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_PLANNER_H_
