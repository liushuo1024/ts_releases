/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_NAVIGATION_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_NAVIGATION_H_
#include <ros/ros.h>

#include <mutex>
#include <string>
#include <thread>

#include "amr_common/amr_topic_name.h"
#include "amr_common/node_diagnostic_info.h"
#include "amr_msgs/pgv100_feedback.h"
#include "amr_msgs/pose_deviation.h"
#include "amr_navigation/goal_manager.h"
#include "amr_navigation/navigation_options.h"
#include "amr_navigation/planner.h"
#include "amr_navigation/state_manager.h"
//#include "hikvs_mv_im5005_ros/hikvs_mv_im5005.h"

namespace amr_navigation {

class Navigation {
 public:
  Navigation();

  ~Navigation() {
    if (executor_) {
      executor_->join();
      executor_ = nullptr;
    }
  }

  bool Init(const NavigationOption& option);

  void Run();

  // 输入
  void AddTrackPathActionTask(const amr_msgs::track_pathGoalConstPtr& goal,
                              std::shared_ptr<TrackPathActionServer> as);
  void AddMoveFeedbackData(const amr_msgs::move_feedback::ConstPtr& feedback);
  void AddOdometryData(const nav_msgs::Odometry::ConstPtr& msg);
  void AddSafetyStateData(const amr_msgs::safety_state::ConstPtr& feedback);
  void AddPalletCenterData(
      const amr_msgs::pallet_center_feedback::ConstPtr& feedback);
  void AddForkPalletStablizerData(
      const amr_msgs::pallet_stablizer::ConstPtr& feedback);
  void AddRightForkPalletStablizerData(
      const amr_msgs::pallet_stablizer::ConstPtr& feedback);
  void AddPalletForkIoStateData(
      const amr_msgs::pallet_fork_io_state::ConstPtr& feedback);
  void AddBatteryData(const amr_msgs::battery::ConstPtr& feedback);
  void AddLeftMotorData(
      const amr_msgs::motor_syntro_feedback::ConstPtr& feedback);
  void AddRightMotorData(
      const amr_msgs::motor_syntro_feedback::ConstPtr& feedback);
  void AddSafetyIOmsg(const amr_msgs::safety_io_state::ConstPtr& feedback);
  void AddStopProtectData(const amr_msgs::stop_protect::ConstPtr& feedback);
  void AddJackUpIOStateData(
      const amr_msgs::jack_up_io_state::ConstPtr& feedback);
  void AddDockStateData(const amr_msgs::roller_io_state::ConstPtr& feedback);
  void AddQrCodeData(uint64_t num);
  void AddQrCodeUpData(uint64_t num);
  bool UpdateOption(const NavigationOption& option);

 private:
  void Runner();

  void HandleError();

  // 节点监控
  void NodeDiagnostic(const ros::TimerEvent& e);

  inline void SetNodeStatus(
      const amr_diagnostic::NavigationNodeStatus& status) {
    node_status_ = static_cast<uint16_t>(status);
  }

  NavigationOption option_;
  std::shared_ptr<std::thread> executor_;

  std::mutex mutex_;

  std::shared_ptr<GoalManager> goal_manager_;
  std::shared_ptr<StateManager> state_manager_;
  std::shared_ptr<Planner> planner_;

  ros::Publisher cmd_vel_pub_;
  ros::Publisher pose_deviation_pub_;
  ros::Publisher node_diagnostic_pub_;
  uint16_t node_status_;
  ros::Timer node_diagnostic_timer_;
};

}  // end of namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_NAVIGATION_H_
