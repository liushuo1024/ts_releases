/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_NAVIGATION_OPTIONS_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_NAVIGATION_OPTIONS_H_
#include <ros/ros.h>

#include <string>

#include "amr_common/geometry/amr_geometry.h"

namespace amr_navigation {

enum class DeviationType : uint8_t {
  NONE = 0,
  STRAIGHT_LINE = 1,
  B_SPLINE_CURVES = 2
};
struct OmegaControllDeviation {
  double delta_y_control;
  double theta_control;
  double track_yaw_control;
  OmegaControllDeviation()
      : delta_y_control(0.), theta_control(0.), track_yaw_control(0.) {}
  double get() { return delta_y_control + theta_control + track_yaw_control; }
};

struct TimedPalletDistInfo {
  ros::Time time;
  bool vaild;
  TimedPalletDistInfo() : vaild(false) {}
};

struct TimedPalletStablizerInfo {
  ros::Time time;
  uint32_t id;
  amr_geometry::Pose pose;
  double pallet_length;
  bool Vaild() { return ros::Time::now() - time < ros::Duration(30.0); }
  TimedPalletStablizerInfo() : id(0), pallet_length(0.), time(ros::Time()) {}
};

struct NavigationDeviation {
  DeviationType deviation_type;
  double delta_y;         // 轨迹跟踪横向偏差
  double delta_theta;     // 轨迹跟踪角度偏差
  double delta_distance;  // 目标点距离值
  double spin_theta;      // 旋转角度
  double delta_yaw;       // b样条 额外偏差
  double curvature;       // 路径曲率 >0 左转  < 0 右转
  NavigationDeviation()
      : deviation_type(DeviationType::NONE),
        delta_y(0.),
        delta_theta(0.),
        delta_distance(0.),
        delta_yaw(0.),
        curvature(0.) {}
  std::string ToString() {
    std::stringstream info;
    info << "deviation info: "
         << " deviation_type : " << static_cast<double>(deviation_type)
         << " delta y: " << delta_y
         << ", delta theta: " << math::Rad2Deg(delta_theta)
         << ", delta_yaw: " << math::Rad2Deg(delta_yaw)
         << ", curvature: " << curvature << std::endl;
    return info.str();
  }
};

struct Warning {
  double distance_deviation;
  double angle_deviation;
};

struct Error {
  double distance_deviation;
  double angle_deviation;
};

struct Deviation {
  Warning warning;
  Error error;
};

struct AvoidRatio {
  double slow_level1_decel_ratio;
  double slow_level2_decel_ratio;
  double slow_level3_decel_ratio;
};

struct ChargeParamer {
  double charge_back_speed;     //充电时后退速度
  double motor_stop_current;    //行走电机停止电流
  double charge_check_time;     //充电检测时间
  double charge_check_current;  //充电检测电流,充电为负值
  double battery_charge_sign;   //充电时电流值正:>0,负:<0
};

struct VelocityParamer {
  double max_v;
  double min_v;
  double acceleration;
  double deceleration;
  double margin;
  int inertia_gain;
  double
      s_curve_flex;  // S曲线区间，越大代表呀所得越厉害，越小越接近匀加速，通常4~6
  double kp;
  double ki;
  double kd;
  double x_stop_accuracy;    //前进后退停止精度，单位：米
  double yaw_stop_accuracy;  //旋转停止精度，单位：弧度
  double v_dynamic_para;  //考虑车体动力学，线速度反馈小于此值时才停止
  double w_dynamic_para;  //考虑车体动力学，角速度反馈小于此值时才停止
  bool use_avoid;
  bool spin_to_center;  //旋转至目标点中心

  // Z字整定参数
  double z_max_acc_dec;
  double z_kv;
  double z_kw;
  double z_x_bound;
  double z_yaw_bound;
  double z_x_truncation;
  double z_yaw_truncation;
};

struct PathDeviationGain {
  double laterl_error_gain = 0.;
  double orientation_error_gain = 0.;
  double track_error_gain = 0.;
};

struct PathStateParamer {
  double state_dist_threshould = 0.;
  double dist_to_next_step = 0.;
  double backup_state_dist_threshould = 0.;
  double backup_dist_to_next_step = 0.;
};

struct PathTrackingParamer {
  double high_precision_margin;
  PathStateParamer straight_path_state_paramer;
  PathDeviationGain straight_gain;
  PathDeviationGain straight_high_gain;
  PathStateParamer b_spline_path_state_paramer;
  PathDeviationGain b_spline_gain;
  PathDeviationGain b_spline_high_gain;
};

struct MagneticPidParamer {
  double p;
  double i;
  double d;
  double max_i_output;
  double limit_left;
  double limit_right;
};

struct DockingParamer {
  double docking_velocity;
  double docking_distance;
  double time_out;
};

struct OthersOptions {
  double fork_check_pallet_threshold;
  double track_column_threshold;
  double odom_exceed_translation_ratio;
  int qr_offtrack_threshold;
  bool need_tag_when_rotate;
  bool need_tag_when_arrived;
  double loss_distance;
};

struct ServerOption {
  std::string ip;
  int port;
};

struct NavigationOption {
  ServerOption server;
  float controller_frequency;
  bool enable_magnetic_navi;
  bool enable_up_qr_code;
  Deviation deviation;
  AvoidRatio avoid_ratio;
  ChargeParamer charge_check;
  VelocityParamer navigation_velocity;
  VelocityParamer rotation_velocity;
  VelocityParamer stabilization_velocity;
  PathTrackingParamer path_tracking_paramer;
  DockingParamer docking_paramer;
  MagneticPidParamer magnetic_pid_paramer;
  OthersOptions others_options;
};

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_NAVIGATION_OPTIONS_H_
