/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_PATH_STRAIGHT_PATH_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_PATH_STRAIGHT_PATH_H_

#include <memory>

#include "amr_navigation/path/path_interface.h"

namespace amr_navigation {

class StraightPath : public PathInterface {
 public:
  StraightPath(const PathTrackingParamer& option);
  ~StraightPath() {}

  bool UpdatePathInfo(const PathInfo& path_info);
  bool CheckPathInfo();
  const bool IsForward() { return is_forward_; }
  NavigationDeviation GetNavigationDeviation(const Pose& current_pose);
  bool Arrived(const Pose& current_pose, double* x_distance_to_end);

  void UpdateGoalPose(const Pose& pose, double delta_state,
                      double distance_threshold);

  PathInfo GetPathInfo() override { return path_info_; }

  double GetPathState() override { return state_; }

  // 根据s得到直线上的点信息；
  Pose GetStraightPose(double state);

  Pose GetGoalPose(const Pose& current_pose);

  std::string ToString() {
    std::stringstream info;
    info << "straight path info: "
         << "(" << start_pose_.x() << ", " << start_pose_.y() << ", "
         << math::Rad2Deg(start_pose_.yaw()) << ")"
         << "  ---> "
         << "(" << end_pose_.x() << ", " << end_pose_.y() << ", "
         << math::Rad2Deg(end_pose_.yaw()) << ")" << std::endl;
    return info.str();
  }

 private:
  double GetDeltaY(const Pose& current_pose);
  double GetYawBias(const Pose& current_pose);
  double GetYawBias2(const Pose& current_pose);

  Pose start_pose_;
  Pose end_pose_;
  double yaw_;
  double state_;
  Pose goal_pose_;
  bool is_forward_;

  PathInfo path_info_;
};
}  // namespace amr_navigation

#endif  //  amr_NAVIGATION_INCLUDE_amr_NAVIGATION_PATH_STRAIGHT_PATH_H_