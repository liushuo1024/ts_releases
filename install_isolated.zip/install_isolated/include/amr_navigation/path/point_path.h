/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_PATH_POINT_PATH_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_PATH_POINT_PATH_H_

#include "amr_navigation/path/path_interface.h"

namespace amr_navigation {

class PointPath : public PathInterface {
 public:
  PointPath(const PathTrackingParamer& option);
  ~PointPath() {}

  bool UpdatePathInfo(const PathInfo& path_info);
  bool CheckPathInfo();
  const bool IsForward() { return false; }
  NavigationDeviation GetNavigationDeviation(const Pose& current_pose);
  bool Arrived(const Pose& current_pose, double* x_distance_to_end);

  Pose GetGoalPose(const Pose& current_pose);
  PathInfo GetPathInfo() override { return path_info_; }

  double GetPathState() override { return 0.0; }

  std::string ToString() {
    std::stringstream info;
    info << "point path info: "
         << "(" << path_info_.front().x() << ", " << path_info_.front().y()
         << ", " << math::Rad2Deg(path_info_.front().yaw()) << ")" << std::endl;
    return info.str();
  }

 private:
  PathInfo path_info_;
  Pose goal_pose_;
};
}  // namespace amr_navigation

#endif  //  amr_NAVIGATION_INCLUDE_amr_NAVIGATION_PATH_POINT_PATH_H_