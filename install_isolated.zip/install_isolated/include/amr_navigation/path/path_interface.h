/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_PATH_PATH_INTERFACE_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_PATH_PATH_INTERFACE_H_

#include <angles/angles.h>

#include <memory>
#include <queue>
#include <string>
#include <vector>

#include "amr_common/geometry/amr_geometry.h"
#include "amr_common/log_porting.h"
#include "amr_navigation/navigation_enum.h"
#include "amr_navigation/util.h"

namespace amr_navigation {
using Point = amr_geometry::Point;
using Pose = amr_geometry::Pose;
using PathInfo = std::queue<Pose>;

enum class PathInterfaceType : uint8_t {

  PATH_NONE = 0,
  PATH_POINT = 1,
  PATH_START = 2,
  PATH_STRAIGHT = 3,
  PATH_BSPLINE = 4
};

class PathInterface {
 public:
  explicit PathInterface(PathInterfaceType path_interface_type,
                         const PathTrackingParamer& option)
      : path_interface_type_(path_interface_type), option_(option) {}

  virtual ~PathInterface() = default;

  virtual bool UpdatePathInfo(const PathInfo& path_info) = 0;
  virtual bool CheckPathInfo() = 0;
  virtual NavigationDeviation GetNavigationDeviation(
      const Pose& current_pose) = 0;
  virtual bool Arrived(const Pose& current_pose, double* x_distance_to_end) = 0;

  virtual Pose GetGoalPose(const Pose& current_pose) = 0;

  virtual std::string ToString() = 0;

  virtual PathInfo GetPathInfo() = 0;

  virtual const bool IsForward() = 0;

  virtual bool UpdateNextPath(std::shared_ptr<PathInterface> next_path_ptr) {
    next_path_ptr_ = next_path_ptr;
    return true;
  }

  virtual double GetPathState() = 0;

  inline PathInterfaceType GetPathInterface() { return path_interface_type_; };

 protected:
  PathTrackingParamer option_;
  std::shared_ptr<PathInterface> next_path_ptr_;
  PathInterfaceType path_interface_type_;
};

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_PATH_PATH_INTERFACE_H_
