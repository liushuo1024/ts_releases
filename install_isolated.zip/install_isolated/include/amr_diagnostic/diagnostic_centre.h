/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_DIAGNOSTIC_INCLUDE_amr_DIAGNOSTIC_DIAGNOSTIC_CENTRE_H_
#define amr_DIAGNOSTIC_INCLUDE_amr_DIAGNOSTIC_DIAGNOSTIC_CENTRE_H_

#include <ros/ros.h>

#include <map>
#include <memory>
#include <string>
#include <thread>
#include <vector>

#include "amr_common/amr_node_name.h"
#include "amr_common/amr_topic_name.h"
// #include "amr_diagnostic/config_helper.h"
#include "amr_common/device_table_loader.h"
#include "amr_diagnostic/device_case.h"
#include "amr_diagnostic/diagnostic_options.h"
#include "amr_msgs/fault_report.h"
#include "amr_common/node_diagnostic_info.h"

namespace amr_diagnostic {

class DiagnosticCentre final {
 public:
  DiagnosticCentre() = delete;

  explicit DiagnosticCentre(const amr_diagnostic::DiagnosticOption& option);

  ~DiagnosticCentre() {}

  bool Init(ros::NodeHandle* nh);

  void Run();

  void Runner();

  void Diagnostic2Decision();

  void UpdateFaultReport();

 private:
  amr_diagnostic::DiagnosticOption option_;
  std::vector<ros::Subscriber> subscriber_;
  std::map<std::string, std::shared_ptr<DeviceInterface>> device_map_;
  ros::Publisher fault_report_pub_;
  ros::Time start_time_;
  amr_msgs::fault_report fault_report_;
  std::shared_ptr<std::thread> run_executor_;
};

}  // namespace amr_diagnostic

#endif  // amr_DIAGNOSTIC_INCLUDE_amr_DIAGNOSTIC_DIAGNOSTIC_CENTRE_H_
