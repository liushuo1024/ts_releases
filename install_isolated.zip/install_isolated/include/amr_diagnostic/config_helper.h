/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_DIAGNOSTIC_INCLUDE_amr_DIAGNOSTIC_CONFIG_HELPER_H_
#define amr_DIAGNOSTIC_INCLUDE_amr_DIAGNOSTIC_CONFIG_HELPER_H_
#include <ros/package.h>

#include <map>
#include <string>
#include <vector>

#include "amr_common/log_porting.h"
#include "amr_common/util/json11.h"
#include "amr_common/util/local_service.h"

namespace amr_diagnostic {
// 读取 json 文件 加载配置

class ConfigHelper {
 public:
  ~ConfigHelper() {}
  // 单例实现
  static ConfigHelper& Instance() {
    static ConfigHelper instance;
    return instance;
  }

  ConfigHelper(const ConfigHelper&) = delete;
  ConfigHelper& operator=(const ConfigHelper&) = delete;

  // 加载 json 文件获取配置
  bool LoadConfig(const std::string& json_str);

  inline const std::vector<std::string>& GetSensorList() {
    return sensor_list_;
  }

 private:
  ConfigHelper() {}

  std::vector<std::string> sensor_list_;
};

}  // namespace amr_diagnostic
#endif  // amr_DIAGNOSTIC_INCLUDE_amr_DIAGNOSTIC_CONFIG_HELPER_H_
