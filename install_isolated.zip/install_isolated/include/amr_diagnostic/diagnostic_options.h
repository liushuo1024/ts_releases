/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_DIAGNOSTIC_INCLUDE_amr_DIAGNOSTIC_DIAGNOSTIC_OPTIONS_H_
#define amr_DIAGNOSTIC_INCLUDE_amr_DIAGNOSTIC_DIAGNOSTIC_OPTIONS_H_
#include <string>

namespace amr_diagnostic {
struct DiagnosticOption {
  double control_frequency;
  double fault_report_delay;
};

}  // namespace amr_diagnostic

#endif  // amr_DIAGNOSTIC_INCLUDE_amr_DIAGNOSTIC_DIAGNOSTIC_OPTIONS_H_
