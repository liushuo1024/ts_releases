/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_COMMUNICATE_INCLUDE_amr_COMMUNICATE_COMMUNICATE_H_
#define amr_COMMUNICATE_INCLUDE_amr_COMMUNICATE_COMMUNICATE_H_
#include <arpa/inet.h>
#include <net/if.h>
#include <netinet/in.h>
#include <ros/ros.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <unistd.h>

#include <cstring>
#include <iostream>
#include <map>
#include <memory>
#include <numeric>
#include <string>
#include <thread>
#include <vector>

#include "amr_common/common.h"
#include "amr_common/amr_config_helper.h"
#include "amr_common/amr_topic_name.h"
#include "amr_common/log_porting.h"
#include "amr_common/node_diagnostic_info.h"
#include "amr_common/thread_pool.h"
#include "amr_common/util/ping_tool.h"
#include "amr_communicate/communicate_method/mqtt.h"
#include "amr_communicate/communicate_method/udp_socket.h"
#include "amr_communicate/communicate_options.h"
#include "amr_communicate/protocl_message_v1.h"
#include "amr_msgs/agv_info_request.h"
#include "amr_msgs/agv_info_response.h"
#include "amr_msgs/agv_query_dispatch.h"
#include "amr_msgs/battery_info_request.h"
#include "amr_msgs/battery_info_response.h"
#include "amr_msgs/dongle_to_dispatch.h"
#include "amr_msgs/finish_relocation_request.h"
#include "amr_msgs/node_diagnostic.h"
#include "amr_msgs/storage.h"
#include "amr_msgs/task_calibration_request.h"
#include "amr_msgs/task_control_audio_request.h"
#include "amr_msgs/task_control_request.h"
#include "amr_msgs/task_finish_request.h"
#include "amr_msgs/task_get_map_request.h"
#include "amr_msgs/task_request.h"
#include "amr_msgs/task_response.h"
#include "amr_msgs/update_event.h"
#include "amr_msgs/update_single_task.h"

namespace amr_communicate {
class Communicate {
 public:
  Communicate(const CommunicateOption &option);

  Communicate &operator=(const Communicate &) = delete;
  ~Communicate() {
    if (network_checking_daemon_) {
      network_checking_daemon_->join();
      network_checking_daemon_ = nullptr;
    }
  }

  bool Init();

  bool RosCommunicateInit();

  bool Start();

  bool UpdateOption(const CommunicateOption &option);

  // 输入其他节点数据
  void AddUpdateEventMsg(
      const amr_msgs::update_event::ConstPtr &update_event);

  void AddTaskResponseMsg(
      const amr_msgs::task_response::ConstPtr &task_response);

  void AddTaskFinishRequestMsg(
      const amr_msgs::task_finish_request::ConstPtr &task_finish_request);

  void AddFinishRelocationRequestMsg(
      const amr_msgs::finish_relocation_request::ConstPtr
          &finish_relocation_request);

  void AddBatteryInfoResponseMsg(
      const amr_msgs::battery_info_response::ConstPtr &battery_info_response);

  void AddAgvInfoResponseMsg(
      const amr_msgs::agv_info_response::ConstPtr &agv_info_response);

  void AddDongleMsg(
      const amr_msgs::dongle_to_dispatch::ConstPtr &dongle_data);

 private:
  // 发送数据接口 输入数据包类型和数据包数据
  void Send(const std::string &msg_type, const std::string &msg_data,
            const Qos &qos);
  void Send(const std::string &bind_id, const std::string &msg_type,
            const std::string &msg_data, const Qos &qos);
  void Send(const std::string &bind_id, const std::string &remote_bind_id,
            const std::string &msg_type, const std::string &msg_data,
            const Qos &qos);

  void HttpSend(const std::string &msg_type, const std::string &msg_data);

  bool HttpPost(const std::string &server_ip, const int server_port,
                const std::string &api, const std::string &data);

  // 得到本机ip接口
  bool GetIP(const std::string &vNetType, std::string *strip);

  // udp 数据回调终端, 校验数据 并 分发给不同的回调函数
  void MessageCallback(ProtoclMessageV1 msg);

  // 不同数据包数据 回调函数
  void TaskResponseHandler(std::string data, const std::string &remote_bind_id);
  void TaskRequestHandler(std::string data, const std::string &remote_bind_id);
  void TaskControlRequestHandler(std::string data,
                                 const std::string &remote_bind_id);
  void TaskReLocationRequestHandler(std::string data,
                                    const std::string &remote_bind_id);
  void TaskCalibrationRequestHandler(std::string data,
                                     const std::string &remote_bind_id);
  void TaskGetMapRequestHandler(std::string data,
                                const std::string &remote_bind_id);
  void TaskControlAudioRequestHandler(std::string data,
                                      const std::string &remote_bind_id);
  void TaskQueryStorageRequestHandler(std::string data,
                                      const std::string &remote_bind_id);
  void TaskQueryOdomInfoRequestHandler(std::string data,
                                       const std::string &remote_bind_id);

  void TaskUpdateMapHandler(std::string data,
                            const std::string &remote_bind_id);
  void TaskUpdateStorageMapHandler(std::string data,
                                   const std::string &remote_bind_id);

  // 参数上传
  void TaskPushParamRequestHandler(std::string data,
                                   const std::string &remote_bind_id);
  // 参数更新
  void TaskUpdateBasicParamHandler(std::string data,
                                   const std::string &remote_bind_id);
  void TaskUpdateDeviceParamHandler(std::string data,
                                    const std::string &remote_bind_id);
  void TaskUpdateNavigationParamHandler(std::string data,
                                        const std::string &remote_bind_id);
  void TaskUpdateActionParamHandler(std::string data,
                                    const std::string &remote_bind_id);
  void TaskUpdateAvoidParamHandler(std::string data,
                                   const std::string &remote_bind_id);
  void TaskUpdateAvoidAreaParamHandler(std::string data,
                                       const std::string &remote_bind_id);
  void TaskUpdateLocalizerParamHandler(std::string data,
                                       const std::string &remote_bind_id);
  void TaskUpdateLogicParamHandler(std::string data,
                                   const std::string &remote_bind_id);
  void TaskUpdateEmbeddedParamHandler(std::string data,
                                      const std::string &remote_bind_id);
  // 单机任务
  void SingleTaskHandler(std::string data, const std::string &remote_bind_id);

  // 数据查询
  void BatteryInfoRequestHandler(std::string data,
                                 const std::string &remote_bind_id);

  bool AgvQueryDispatch(amr_msgs::agv_query_dispatch::Request &req,
                        amr_msgs::agv_query_dispatch::Response &res);

  void QueryInfoFromDispatch(const std::string &msg_type);

  // 节点监控
  void NodeDiagnostic(const ros::TimerEvent &e);

  // 通讯链路保持连接,掉线检测
  void NetWorkLinkCheck();

  inline void SetNodeStatus(
      const amr_diagnostic::CommunicateNodeStatus &status) {
    node_status_ = static_cast<uint16_t>(status);
  }

  void PrePare();

  std::shared_ptr<std::thread> network_checking_daemon_;

  uint16_t node_status_;
  ros::Timer node_diagnostic_timer_;
  ros::Timer network_link_timer_;

  CommunicateOption option_;
  std::map<std::string, ros::Publisher> msg_publishers_;
  std::map<std::string,
           std::function<void(std::string, const std::string &bind_id)>>
      handler_;
  std::map<std::string, std::string> agv_map_info_;

  std::shared_ptr<CommunicateInterface<ProtoclMessageV1>> socket_;
  util::PingTool ping_tool_;

  // 远程参数更新的服务器与本地配置不同
  std::string remote_calibration_host_;
  std::string remote_update_config_host_;

  std::string local_ip_;
  std::map<std::string, std::string> remote_bind_list_;

  ros::ServiceClient update_logic_config_service_client_;
  ros::ServiceClient update_localizer_config_service_client_;
  ros::ServiceClient update_navigation_config_service_client_;
  ros::ServiceClient update_action_config_service_client_;
  ros::ServiceClient update_avoid_config_service_client_;
  ros::ServiceClient update_avoid_area_config_service_client_;
  ros::ServiceClient update_single_task_service_client_;
  ros::ServiceClient update_embedded_config_service_client_;

  ros::ServiceServer agv_query_dispatch_server_;
  amr_common::ThreadPool thread_pool_;
};

}  // namespace amr_communicate

#endif  // amr_COMMUNICATE_INCLUDE_amr_COMMUNICATE_COMMUNICATE_H_
