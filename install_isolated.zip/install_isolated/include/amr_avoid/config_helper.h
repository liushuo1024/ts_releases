/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_AVOID_INCLUDE_amr_AVOID_CONFIG_HELPER_H_
#define amr_AVOID_INCLUDE_amr_AVOID_CONFIG_HELPER_H_
#include <map>
#include <string>
#include <vector>

#include "amr_avoid/avoid_constants.h"
#include "amr_avoid/avoid_options.h"
#include "amr_common/amr_config_helper.h"
#include "amr_common/log_porting.h"
#include "amr_common/util/json11.h"

namespace amr_avoid {

// <map_id, <area_name, [coordinate_vector]>>
using AvoidMap = std::map<int, std::map<std::string, std::vector<Boost_Point>>>;
using Inner = std::vector<Boost_Point>;

// 读取 json 文件 加载配置
class ConfigHelper {
 public:
  ~ConfigHelper() {}
  static ConfigHelper& Instance() {
    static ConfigHelper instance;
    return instance;
  }
  ConfigHelper(const ConfigHelper&) = delete;
  ConfigHelper& operator=(const ConfigHelper&) = delete;
  /**
   * \brief load config param from file path
   * \param the path of config param
   */
  bool LoadAvoidAreaConfig(const std::string& json_str);
  /**
   * \brief load Param config from file path
   * \param the path of config param
   */
  bool LoadParamConfig(const std::string& json_str,
                       amr_avoid::AvoidOption* option);
  /**
   * \brief get coordinate point from file
   */
  std::vector<Boost_Point> GetCoordinateVector(
      const std::vector<json11::Json>& vj);

  inline const AvoidMap& GetAvoidMap() { return avoid_map_; }

  inline const Polygon& GetAgvInner() { return agv_inner_; }

  inline const SensorTFData& GetSensorTransform() { return sensor_tf_; }

 private:
  ConfigHelper() {}

  AvoidMap avoid_map_;
  Polygon agv_inner_;
  SensorTFData sensor_tf_;
};
}  // namespace amr_avoid
#endif  // amr_AVOID_INCLUDE_amr_AVOID_CONFIG_HELPER_H_
