/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_AVOID_INCLUDE_amr_AVOID_STATE_MANAGER_H_
#define amr_AVOID_INCLUDE_amr_AVOID_STATE_MANAGER_H_
#include <ros/ros.h>
#include <tf/transform_listener.h>

#include <string>
#include <thread>

#include "amr_avoid/avoid_options.h"
#include "amr_common/amr_enum_type.h"
#include "amr_common/amr_tf_name.h"
#include "amr_common/geometry/amr_geometry.h"
#include "amr_common/math.h"
#include "amr_msgs/battery.h"
#include "amr_msgs/jack_up_io_state.h"
#include "amr_msgs/motor_syntro_feedback.h"
#include "amr_msgs/move_cmd.h"
#include "amr_msgs/move_feedback.h"
#include "amr_msgs/pallet_fork_io_state.h"
#include "amr_msgs/safety_state.h"
#include "amr_msgs/stop_protect.h"

namespace amr_avoid {

using Pose = amr_geometry::Pose;

class StateManager {
 public:
  /**
   * \brief getter
   */
  inline Pose pose() const { return pose_; }

  inline VelocityFactor velocity_factor() const { return velocity_factor_; }

  /**
   * \brief setter
   */
  inline Pose set_pose(const Pose& pose) { pose_ = pose; }

  inline VelocityFactor set_velocity_factor(const VelocityFactor& t) {
    velocity_factor_ = t;
  }

  std::map<std::string, std::shared_ptr<FixedRatioSampler>>& samplers() {
    return samplers_;
  }

 private:
  Pose pose_;
  VelocityFactor velocity_factor_;
  std::map<std::string, std::shared_ptr<FixedRatioSampler>> samplers_;
};

}  // namespace amr_avoid

#endif  // amr_AVOID_INCLUDE_amr_AVOID_STATE_MANAGER_H_
