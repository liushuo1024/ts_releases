/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_AVOID_INCLUDE_amr_AVOID_AVOID_MESSAGE_QUEUE_H_
#define amr_AVOID_INCLUDE_amr_AVOID_AVOID_MESSAGE_QUEUE_H_
#include <ros/ros.h>

#include <deque>
#include <mutex>
#include <utility>

#include "amr_avoid/avoid_constants.h"
#include "amr_avoid/avoid_options.h"
#include "amr_common/amr_enum_type.h"
#include "amr_common/log_porting.h"

namespace amr_avoid {
class AvoidMessageQueue : public std::deque<std::pair<ros::Time, AvoidFacotr>> {
 public:
  AvoidMessageQueue();
  AvoidFacotr Filter(const ros::Duration& reserve_time);

  void PushData(const ros::Time& time, const AvoidFacotr& factor);

 private:
  ros::Time start_time_;
  std::mutex mutex_;
};

}  // namespace amr_avoid
#endif  // amr_AVOID_INCLUDE_amr_AVOID_AVOID_MESSAGE_QUEUE_H_
