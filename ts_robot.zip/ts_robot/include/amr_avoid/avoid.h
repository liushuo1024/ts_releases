/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_AVOID_INCLUDE_amr_AVOID_AVOID_H_
#define amr_AVOID_INCLUDE_amr_AVOID_AVOID_H_
#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>
#include <tf/transform_listener.h>

#include <boost/shared_ptr.hpp>
#include <deque>
#include <string>
#include <thread>
#include <utility>

#include "amr_avoid/avoid_constants.h"
#include "amr_avoid/avoid_options.h"
#include "amr_avoid/avoid_process.h"
#include "amr_avoid/state_manager.h"
#include "amr_common/amr_topic_name.h"
#include "amr_common/node_diagnostic_info.h"
#include "amr_msgs/bmmsk34_encoder_feedback.h"
#include "amr_msgs/bump_reset.h"
#include "amr_msgs/front_camera_distance.h"
#include "amr_msgs/manual.h"
#include "amr_msgs/move_cmd.h"
#include "amr_msgs/node_diagnostic.h"
#include "amr_msgs/pallet_stablizer.h"
#include "amr_msgs/ultarsonic_feedback.h"

namespace amr_avoid {

class Avoid {
 public:
  /**
   * \brief default constructor
   */
  explicit Avoid(const AvoidOption& option,
                 std::shared_ptr<NodeStatusManager> node_status_manager_ptr,
                 std::shared_ptr<StateManager> state_manager);

  /**
   * \brief construct object with options
   * \param option all Avoid related parameters
   */
  // explicit Avoid(const AvoidOption& option);

  /**
   * \brief destructor
   */
  ~Avoid();

  /**
   * \brief option getter
   * \return LocalizerOption
   */
  inline AvoidOption Option() const { return option_; }

  /**
   * \brief option getter
   * \return LocalizerOption
   */
  bool UpdateOption(const AvoidOption& option) {
    option_ = option;
    return ap_->UpdateOption(option_.data_process_option);
  }

  /**
   * \brief do initialization
   * \return true if init succeeded
   */
  bool Init() { return ap_->Init(); }

  /**
   * \brief start a thread and excute cycle
   */
  void Run();

  void AddSafetyIOStateCallback(
      const amr_msgs::safety_io_state::ConstPtr& state);

  void AddPederstrianPoseCallback(
      const amr_msgs::multi_pedestrian_pose::ConstPtr& pose_list);

  void AddPGVR2100Callback(
      const amr_msgs::pgv_r2100_feedback::ConstPtr& data);

  void AddLaserScanCallback(const sensor_msgs::LaserScan::ConstPtr& scan);

  void AddAvoidLaser1Callback(const sensor_msgs::LaserScan::ConstPtr& scan);

  void AddUltarsonicCallback(
      const amr_msgs::ultarsonic_feedback::ConstPtr& data);

  void AddSafetySettingCallback(
      const amr_msgs::safety_setting::ConstPtr& setting);

  void AddManualCallback(const amr_msgs::manual::ConstPtr& manual);

  void AddLeftFrontCameraCallback(
      const amr_msgs::front_camera_distance::ConstPtr& data);

  void AddFrontCameraCallback(
      const amr_msgs::front_camera_distance::ConstPtr& data);

  void AddRightFrontCameraCallback(
      const amr_msgs::front_camera_distance::ConstPtr& data);

  void AddForkliftPalleState(
      const amr_msgs::pallet_fork_io_state::ConstPtr& pallet_fork_io_state);

  void AddMoveFeedback(const amr_msgs::move_feedback::ConstPtr& feedback);

  void AddHightBmmsk34Encode(
      const amr_msgs::bmmsk34_encoder_feedback::ConstPtr& bmmsk34);

  void AddBumpReset(const amr_msgs::bump_reset::ConstPtr& feedback);

  void AddForkPalletStablizerCallback(
      const amr_msgs::pallet_stablizer::ConstPtr& ks);

  void AddRightForkPalletStablizerCallback(
      const amr_msgs::pallet_stablizer::ConstPtr& ks);

  void UpdateRobotPose();

  void AddMoveCmd(const amr_msgs::move_cmd::ConstPtr& move_cmd);

 private:
  void Runner();
  /**
   * \brief handle error
   * \return true if can continue, false otherwise
   */
  ros::NodeHandle nh;

  void NodeDiagnostic(const ros::TimerEvent& e);

  AvoidOption option_;
  std::shared_ptr<std::thread> executor_;

  ros::Publisher avoid_level_pub_;
  std::shared_ptr<NodeStatusManager> node_status_manager_ptr_;
  std::shared_ptr<AvoidProcess> ap_;
  std::shared_ptr<StateManager> state_manager_;
};

}  // namespace amr_avoid

#endif  // amr_AVOID_INCLUDE_amr_AVOID_AVOID_H_
