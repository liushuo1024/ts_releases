/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_AVOID_INCLUDE_amr_AVOID_AVOID_OPTIONS_H_
#define amr_AVOID_INCLUDE_amr_AVOID_AVOID_OPTIONS_H_
#include <map>
#include <string>

namespace amr_avoid {

struct TopicOption {
  int num_laser_scans;
  bool io_state = false;
  bool avoid_laser_0 = false;    // 避障激光   左边
  bool avoid_laser_1 = false;    // 避障激光1  默认视为中间 
  bool avoid_laser_2 = false;    // 避障激光2  默认视为右边
  bool avoid_laser_3 = false;    // 避障激光3
  bool avoid_laser_4 = false;    // 避障激光4
  bool avoid_laser_5 = false;    // 避障激光5
  bool PGV_r2000_lidar = false;  // 倍加福定位激光
  bool PGV_r2100_avoid_lidar = false;  // 倍加福避障激光
  bool avoid_camera_0 = false;         // 前置中或左摄像头
  bool avoid_camera_1 = false;         // 前置中或左摄像头
  bool avoid_camera_2 = false;         // 右摄像头
  bool avoid_camera_3 = false;         // 叉腿右侧摄像头
  bool avoid_camera_4 = false;         // 叉腿左侧摄像头
  bool avoid_ultrasonic = false;       // 超声波避障
};

struct LaserScanOption {
  struct Filter {
    bool positive;
    double angle_min;
    double angle_max;
    double filter_laser_point;
  };

  int scan_sample_step;
  int samples_per_scan;
  std::string scan_frame_name;
  double angle_min;
  double angle_max;
  double angle_increment;
  double range_min;
  double range_max;
  Filter filter;
};

struct DataProcessOption {
  bool enable_visualize;
  bool ingore_error_laser_point;
  double sample_ratio;
  double overtime;
  LaserScanOption pgv_r2100;
  LaserScanOption navi_laser;
  std::map<std::string, LaserScanOption> avoid_laser;
};

struct AvoidOption {
  TopicOption topic_option;
  DataProcessOption data_process_option;
  bool enable_local_debug;
  double controller_frequency;
  double node_diagnostic_frequency;
  std::string config_filename;
};

struct AvoidFacotr {
  AvoidLevel type;
  AvoidSpeedLevel lv;
  double dist;
  AvoidFacotr()
      : type(AvoidLevel::NONE), lv(AvoidSpeedLevel::FREE), dist(100.) {}
};

struct VelocityFactor {
  bool vaild;
  double current_v;
  double current_w;
  VelocityFactor() : vaild(false), current_v(0.), current_w(0.) {}
};

}  // namespace amr_avoid

#endif  // amr_AVOID_INCLUDE_amr_AVOID_AVOID_OPTIONS_H_
