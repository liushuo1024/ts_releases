/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_AVOID_INCLUDE_amr_AVOID_AVOID_PROCESS_H_
#define amr_AVOID_INCLUDE_amr_AVOID_AVOID_PROCESS_H_
#include <geometry_msgs/PointStamped.h>
#include <geometry_msgs/PolygonStamped.h>
#include <sensor_msgs/LaserScan.h>

#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>
#include <list>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include "boost/algorithm/clamp.hpp"
#include "amr_avoid/avoid_constants.h"
#include "amr_avoid/avoid_message_queue.h"
#include "amr_avoid/avoid_options.h"
#include "amr_avoid/config_helper.h"
#include "amr_avoid/fixed_ratio_sampler.h"
#include "amr_avoid/state_manager.h"
#include "amr_common/amr_enum_type.h"
#include "amr_common/amr_topic_name.h"
#include "amr_common/log_porting.h"
#include "amr_common/math.h"
#include "amr_common/node_diagnostic_manager.h"
#include "amr_msgs/bmmsk34_encoder_feedback.h"
#include "amr_msgs/bump_reset.h"
#include "amr_msgs/front_camera_distance.h"
#include "amr_msgs/ks103_feedback.h"
#include "amr_msgs/manual.h"
#include "amr_msgs/move_cmd.h"
#include "amr_msgs/multi_pedestrian_pose.h"
#include "amr_msgs/pallet_fork_io_state.h"
#include "amr_msgs/pallet_stablizer.h"
#include "amr_msgs/pgv_r2100_feedback.h"
#include "amr_msgs/safety_io_state.h"
#include "amr_msgs/safety_setting.h"
#include "amr_msgs/safety_state.h"
#include "amr_msgs/ultarsonic_feedback.h"
#include "eigen3/Eigen/Dense"

namespace amr_avoid {

using AvoidNodeStatus = amr_diagnostic::AvoidNodeStatus;
using NodeStatusManager = amr_diagnostic::NodeStatusManager<AvoidNodeStatus>;

enum class ErrorCode : uint8_t {
  NONE = 0,
  CONFIG_ERR,
  AVOID_SETTING_ERR,
  DATA_CHECK_ERR,
  DATA_TIME_OUT,
  AVOID_OVERTIME,
  BUMP_ERR,
  FORK_LEG_AVOID,
  ULTRASOUND_AVOID,
  UP_FORWARD_LASER_OBSTACLE,
  SENSOR_PROTECT,
  PEDERSTRAIN_WARING
};

struct Strategy {
  Polygon slow_level1;
  Polygon slow_level2;
  Polygon stop;
  Polygon laser_protect;
  int32_t enable_ultrasonic;
};

struct SensorAvoidLevel {
  AvoidFacotr navi_laser;
  AvoidFacotr avoid_laser_1;
  AvoidFacotr pgv_r2100;
  AvoidFacotr io_state;
  AvoidFacotr ks_avoid;
  AvoidFacotr rs_avoid;  // 视觉避障
  AvoidFacotr pederstrian_avoid;
  AvoidFacotr ultarsonic_avoid;
};

struct UltrasoundAvoid {
  double length1;
  double length2;
  double length3;
};

struct SensorTimeOut {
  bool timeout;
  std::vector<double> type_vec;
};

class AvoidProcess {
 public:
  explicit AvoidProcess(
      const DataProcessOption &option, std::shared_ptr<StateManager> ptr,
      std::shared_ptr<NodeStatusManager> node_status_manager_ptr);
  /**
   * \brief config default config and param..
   */
  bool Init();

  bool UpdateOption(const DataProcessOption &option) {
    option_ = option;
    return true;
  }

  amr_msgs::safety_state GetAvoidState();

  void SafetyIOStateCallback(
      const amr_msgs::safety_io_state::ConstPtr &state);

  void PederstrianPoseCallback(
      const amr_msgs::multi_pedestrian_pose::ConstPtr &pose_list);

  void PGVR2100Callback(const amr_msgs::pgv_r2100_feedback::ConstPtr &data);

  void LaserScanCallback(const sensor_msgs::LaserScan::ConstPtr &scan);

  void AvoidLaserCallback(const sensor_msgs::LaserScan::ConstPtr &scan);

  void UltarsonicCallback(
      const amr_msgs::ultarsonic_feedback::ConstPtr &data);

  void SafetySettingCallback(
      const amr_msgs::safety_setting::ConstPtr &setting);

  void ManualCallback(const amr_msgs::manual::ConstPtr &manual);

  void AddBumpReset(const amr_msgs::bump_reset::ConstPtr &state);

  void AddForkliftPalleState(
      const amr_msgs::pallet_fork_io_state::ConstPtr &pallet_fork_io_state);

  void AddHightBmmsk34Encode(
      const amr_msgs::bmmsk34_encoder_feedback::ConstPtr &bmmsk34);

  void LeftFrontCameraCallback(
      const amr_msgs::front_camera_distance::ConstPtr &data);

  void FrontCameraCallback(
      const amr_msgs::front_camera_distance::ConstPtr &data);

  void RightFrontCameraCallback(
      const amr_msgs::front_camera_distance::ConstPtr &data);

  void ForkPalletStablizerCallback(
      const amr_msgs::pallet_stablizer::ConstPtr &data);

  void RightForkPalletStablizerCallback(
      const amr_msgs::pallet_stablizer::ConstPtr &data);

  void AddMoveCmd(const amr_msgs::move_cmd::ConstPtr &move_cmd);

  inline void ClearTimeOutCnt() { avoid_time_out_cnt_ = 0; }

 private:
  bool CheckScanPointNeiberVaild(const sensor_msgs::LaserScan::ConstPtr &scan,
                                 const int &index,
                                 const LaserScanOption &option,
                                 const double &margin);
  AvoidLevel GetAvoidType(const std::string &frame);

  // TODO(@some)后续由故障节点统一配置传感器超时检测
  AvoidLevel GetTimeoutType(const std::string &frame);

  AvoidFacotr Get2DPointsAvoidLevel(
      const amr_msgs::pallet_stablizer::ConstPtr &data,
      const Polygon &slow_level1, const Polygon &slow_level2,
      const Polygon &stop, const SensorTransform &tf);

  AvoidFacotr GetCameraAvoidLevel(const double &dist,
                                  const Polygon &slow_level1,
                                  const Polygon &slow_level2,
                                  const Polygon &stop,
                                  const SensorTransform &tf);
  AvoidFacotr GetScanAvoidLevel(const sensor_msgs::LaserScan::ConstPtr &scan,
                                const Polygon &slow_level1,
                                const Polygon &slow_level2, const Polygon &stop,
                                const Polygon &inner,
                                const LaserScanOption &option,
                                const SensorTransform &tf);

  AvoidFacotr GetUltrasonicAvoidLevel(const std::vector<Boost_Point> &scan_pt,
                                      const Polygon &slow_level1,
                                      const Polygon &slow_level2,
                                      const Polygon &stop);

  AvoidFacotr GetAvoidLaserAvoidLevel(
      const sensor_msgs::LaserScan::ConstPtr &scan, const Polygon &slow_level1,
      const Polygon &slow_level2, const Polygon &stop, const Polygon &inner,
      const LaserScanOption &option, const SensorTransform &tf);

  AvoidFacotr GetPederstrianAvoidLevel(
      const amr_msgs::multi_pedestrian_pose::ConstPtr &pose_list,
      const Polygon &slow_level1, const Polygon &slow_level2,
      const Polygon &stop, const SensorTransform &tf);

  AvoidSpeedLevel GetLaserProtectAvoidLevel(
      const sensor_msgs::LaserScan::ConstPtr &scan, const Polygon &protect_map,
      const LaserScanOption &option);
  /**
   * \brief transform that caculate point to poly
   */
  Polygon TransformPoly(const Polygon &from_poly, const SensorTransform &tf);

  void AvoidPolygonPublish(const sensor_msgs::LaserScan::ConstPtr &scan,
                           const Polygon &slow_level1,
                           const Polygon &slow_level2, const Polygon &stop);

  void AvoidPointPublish(const sensor_msgs::LaserScan::ConstPtr &scan,
                         const Boost_Point &pt);

  Strategy GetStrategy(
      const std::map<std::string, std::vector<Boost_Point>> area_map);

  /**
   * \brief  caculate  min dist from point to poly
   */
  double GetMinDistFromPtAndPoly(const Boost_Point &pt, const Polygon &poly);

  double CalIoAvoidDist(AvoidSpeedLevel avoid_level, const double &cmd_v,
                        const double &controller_frequency);

  SensorTimeOut SensorIsTimeout();

  DataProcessOption option_;
  ros::Duration reserve_time_;
  ros::Time lastest_stop_time_;
  SensorAvoidLevel sensor_avoid_level_;
  AvoidLevel io_state_;
  // 避障超时
  uint8_t avoid_time_out_cnt_;
  double height_;
  uint8_t fork_up_down_state_;

  ros::Publisher avoid_pub_;
  ros::Publisher point_pub_;
  ros::Publisher avoid_slow_level1_pub_;
  ros::Publisher avoid_slow_level2_pub_;
  ros::Publisher avoid_stop_pub_;

  std::map<std::string, std::vector<Boost_Point>> default_map_;
  Strategy active_strategy_;
  Strategy pederstrain_strategy_;
  Strategy default_strategy_;
  AvoidMessageQueue msg_queue_;
  std::shared_ptr<StateManager> state_manager_ptr_;
  std::shared_ptr<NodeStatusManager> node_status_manager_ptr_;
  std::list<double> left_front_camera_avoid_list_;
  std::list<double> front_camera_avoid_list_;
  std::list<double> right_front_camera_avoid_list_;
  double previous_value_ = 7000;
  double left_previous_value_ = 7000;
  double right_previous_value_ = 7000;

  amr_msgs::safety_state last_safety_state_;

  amr_msgs::move_cmd move_cmd_;
};
}  // namespace amr_avoid

#endif  // amr_AVOID_INCLUDE_amr_AVOID_AVOID_PROCESS_H_
