/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_GOAL_MANAGER_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_GOAL_MANAGER_H_
#include <actionlib/server/simple_action_server.h>
#include <ros/ros.h>

#include <queue>
#include <string>
#include <vector>

#include "amr_common/amr_enum_type.h"
#include "amr_common/geometry/amr_geometry.h"
#include "amr_msgs/track_pathAction.h"
#include "amr_navigation/navigation_enum.h"
#include "amr_navigation/path/b_spline_path.h"
#include "amr_navigation/path/path_interface.h"
#include "amr_navigation/path/point_path.h"
#include "amr_navigation/path/start_path.h"
#include "amr_navigation/path/straight_path.h"
#include "amr_navigation/path/lat_straight_path.h"
#include "amr_navigation/state_manager.h"

namespace amr_navigation {

using NaviType = dispacth::NaviType;
using MotionType = navigation::MotionType;
using Pose = amr_geometry::Pose;
using MoveType = dispacth::MoveType;

using TrackPathActionServer =
    actionlib::SimpleActionServer<amr_msgs::track_pathAction>;

struct AdjustSpeedPose {
  double adjust_speed;
  Pose adjust_pose;
  AdjustSpeedPose() : adjust_speed(0.0), adjust_pose(Pose()) {}
};

class SingleGoal {
 public:
  SingleGoal();
  ~SingleGoal() {}

  inline std::string order_id() const { return order_id_; }
  inline std::string task_id() const { return task_id_; }
  inline NaviType navi_type() const { return navi_type_; }
  inline MotionType motion_type() const { return motion_type_; }
  inline int32_t point_id() const { return point_id_; }
  inline int32_t next_point_id() { return next_point_id_; }
  inline MoveType next_move_type() { return next_move_type_; }
  inline double target_v() const { return target_v_; }
  inline double max_v() const { return max_v_; }
  inline Pose end_pose() const { return end_pose_; }
  inline double end_yaw() const { return end_pose_.yaw(); }
  inline AdjustSpeedPose adjust_speed_pose() const {
    return adjust_speed_pose_;
  }
  inline Pose start_pose() const { return start_pose_; }
  inline Pose high_precision_pose() const { return high_precision_pose_; }
  inline ros::Time goal_start_time() const { return goal_start_time_; }
  inline Pose start_odom_pose() const { return start_odom_pose_; }
  inline double goal_translation() const { return goal_translation_; }

  inline void set_order_id(const std::string &order_id) {
    order_id_ = order_id;
  }
  inline void set_task_id(const std::string &task_id) { task_id_ = task_id; }

  inline void set_navi_type(const NaviType &navi_type) {
    navi_type_ = navi_type;
  }
  inline void set_motion_type(const MotionType &motion_type) {
    motion_type_ = motion_type;
  }
  inline void set_next_motion_type(const MotionType &next_motion_type) {
    next_motion_type_ = next_motion_type;
  }
  inline void set_point_id(const int32_t &point_id) { point_id_ = point_id; }

  inline void set_next_point_id(const int32_t &next_point_id) {
    next_point_id_ = next_point_id;
  }

  inline void set_next_move_type(const MoveType &next_move_type) {
    next_move_type_ = next_move_type;
  }

  inline void set_target_v(const double &target_v) { target_v_ = target_v; }

  inline void set_max_v(const double &max_v) { max_v_ = max_v; }

  inline void set_end_pose(const Pose &pose) { end_pose_ = pose; }

  inline void set_adjust_speed_pose(const AdjustSpeedPose &adjust_speed_pose) {
    adjust_speed_pose_ = adjust_speed_pose;
  }

  inline void set_start_pose(const Pose &start_pose) {
    start_pose_ = start_pose;
  }

  inline void set_high_precision_pose(const Pose &high_precision_pose) {
    high_precision_pose_ = high_precision_pose;
  }

  inline void set_goal_start_time(const ros::Time &time) {
    goal_start_time_ = time;
  }
  inline void set_start_odom_pose(const Pose &pose) { start_odom_pose_ = pose; }
  inline void set_goal_translation(const double &translation) {
    goal_translation_ = translation;
  }

 private:
  ros::Time goal_start_time_;
  std::string order_id_;
  std::string task_id_;
  NaviType navi_type_;
  MotionType motion_type_;
  MotionType next_motion_type_;
  MoveType next_move_type_;
  int32_t point_id_;
  int32_t next_point_id_;

  double target_v_;
  double max_v_;
  // 每段任务的位移距离
  double goal_translation_;
  // 特殊速度点
  AdjustSpeedPose adjust_speed_pose_;
  // 任务串起点
  Pose start_pose_;
  // 高精度停放点
  Pose high_precision_pose_;
  Pose end_pose_;
  // 任务里程计起点
  Pose start_odom_pose_;
};

class GoalManager {
 public:
  GoalManager();
  ~GoalManager();

  bool UpdateOption(const NavigationOption &option);

  // 添加导航目标
  ErrorCode AddTrackPathActionTask(
      const amr_msgs::track_pathGoalConstPtr &goal,
      std::shared_ptr<TrackPathActionServer> action_server,
      std::shared_ptr<StateManager> state);

  inline bool is_waiting() const { return is_waiting_; }
  inline bool is_preempt() const {
    return action_server_->isPreemptRequested();
  }

  inline std::string order_id() const { return single_goal_.order_id(); }
  inline std::string task_id() const { return single_goal_.task_id(); }

  inline NaviType navi_type() const { return single_goal_.navi_type(); }
  inline MotionType motion_type() const { return single_goal_.motion_type(); }
  inline int32_t id() const { return single_goal_.point_id(); }
  inline int32_t next_point_id() { return single_goal_.next_point_id(); }
  inline MoveType next_move_type() { return single_goal_.next_move_type(); }
  inline double target_v() const { return single_goal_.target_v(); }
  inline double max_v() const { return single_goal_.max_v(); }
  inline double end_yaw() const { return single_goal_.end_yaw(); }

  inline AdjustSpeedPose adjust_speed_pose() const {
    return single_goal_.adjust_speed_pose();
  }
  inline Pose start_pose() const { return single_goal_.start_pose(); }
  inline Pose high_precision_pose() const {
    return single_goal_.high_precision_pose();
  }
  inline ros::Time goal_start_time() const {
    return single_goal_.goal_start_time();
  }
  inline double goal_translation() const {
    return single_goal_.goal_translation();
  }
  inline Pose start_odom_pose() const { return single_goal_.start_odom_pose(); }

  inline Pose end_pose() const { single_goal_.end_pose(); }

  // 上一次任务的数据接口
  inline MotionType last_motion_type() const {
    return last_single_goal_.motion_type();
  }
  inline Pose last_end_pose() const { last_single_goal_.end_pose(); }

  std::shared_ptr<PathInterface> PathAnalyzer() { return path_interface_; }

  const std::queue<Pose> PathInfo() const { return path_info_; }

  inline bool IsForward() {
    Eigen::Vector2d start_oritentation(std::cos(path_info_.front().yaw()),
                                       std::sin(path_info_.front().yaw()));
    Eigen::Vector2d start_to_end(
        path_info_.back().x() - path_info_.front().x(),
        path_info_.back().y() - path_info_.front().y());
    return start_oritentation.dot(start_to_end) > 0. ? true : false;
  }

  void Finish(const GoalFinishState &goal_state);

  void Preempted();

  void SetFeedback(amr_msgs::track_pathFeedback fb);

  inline std::string ToString() {}

 private:
  // 移除所有路经
  inline void PopAllPathInfo() {
    LOG_INFO("Pop All PathInfo");
    while (!path_info_.empty()) {
      path_info_.pop();
    }
  }

  // 移除走完的路经, 保留终点, 用来和下一段路经相连
  inline void PopArrivedPathInfo() {
    LOG_INFO("Pop Arrived PathInfo");
    while (path_info_.size() > 1) {
      path_info_.pop();
    }
  }

  inline void PopAllNextPathInfo() {
    LOG_INFO("Pop All PathInfo");
    while (!next_path_info_.empty()) {
      next_path_info_.pop();
    }
  }

  bool IsEqualLastGoal(const amr_msgs::track_pathGoalConstPtr &goal);

  std::shared_ptr<TrackPathActionServer> action_server_;

  bool is_waiting_;

  NavigationOption option_;

  SingleGoal single_goal_;
  SingleGoal last_single_goal_;
  std::queue<Pose> path_info_;  // 路经描述
  std::queue<Pose> next_path_info_;
  std::shared_ptr<PathInterface> path_interface_;  // 目标路经
  std::shared_ptr<PathInterface> next_path_interface_;
};

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_GOAL_MANAGER_H_
