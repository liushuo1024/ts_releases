/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_PATH_B_SPLINE_PATH_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_PATH_B_SPLINE_PATH_H_

#include <memory>
#include <vector>

#include "amr_navigation/path/path_interface.h"

namespace amr_navigation {

class BsplinePath : public PathInterface {
 public:
  BsplinePath(const PathTrackingParamer& option);
  ~BsplinePath() = default;

  bool UpdatePathInfo(const PathInfo& path_info);
  bool CheckPathInfo();
  const bool IsForward() { return is_forward_; }
  NavigationDeviation GetNavigationDeviation(const Pose& current_pose);
  bool Arrived(const Pose& current_pose, double* x_distance_to_end);

  Pose GetGoalPose(const Pose& current_pose);

  double GetPathState() override { return state_; }

  PathInfo GetPathInfo() override { return path_info_; }

  inline PathInterfaceType GetPathInterface() { return path_interface_type_; };

  std::string ToString() {
    std::stringstream info;
    info << "b-spline path info: "
         << "(" << control_points_[0].x() << ", " << control_points_[0].y()
         << ", " << math::Rad2Deg(control_points_[0].yaw()) << ")"
         << "  ---> "
         << "(" << control_points_[1].x() << ", " << control_points_[1].y()
         << ")"
         << "  ---> "
         << "(" << control_points_[2].x() << ", " << control_points_[2].y()
         << ")"
         << "  ---> "
         << "(" << control_points_[3].x() << ", " << control_points_[3].y()
         << ", " << math::Rad2Deg(control_points_[3].yaw()) << ")" << std::endl;
    return info.str();
  }

 private:
  double GetDeltaY(const Pose& current_pose);
  double GetYawBias(const Pose& current_pose);
  double GetYawBias2(const Pose& current_pose);

  // 根据s得到B样条曲线上的点信息；
  Pose GetCurvePose(double state);

  // 更新B样条上目标跟踪的点信息
  void UpdateGoalPose(const Pose& pose, double delta_state,
                      double distance_threshold);

  std::vector<double> UQuasiUniform();

  double BaseFunction(int i, int order, double state);

  Point DerivativeBCurve(double state, int order, int derivative_num);

  double GetCurvature(double state, int order);

  double ComputeRadius();

  double GetCurvatureWithDir(const double& current_curvature,
                             const double& start_curvature,
                             const bool& is_forward);

  // 高阶求导时使用
  std::vector<Point> DerivativeQPoints(double state, int order,
                                       int derivative_num);

  double state_;
  uint32_t control_points_number_;
  bool is_forward_;
  double start_curvature_;
  double current_curvature_;
  std::vector<Pose> control_points_;
  std::vector<double> node_vector_;
  Eigen::Vector2d move_orientation_criterion_;
  Pose end_pose_;
  Pose goal_pose_;
  Pose last_pose_;
  PathInfo path_info_;

  double dist_to_next_step_;
  double state_dist_threshould_;
};
}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_PATH_B_SPLINE_PATH_H_