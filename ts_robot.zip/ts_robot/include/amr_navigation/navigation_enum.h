/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_NAVIGATION_ENUM_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_NAVIGATION_ENUM_H_

namespace amr_navigation {

enum class VelocityControllerType {
  NONE = 0,
  DRIVING = 1,
  MAGNETIC = 2,
  ROATATE = 3,
  STABILIZE_UP = 4,
  STABILIZE_DOWN = 5,
  QR_DRIVING = 6,
  POWERON_SHAKING = 7,
  CHARGE = 8,
  CAR_BACK = 9,
  FREE_DRIVING = 10,
  DOCKING = 11,
  TRACK_COLUMN = 12,
  STRAIGHT_STABLIZE = 13,
  BCURVE_STABLIZE = 14,
  STABILIZE_DOWN_NOROTATE = 15,
  TRACK_FORBID_UN_LOAD = 16,
  FORK_ROTATE = 17,
  JACKUP_STRAIGHT_STABLIZE = 18,
  FORK_PALLET_STABLIZER = 20,
  TEB_DRIVING = 33,
  LAT_DRIVING = 32
};

enum class GoalFinishState : uint8_t {
  FAILED = 0,
  SUCCEEDED = 1,
  SUCCEEDED_TO_OPERATION = 2,
  SUCCEEDED_TO_END = 3
};

enum class ErrorCode {
  NONE = 0,
  INVALID_CMD = 1,
  LOSS_CMD = 2,
  ILLEGAL_OPTION = 3,
  OFF_THE_TRACK = 4,
  LOCATION_LOSS = 5,
  SHELF_LOSS = 6,
  GOAL_RECEIVE_CHECK_ERROR = 7,
  GOAL_FINISH_CHECK_ERROR = 8,
  POWERON_INIT_ERROR = 9,             // 上电初始化 抖动超时；
  DOWN_TAG_LOSS_WHEN_ROTATE = 10,     //旋转时二维码丢失
  DOWN_TAG_LOSS_WHEN_ARRIVED = 11,    //到站时二维码丢失
  DOWN_TAG_LOSS_WHEN_STABILIZE = 12,  //正定时二维码丢失
  DOCKING_TIMEOUT = 13,
  STABILIZE_TIMEOUT = 14  //整定超时
};

enum class TaskState { WAITING = 1, DOING = 2, HOLDING = 3 };

enum class MoveFeedbackState : int32_t {
  NONE = 0,
  MOVING,
  WAITING_NEW_GOAL,  // when target speed doesnt equal to zero;
  ARRIVED_AND_NOT_CHECKED,
  ARRIVED_AND_CHECKED
};

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_NAVIGATION_ENUM_H_
