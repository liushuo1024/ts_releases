/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_QR_DRIVING_CONTROLLER_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_QR_DRIVING_CONTROLLER_H_

#include "amr_navigation/velocity_controller/velocity_decorate_interface.h"

namespace amr_navigation {

class QrController : public VelocityDecorateInterface {
 public:
  explicit QrController(std::shared_ptr<VelocityControllerInterface> controller)
      : VelocityDecorateInterface(controller),
        is_arrived_(false),
        qr_offtrack_threshold_(0) {}
  QrController() = default;

  virtual void Init(const NavigationOption &option) {
    velocity_controller_ptr_->Init(option);
    UpdateOption(option);
  }

  virtual void UpdateOption(const NavigationOption &option) {
    velocity_controller_ptr_->UpdateOption(option);
    option_ = option;
  }

  // 规划偏差, 规划剩余路经
  void UpdateProcess(const std::shared_ptr<StateManager> state,
                     const std::shared_ptr<GoalManager> goal);

  // 到达判断
  bool Arrived(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);
  // 出轨判断
  bool OffTheTrack(const std::shared_ptr<StateManager> state,
                   const std::shared_ptr<GoalManager> goal);

  // 错误判断
  bool IsError(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);

  // 计算 v, w
  amr_msgs::move_cmd GetVelocity(const std::shared_ptr<StateManager> state,
                                   const std::shared_ptr<GoalManager> goal);

 private:
  bool is_arrived_;
  uint8_t qr_offtrack_threshold_;
};

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_QR_DRIVING_CONTROLLER_H_