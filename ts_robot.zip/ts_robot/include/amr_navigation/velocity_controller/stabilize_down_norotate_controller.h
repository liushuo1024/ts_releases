/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_STABLILIZE_DOWN_NOROTATE_CONTROLLER_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_STABLILIZE_DOWN_NOROTATE_CONTROLLER_H_

#include "amr_navigation/velocity_controller/velocity_controller_interface.h"

namespace amr_navigation {

class StabilizeDownNorotateVelocityController
    : public VelocityControllerInterface {
 public:
  StabilizeDownNorotateVelocityController()
      : dis_(0.),
        change_opposite_(1),
        goal_pose_vector_(0.f, 0.f),
        agv_move_flag_(false),
        first_in_(true) {}
  ~StabilizeDownNorotateVelocityController() = default;

  void Reset(const std::shared_ptr<StateManager> state,
                             const std::shared_ptr<GoalManager> goal){};
  // 规划偏差, 规划剩余路经
  void UpdateProcess(const std::shared_ptr<StateManager> state,
                     const std::shared_ptr<GoalManager> goal);

  // 到达判断
  bool Arrived(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);
  // 出轨判断005
  bool OffTheTrack(const std::shared_ptr<StateManager> state,
                   const std::shared_ptr<GoalManager> goal);

  // 错误判断
  bool IsError(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);

  // 计算 v, w
  amr_msgs::move_cmd GetVelocity(const std::shared_ptr<StateManager> state,
                                   const std::shared_ptr<GoalManager> goal);

  double GetYawBias(const double& current_yaw, const double& end_yaw);

  double GetIntermediateData(double x, double x_min, double x_max);

  double NearestShelfAngle(const double& end_yaw, const double& shelf_yaw);

  double Deadouter_1(const double& d_yaw_1);
  double Deadouter_2(const double& d_yaw_2);
  double Deadouter(const double& x, const double& x_min, const double& x_max);

 private:
  double shelf_near_angle_;
  double d_x;
  double d_y;
  double d_yaw;
  double dx_local_;
  double dy_local_;
  double goal_x;
  double goal_y;
  double goal_yaw;
  double temp_dyaw;
  double temp_dx;
  double dis_;
  double dis_agv_;
  int change_opposite_;
  bool agv_move_flag_;
  Eigen::Vector2d goal_pose_vector_;
  amr_msgs::move_cmd last_move_cmd_;
  ros::Time straight_start_time_;

  // 增加整定超时处理
  ros::Time start_time_;
  bool first_in_;
};

}  // namespace amr_navigation
#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_STABLILIZE_DOWN_CONTROLLER_H_