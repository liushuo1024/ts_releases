/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_TRACK_COLUMN_CONTROLLER_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_TRACK_COLUMN_CONTROLLER_H_

#include "amr_navigation/velocity_controller/velocity_controller_interface.h"
namespace amr_navigation {

class TrackColumnController : public VelocityControllerInterface {
 public:
  TrackColumnController()
      : end_of_the_distance_(0.),
        goal_state_(GoalFinishState::FAILED),
        cnt_(0),
        cnt2_(0),
        cnt3_(0),
        cnt4_(0),
        cnt5_(0) {}
  ~TrackColumnController() = default;

  // 规划偏差, 规划剩余路经
  void UpdateProcess(const std::shared_ptr<StateManager> state,
                     const std::shared_ptr<GoalManager> goal);

  // 到达判断
  bool Arrived(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);

  // 出轨判断
  bool OffTheTrack(const std::shared_ptr<StateManager> state,
                   const std::shared_ptr<GoalManager> goal);

  // 错误判断
  bool IsError(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);

  // 计算 v, w
  amr_msgs::move_cmd GetVelocity(const std::shared_ptr<StateManager> state,
                                   const std::shared_ptr<GoalManager> goal);

  GoalFinishState GetGoalState() override { return goal_state_; }

  void Reset(const std::shared_ptr<StateManager> state,
             const std::shared_ptr<GoalManager> goal) override {
    goal_state_ = GoalFinishState::FAILED;
    cnt_ = 0;
    cnt2_ = 0;
    cnt3_ = 0;
    cnt4_ = 0;
    cnt5_ = 0;
  }

 private:
  double GetOmega(const double& dy, const double& dw1, const double& dw2,
                  const double& v, const double& last_cmd_w,
                  const PathDeviationGain& option);

  PathDeviationGain AutoAdjustDeviation(const PathTrackingParamer& path_paramer,
                                        const DeviationType& type,
                                        const bool& high_precision,
                                        const double& dist,
                                        const double& margin);

  MotionType motion_type_;
  double end_of_the_distance_;
  GoalFinishState goal_state_;
  int cnt_;
  int cnt2_;
  int cnt3_;
  int cnt4_;
  int cnt5_;
};

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_TRACK_COLUMN_CONTROLLER_H_