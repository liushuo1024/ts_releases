/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_TEB_DRIVING_CONTROLLER_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_TEB_DRIVING_CONTROLLER_H_

#include "amr_navigation/velocity_controller/velocity_controller_interface.h"

// 避免PI宏定义冲突
#undef PI

#include <teb_local_planner/teb_config.h>
#include <teb_local_planner/optimal_planner.h>
#include <teb_local_planner/pose_se2.h>
#include <teb_local_planner/robot_footprint_model.h>
#include <teb_local_planner/obstacles.h>
#include <costmap_2d/costmap_2d_ros.h>
#include <tf2_ros/buffer.h>
#include <tf2/utils.h>
#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Twist.h>

namespace amr_navigation {

class TebDrivingController : public VelocityControllerInterface {
 public:
  TebDrivingController();
  ~TebDrivingController() = default;

  // 初始化TEB控制器参数
  void Init(const NavigationOption &option) override;
  
  // 重置TEB控制器状态
  void Reset(const std::shared_ptr<StateManager> state,
             const std::shared_ptr<GoalManager> goal) override;

  // 规划偏差, 规划剩余路径
  void UpdateProcess(const std::shared_ptr<StateManager> state,
                     const std::shared_ptr<GoalManager> goal) override;

  // 到达判断
  bool Arrived(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal) override;

  // 出轨判断
  bool OffTheTrack(const std::shared_ptr<StateManager> state,
                   const std::shared_ptr<GoalManager> goal) override;

  // 错误判断
  bool IsError(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal) override;

  // 使用TEB算法计算 v, w
  amr_msgs::move_cmd GetVelocity(const std::shared_ptr<StateManager> state,
                                 const std::shared_ptr<GoalManager> goal) override;

 private:
  // TEB相关参数和状态变量
  double x_distance_to_end_;
  MotionType motion_type_;
  
  // TEB配置参数 - 使用TEB库的配置结构
  teb_local_planner::TebConfig teb_config_;
  
  // TEB内部状态
  bool teb_initialized_;
  ros::Time last_update_time_;
  
  // TEB规划器实例
  boost::shared_ptr<teb_local_planner::TebOptimalPlanner> teb_planner_;
  
  // 障碍物容器
  teb_local_planner::ObstContainer obstacles_;
  
  // 机器人足迹模型
  teb_local_planner::RobotFootprintModelPtr robot_model_;
  
  // TF缓冲区
  tf2_ros::Buffer* tf_buffer_;
  
  // 代价地图
  costmap_2d::Costmap2DROS* costmap_ros_;
  
  // TEB算法相关辅助函数
  bool InitializeTebPlanner(const std::shared_ptr<StateManager> state,
                            const std::shared_ptr<GoalManager> goal);
  
  bool PlanTrajectory(const std::shared_ptr<StateManager> state,
                      const std::shared_ptr<GoalManager> goal,
                      amr_msgs::move_cmd& cmd);
  
  bool CheckTebFeasibility(const std::shared_ptr<StateManager> state,
                           const std::shared_ptr<GoalManager> goal);
  
  void UpdateObstacles(const std::shared_ptr<StateManager> state,
                       const std::shared_ptr<GoalManager> goal);
};

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_TEB_DRIVING_CONTROLLER_H_