/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_VELOCITY_CONTROLLER_INTERFACE_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_VELOCITY_CONTROLLER_INTERFACE_H_

#include "amr_common/amr_config_helper.h"
#include "amr_common/pid/mini_pid.h"
#include "amr_navigation/goal_manager.h"
#include "amr_navigation/navigation_options.h"
#include "amr_navigation/state_manager.h"
#include "amr_navigation/util.h"

namespace amr_navigation {

class VelocityControllerInterface {
 public:
  VelocityControllerInterface() = default;
  virtual ~VelocityControllerInterface() = default;

  virtual void Init(const NavigationOption &option) { UpdateOption(option); }
  virtual void UpdateOption(const NavigationOption &option) {
    option_ = option;
  }
  const NavigationDeviation GetDeviation() const { return deviation_; }
  const Pose GetGoalPose() const { return goal_pose_; }
  const OmegaControllDeviation GetOmegaController() const {
    return omega_controller_;
  }

  virtual void Reset(const std::shared_ptr<StateManager> state,
                     const std::shared_ptr<GoalManager> goal) {}

  // 规划偏差, 规划剩余路经
  virtual void UpdateProcess(const std::shared_ptr<StateManager> state,
                             const std::shared_ptr<GoalManager> goal) = 0;

  // 到达判断
  virtual bool Arrived(const std::shared_ptr<StateManager> state,
                       const std::shared_ptr<GoalManager> goal) = 0;
  // 出轨判断
  virtual bool OffTheTrack(const std::shared_ptr<StateManager> state,
                           const std::shared_ptr<GoalManager> goal) = 0;

  // 错误判断
  virtual bool IsError(const std::shared_ptr<StateManager> state,
                       const std::shared_ptr<GoalManager> goal) = 0;

  // TODO(@ssh) 防止大更改，原先控制器采用正常完成，特殊控制器采用特殊完成状态
  virtual GoalFinishState GetGoalState() { return GoalFinishState::SUCCEEDED; }
  // 计算 v, w
  virtual amr_msgs::move_cmd GetVelocity(
      const std::shared_ptr<StateManager> state,
      const std::shared_ptr<GoalManager> goal) = 0;

 protected:
  NavigationOption option_;
  NavigationDeviation deviation_;
  Pose goal_pose_;
  OmegaControllDeviation omega_controller_;
};

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_VELOCITY_CONTROLLER_INTERFACE_H_