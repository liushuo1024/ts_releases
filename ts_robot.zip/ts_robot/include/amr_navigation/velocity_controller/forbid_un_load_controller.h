/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_FORBID_UN_LOAD_CONTROLLER_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_FORBID_UN_LOAD_CONTROLLER_H_

#include "amr_common/thread_pool.h"
#include "amr_navigation/velocity_controller/velocity_controller_interface.h"
namespace amr_navigation {

using ThreadPool = amr_common::ThreadPool;

class ForbidUnLoadController : public VelocityControllerInterface {
 public:
  enum ForbidUnLoadState : uint8_t { NONE = 0, PERMIT = 1, FORBID = 2 };
  ForbidUnLoadController()
      : end_of_the_distance_(0.),
        cnt_(0),
        goal_state_(GoalFinishState::FAILED),
        forbid_state_(ForbidUnLoadState::NONE),
        doing_send_(false),
        thread_pool_(1),
        send_succeeded_(false) {}
  ~ForbidUnLoadController() = default;

  // 规划偏差, 规划剩余路经
  void UpdateProcess(const std::shared_ptr<StateManager> state,
                     const std::shared_ptr<GoalManager> goal);

  // 到达判断
  bool Arrived(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);

  // 出轨判断
  bool OffTheTrack(const std::shared_ptr<StateManager> state,
                   const std::shared_ptr<GoalManager> goal);

  // 错误判断
  bool IsError(const std::shared_ptr<StateManager> state,
               const std::shared_ptr<GoalManager> goal);

  // 计算 v, w
  amr_msgs::move_cmd GetVelocity(const std::shared_ptr<StateManager> state,
                                   const std::shared_ptr<GoalManager> goal);

  void Reset(const std::shared_ptr<StateManager> state,
                             const std::shared_ptr<GoalManager> goal);
  GoalFinishState GetGoalState() override { return goal_state_; }

 private:
  std::string PackForbidInfo(const std::string& order_id,
                             const std::string& task_id,
                             const ForbidUnLoadState info);

  bool SubSendForbidInfo(std::string order_id, std::string task_id,
                         const ForbidUnLoadState info);

  void SendForbidInfo(std::string order_id, std::string task_id,
                      const ForbidUnLoadState info);

  double GetDeltaY(const Pose& current_pose);

  double GetYawBias(const Pose& current_pose);
  double GetYawBias2(const Pose& current_pose);

  double GetOmega(const double& dy, const double& dw1, const double& dw2,
                  const double& v, const double& last_cmd_w,
                  const PathDeviationGain& option);

  PathDeviationGain AutoAdjustDeviation(const PathTrackingParamer& path_paramer,
                                        const DeviationType& type,
                                        const bool& high_precision,
                                        const double& dist,
                                        const double& margin);

  MotionType motion_type_;
  double end_of_the_distance_;
  Pose end_pose_;

  uint32_t cnt_;

  GoalFinishState goal_state_;
  ForbidUnLoadState forbid_state_;
  bool doing_send_;
  ThreadPool thread_pool_;
  bool send_succeeded_;
};

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_CONTROLLER_FORBID_UN_LOAD_CONTROLLER_H_