/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_NAVIGATION_INCLUDE_amr_NAVIGATION_STATE_MANAGER_H_
#define amr_NAVIGATION_INCLUDE_amr_NAVIGATION_STATE_MANAGER_H_
#include <nav_msgs/Odometry.h>
#include <ros/ros.h>
#include <tf/transform_listener.h>

#include <string>
#include <thread>

#include "amr_common/amr_enum_type.h"
#include "amr_common/amr_tf_name.h"
#include "amr_common/geometry/amr_geometry.h"
#include "amr_common/math.h"
#include "amr_msgs/battery.h"
#include "amr_msgs/jack_up_io_state.h"
#include "amr_msgs/motor_syntro_feedback.h"
#include "amr_msgs/move_cmd.h"
#include "amr_msgs/move_feedback.h"
#include "amr_msgs/pallet_center_feedback.h"
#include "amr_msgs/pallet_fork_io_state.h"
#include "amr_msgs/pallet_stablizer.h"
#include "amr_msgs/roller_io_state.h"
#include "amr_msgs/safety_io_state.h"
#include "amr_msgs/safety_state.h"
#include "amr_msgs/stop_protect.h"
#include "amr_navigation/navigation_enum.h"
#include "amr_navigation/navigation_options.h"

namespace amr_navigation {

using NaviType = dispacth::NaviType;
using MotionType = navigation::MotionType;
using Pose = amr_geometry::Pose;

class StateManager {
 public:
  StateManager();
  ~StateManager() = default;
  /**
   * \brief getter
   */
  inline bool pose_valid() const { return pose_valid_; }
  inline Pose pose() const { return pose_; }
  inline float current_v() const { return current_v_; }
  inline float current_w() const { return current_w_; }
  inline float last_cmd_v() const { return last_cmd_v_; }
  inline float last_cmd_w() const { return last_cmd_w_; }
  inline bool stop_protect() const { return stop_protect_; }
  inline ForkPalletState fork_pallet_state() const {
    return fork_pallet_state_;
  }
  inline JackUpDownState JackupLiftState() const { return jackup_lift_state_; }
  inline bool shelf_pose_valid() const { return shelf_pose_valid_; }
  inline Pose shelf_pose() const { return shelf_pose_; }
  inline AvoidLevel avoid_type() const { return avoid_type_; }
  inline AvoidLevel avoid_level() const { return avoid_level_; }
  inline double avoid_dist() const { return avoid_dist_; }

  inline TimedPalletDistInfo pallet_dist_info() const {
    return pallet_dist_info_;
  }

  inline TimedPalletDistInfo right_pallet_dist_info() const {
    return right_pallet_dist_info_;
  }

  inline TimedPalletStablizerInfo pallet_stablizer_info() const {
    return pallet_stablizer_info_;
  }

  inline nav_msgs::Odometry odom() const { return odom_; }

  inline Pose odom_pose() const {
    return Pose(odom_.pose.pose.position.x, odom_.pose.pose.position.y, 0.);
  }
  inline ErrorCode error() const { return err_; }

  inline uint32_t current_qr_num() const { return current_qr_num_; }
  inline bool is_on_qr_tag() const { return is_on_qr_tag_; }
  inline uint32_t shelf_qr_num() const { return shelf_qr_num_; }
  inline bool is_shelf_on_qr_tag() const { return is_shelf_on_qr_tag_; }
  inline float move_motor_current() const {
    return std::fabs((left_motor_current_ + right_motor_current_) / 2.);
  }

  inline uint8_t safety_io_state() const { return safety_io_state_; }

  inline float battery_current() const { return battery_current_; }

  inline DockState docker_state() const { return dock_state_; }

  inline TimedPalletStablizerInfo pre_pallet_stablizer_info() {
    return pre_pallet_stablizer_info_;
  }
  // inline amr_msgs::move_cmd last_cmd_vel() const { return cmd_vel_; }
  // inline double delta_y() const { return delta_y_; }
  // inline double yaw_bias() const { return yaw_bias_; }
  // inline float last_cmd_velocity() const { return last_cmd_velocity_; }
  // inline float mls_offset() const { return mls_plc_; }
  // inline MlsState mls_state() const { return mls_state_; }
  // inline bool on_maglane() const { return MlsState::NONE != mls_state_; }
  // inline uint32_t rfid() const { return rfid_; }
  // inline ChargeCheckerState charge_checker_state() const {
  //   return charge_checker_state_;
  // }

  void UpdateRobotPose();
  void UpdateShelfPose();

  /**
   * \brief setter
   */
  inline void set_pose_valid(bool set) { pose_valid_ = set; }
  inline void set_last_cmd_velocity(double v) { last_cmd_v_ = v; }
  inline void set_last_cmd_omega(double w) { last_cmd_w_ = w; }
  inline void set_pose(const Pose &pose) {
    pose_ = pose;
    pose_valid_ = true;
  }
  inline void set_shelf_pose_vaild(bool set) { shelf_pose_valid_ = set; }
  inline void set_shelf_pose(const Pose &pose) {
    shelf_pose_ = pose;
    shelf_pose_valid_ = true;
  }
  inline void set_error_code(ErrorCode err) { err_ = err; }

  inline void set_current_qr_num(uint32_t num) {
    if (current_qr_num_ == num) return;
    current_qr_num_ = num;

    bool state = current_qr_num_ != 0 ? true : false;
    set_is_on_qr_tag(state);
  }

  inline void set_shelf_qr_num(uint32_t num) {
    if (shelf_qr_num_ == num) return;
    shelf_qr_num_ = num;

    bool state = shelf_qr_num_ != 0 ? true : false;
    set_is_shelf_on_qr_tag(state);
  }

  inline void set_is_on_qr_tag(bool state) { is_on_qr_tag_ = state; }

  inline void set_is_shelf_on_qr_tag(bool state) {
    is_shelf_on_qr_tag_ = state;
  }

  inline void set_odom(const nav_msgs::Odometry &msg) { odom_ = msg; }

  inline void set_pre_pallet_stablizer_info(
      const TimedPalletStablizerInfo &info) {
    pre_pallet_stablizer_info_ = info;
  }

  inline void set_pallet_stablizer_info(const TimedPalletStablizerInfo &info) {
    pallet_stablizer_info_ = info;
  }

  //   inline void set_last_cmd_velocity(float v) { last_cmd_velocity_ = v; }
  //   inline void set_cmd_vel(amr_msgs::move_cmd cmd_vel) { cmd_vel_ =
  //   cmd_vel; } inline void set_delta_y(double val) { delta_y_ = val; }
  //   inline void set_yaw_bias(double val) { yaw_bias_ = val; } inline void
  //   set_move_feedback_state(MoveFeedbackState state) {
  //     move_feedback_state_ = state;
  //   }

  // 输入数据
  void AddMoveFeedbackData(const amr_msgs::move_feedback::ConstPtr &feedback);

  void AddOdometryData(const nav_msgs::Odometry::ConstPtr &msg);

  void AddSafetyStateData(const amr_msgs::safety_state::ConstPtr &feedback);

  void AddForkPalletStablizerData(
      const amr_msgs::pallet_stablizer::ConstPtr &feedback);

  void AddRightForkPalletStablizerData(
      const amr_msgs::pallet_stablizer::ConstPtr &feedback);

  void AddPalletCenterData(
      const amr_msgs::pallet_center_feedback::ConstPtr &feedback);

  void AddPalletForkIoStateData(
      const amr_msgs::pallet_fork_io_state::ConstPtr &feedback);

  void AddBatteryData(const amr_msgs::battery::ConstPtr &feedback);

  void AddLeftMotorData(
      const amr_msgs::motor_syntro_feedback::ConstPtr &feedback);

  void AddRightMotorData(
      const amr_msgs::motor_syntro_feedback::ConstPtr &feedback);

  void AddSafetyIOmsg(const amr_msgs::safety_io_state::ConstPtr &feedback);
  void AddJackupIoStateData(
      const amr_msgs::jack_up_io_state::ConstPtr &feedback);

  void AddStopProtectData(const amr_msgs::stop_protect::ConstPtr &feedback);

  void AddDockStateData(const amr_msgs::roller_io_state::ConstPtr &feedback);

  bool IsSensorReady();

  bool IsSafetyStateReady();

 private:
  std::shared_ptr<tf::TransformListener> tf_;

  bool pose_valid_;
  Pose pose_;
  nav_msgs::Odometry odom_;

  uint8_t safety_io_state_;

  float battery_current_;
  float move_motor_current_;
  float left_motor_current_;
  float right_motor_current_;

  float current_v_;
  float current_w_;

  double last_cmd_v_;
  double last_cmd_w_;

  uint32_t current_qr_num_;
  bool is_on_qr_tag_;

  uint32_t shelf_qr_num_;
  bool is_shelf_on_qr_tag_;

  bool stop_protect_;
  ForkPalletState fork_pallet_state_;
  JackUpDownState jackup_lift_state_;
  DockState dock_state_;
  AvoidLevel avoid_type_;

  ros::Time avoid_alive_time_;
  AvoidLevel avoid_level_;
  double avoid_dist_;

  TimedPalletDistInfo pallet_dist_info_;
  TimedPalletDistInfo right_pallet_dist_info_;
  TimedPalletStablizerInfo pallet_stablizer_info_;
  TimedPalletStablizerInfo pre_pallet_stablizer_info_;

  bool shelf_pose_valid_;
  Pose shelf_pose_;

  ErrorCode err_;

  // uint32_t rfid_;
  // MlsState mls_state_;
  // ChargeCheckerState charge_checker_state_;
  // MoveFeedbackState move_feedback_state_;
  // BatteryData battery_;
  // BatteryData last_battery_;
};

}  // namespace amr_navigation

#endif  // amr_NAVIGATION_INCLUDE_amr_NAVIGATION_STATE_MANAGER_H_
