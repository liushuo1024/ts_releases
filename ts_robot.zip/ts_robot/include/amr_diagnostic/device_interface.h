/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_DIAGNOSTIC_INCLUDE_amr_DIAGNOSTIC_DEVICE_INTERFACE_H_
#define amr_DIAGNOSTIC_INCLUDE_amr_DIAGNOSTIC_DEVICE_INTERFACE_H_

#include <ros/ros.h>

#include <mutex>
#include <string>
#include <vector>

#include "amr_msgs/error_info.h"

namespace amr_diagnostic {

using AgvErrorLevel = common::AgvErrorLevel;
struct FaultMsg {
  uint16_t level;
  uint16_t msg;
  std::vector<amr_msgs::error_info> error_info;

  FaultMsg() : level(0), msg(0) {}
};

// enum { OK = 0, WARN = 1, ERROR = 2, FATAL = 3 };

class DeviceInterface {
 public:
  explicit DeviceInterface(const std::string& device_name)
      : device_name_(device_name) {
    /* fill in constructor */
  }

  virtual ~DeviceInterface() {}
  virtual void Init() { /* fill in */
  }

  inline virtual void SetFaultMsg(const amr_diagnostic::FaultMsg& msg) {
    std::unique_lock<std::mutex> lock(mutex_);
    fault_msg_ = msg;
  }

  inline virtual amr_diagnostic::FaultMsg GetFaultMsg() {
    std::unique_lock<std::mutex> lock(mutex_);
    return fault_msg_;
  }
  // 通用处理函数
  template <typename T>
  void HandleNodeData(const T& data) {
    FaultMsg fault_temp;

    auto class_code = data->status % 1000;
    if (class_code >= 300 && class_code < 600) {
      fault_temp.level = static_cast<uint16_t>(AgvErrorLevel::WARN);
    } else if (class_code >= 600 && class_code < 1000) {
      fault_temp.level = static_cast<uint16_t>(AgvErrorLevel::ERROR);
    } else {
      fault_temp.level = static_cast<uint16_t>(AgvErrorLevel::NONE);
    }

    fault_temp.msg = data->status;
    fault_temp.error_info = data->error_info;
    SetFaultMsg(fault_temp);

    last_time_ = ros::Time::now();
  }
  // 通用处理函数
  template <typename T>
  void HandleSensorData(const T& data) {
    FaultMsg fault_temp;
    if (data->error_code)
      fault_temp.level = static_cast<uint16_t>(AgvErrorLevel::ERROR);
    else
      fault_temp.level = static_cast<uint16_t>(AgvErrorLevel::NONE);
    fault_temp.msg = data->error_code;
    SetFaultMsg(fault_temp);
  }

 protected:
  ros::Time last_time_;
  ros::Timer timer_;
  uint16_t error_base_;

 private:
  std::mutex mutex_;

  std::string device_name_;
  FaultMsg fault_msg_;
};

}  // namespace amr_diagnostic
#endif  // amr_DIAGNOSTIC_INCLUDE_amr_DIAGNOSTIC_DEVICE_INTERFACE_H_
