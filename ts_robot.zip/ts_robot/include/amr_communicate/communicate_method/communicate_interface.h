/**
 * Copyright (c) 2022 amr Inc. All rights reserved.
 */

#ifndef amr_COMMUNICATE_INCLUDE_amr_COMMUNICATE_COMMUNICATE_INTERFACE_H_
#define amr_COMMUNICATE_INCLUDE_amr_COMMUNICATE_COMMUNICATE_INTERFACE_H_

#include <ros/ros.h>

#include <deque>
#include <functional>
#include <string>
#include <thread>
#include <utility>

#include "amr_common/amr_protocal.h"
#include "amr_communicate/communicate_options.h"

using Qos = amr_protocal::Qos;

namespace amr_communicate {

template <typename MessageType>
class CommunicateInterface {
 public:
  virtual ~CommunicateInterface() {}

  virtual bool Init(const CommunicateOption& option) = 0;

  virtual void Listen(std::function<void(MessageType)> handler) = 0;

  virtual void Run() = 0;

  virtual void Send(const MessageType& msg, const Qos& qos) = 0;

  virtual void Send(const MessageType& msg, const std::string& remote_bind_id,
                    const Qos& qos) = 0;

  virtual bool Stop() = 0;
};

}  // namespace amr_communicate

#endif  // amr_COMMUNICATE_INCLUDE_amr_COMMUNICATE_COMMUNICATE_INTERFACE_H_