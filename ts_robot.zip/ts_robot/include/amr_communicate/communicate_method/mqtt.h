/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_COMMUNICATE_INCLUDE_amr_COMMUNICATE_MQTT_H_
#define amr_COMMUNICATE_INCLUDE_amr_COMMUNICATE_MQTT_H_

#include <ros/ros.h>
#include <stdint.h>
#include <stdio.h>

#include <deque>
#include <string>
#include <thread>

#include "amr_common/amr_protocal.h"
#include "amr_common/thread_pool.h"
#include "amr_communicate/communicate_method/communicate_interface.h"
#include "amr_communicate/communicate_method/mqtt/mqttclient.h"

namespace amr_communicate {

using ThreadPool = amr_common::ThreadPool;

static std::function<void(void *client, message_data_t *msg)> g_call_back;

static void MqttSubHandle(void *client, message_data_t *msg) {
  g_call_back(client, msg);
}

template <typename MessageType>
class Mqtt : public CommunicateInterface<MessageType> {
 public:
  Mqtt() : client_ptr_(nullptr), thread_pool_(1) {}
  ~Mqtt() { Stop(); }

  bool Init(const CommunicateOption &option) override {
    option_ = option;

    mqtt_log_init();

    ip_ = option_.server_ip;
    port_ = std::to_string(option_.server_port);
    client_id_ = option_.project_topic;

    client_ptr_ = mqtt_lease();

    mqtt_set_host(client_ptr_, (char *)(ip_.c_str()));
    mqtt_set_port(client_ptr_, (char *)(port_.c_str()));
    mqtt_set_user_name(client_ptr_, "amr");
    mqtt_set_password(client_ptr_, "amr@123");
    mqtt_set_client_id(client_ptr_, (char *)client_id_.c_str());
    mqtt_set_clean_session(client_ptr_, 1);
    
    int rc = mqtt_connect(client_ptr_);

    return rc == 0;
  }

  bool Stop() override {
    mqtt_disconnect(client_ptr_);
    mqtt_release(client_ptr_);
    return true;
  }

  void Run() override {
    if (!client_ptr_) return;
    sub_topic_ = std::string("/amr/") + option_.project_topic +
                 std::string("/dispatch/#");

    g_call_back = std::bind(&Mqtt::ProtoclHandle, this, std::placeholders::_1,
                            std::placeholders::_2);

    mqtt_subscribe(client_ptr_, sub_topic_.c_str(), QOS2, MqttSubHandle);
  }

  void Listen(std::function<void(MessageType)> handler) override {
    handler_ = handler;
  }

  void Send(const MessageType &msg, const Qos &qos) override {
    auto no_block_send = [&](const MessageType &msg, const Qos &qos) {
      MqttSendMsg(msg, qos);
    };
    thread_pool_.enqueue(no_block_send, msg, qos);
  }

  // 往指定ip发送
  void Send(const MessageType &msg, const std::string &remote_bind_id,
            const Qos &qos) override {
    auto no_block_send = [&](const MessageType &msg, const Qos &qos) {
      MqttSendMsg(msg, qos);
    };
    thread_pool_.enqueue(no_block_send, msg, qos);
  }

 private:
  void ProtoclHandle(void *client, message_data_t *msg) {
    MessageType r_message;
    r_message.Clear();
    std::string temp(reinterpret_cast<char *>(msg->message->payload));
    LOG_INFO(temp);
    std::memcpy(r_message.Data(),
                reinterpret_cast<char *>(msg->message->payload),
                msg->message->payloadlen);
    if (!handler_) return;
    handler_(r_message);
  }

  void MqttSendMsg(const MessageType &msg, const Qos &qos) {
    if (!client_ptr_) return;
    mqtt_message_t mqtt_msg;
    std::memset(&mqtt_msg, 0, sizeof(mqtt_msg));
    mqtt_msg.qos = static_cast<mqtt_qos_t>(qos);

    MessageType temp_msg = msg;
    std::string topic = std::string("/amr/") + option_.project_topic +
                        std::string("/agv/") + temp_msg.MsgType();
    mqtt_msg.payload = reinterpret_cast<void *>(temp_msg.Data());

    mqtt_publish(client_ptr_, topic.c_str(), &mqtt_msg);
  }

  CommunicateOption option_;
  std::deque<MessageType> w_messageQueue_;
  MessageType r_message_;

  std::string ip_;
  std::string port_;
  std::string client_id_;

  std::string sub_topic_;
  std::string pub_topic_;

  std::function<void(MessageType)> handler_;

  mqtt_client_t *client_ptr_;

  ThreadPool thread_pool_;
};

}  // namespace amr_communicate

#endif  // amr_COMMUNICATE_INCLUDE_amr_COMMUNICATE_MQTT_H_
