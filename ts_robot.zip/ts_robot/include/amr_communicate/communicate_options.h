/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef amr_COMMUNICATE_INCLUDE_amr_COMMUNICATE_COMMUNICATE_OPTIONS_H_
#define amr_COMMUNICATE_INCLUDE_amr_COMMUNICATE_COMMUNICATE_OPTIONS_H_
#include <string>

namespace amr_communicate {

enum CommunicateMethod : uint8_t { NONE = 0, UDP = 1, MQTT = 2 };

struct CommunicateOption {
  std::string server_ip;
  int server_port;
  int local_port;
  CommunicateMethod communicate_method;
  std::string project_topic;
  CommunicateOption()
      : server_port(0),
        local_port(0),
        communicate_method(CommunicateMethod::NONE) {}
};

}  // namespace amr_communicate

#endif  // amr_COMMUNICATE_INCLUDE_amr_COMMUNICATE_COMMUNICATE_OPTIONS_H_
