/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_LOGIC_OPTIONS_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_LOGIC_OPTIONS_H_
#include <string>

#include "amr_common/amr_enum_type.h"

namespace decision_maker {

struct TfListOption {
  bool enable_shelf_tf;
  bool enable_loclizer_tf;
  bool enable_record_tf;
  float rotation_theta;
};

struct ServerOption {
  std::string ip;
  int port;
};

struct LowPowerModeOption {
  bool enable_low_power_mode;
  float waiting_to_enter_time;  // 秒
};

struct FinishingModeOption {
  float time_out;  // 秒
};

struct OthersOption {
  float need_rotate_theta;
};

struct ForkliftLogicOption {
  float extend_threshold;  // 米
  bool enable_check_weight;
  bool enable_pallet_back_limit;
  bool enable_lose_pallet_check;
  bool enable_pallet_stablizer;
  bool enable_measure_size;
  bool enable_heap_fork_extend;
  bool enable_fork_tile;
  double fork_tile_1;
  double fork_tile_2;
  bool enable_auto_fork_up_down;
  double auto_fork_up_margin;
  double auto_fork_down_margin;
  uint32_t kplate_weight;
  uint32_t klost_weighing_threshold;
  double unload_distance_offset;
  double charge_distance_offset;
  double measure_size_adjust_lift;
};

struct JackUpLogicOption {
  bool enable_pallet_zero;
  bool enable_car_back;
  bool enable_pallet_stablizer;
  int stabilize_mode;
};

// 逻辑参数
struct LogicOption {
  AgvType agv_type;
  TfListOption tf_option;
  ServerOption server;
  LowPowerModeOption low_power_mode_option;
  FinishingModeOption finishing_mode_option;
  OthersOption others_option;
  ForkliftLogicOption fork_lift_logic_option;
  JackUpLogicOption jack_up_logic_option;
};
}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_LOGIC_OPTIONS_H_