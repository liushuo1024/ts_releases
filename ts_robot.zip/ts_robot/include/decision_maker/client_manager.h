/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_STEP_MANAGER_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_STEP_MANAGER_H_
#include <ros/ros.h>

#include <memory>
#include <string>
#include <vector>

#include "amr_msgs/agv_actionAction.h"
#include "amr_msgs/openloopAction.h"
#include "amr_msgs/track_pathAction.h"
#include "decision_maker/action_client.h"
#include "decision_maker/openloop_client.h"
#include "decision_maker/task_manager.h"
#include "decision_maker/track_path_client.h"

namespace decision_maker {
// state manager, choose client, send goal, and update state
class ClientManager {
 public:
  ClientManager(const std::string actionName, const std::string trackPathName,
                const std::string openloopName) {
    action_ptr_ = std::make_shared<ActionClient>(actionName);
    track_path_ptr_ = std::make_shared<TrackPathClient>(trackPathName);
    open_loop_ptr_ = std::make_shared<OpenloopClient>(openloopName);
  }
  ~ClientManager() {}

  void SendActionClientGoal(const amr_msgs::agv_actionGoal goal) {
    action_ptr_->SendActionGoal(goal);
  }

  void SendTrackPathClientGoal(const amr_msgs::track_pathGoal goal) {
    track_path_ptr_->SendTrackPathGoal(goal);
  }

  void SendOpenloopClientGoal(const amr_msgs::openloopGoal goal) {
    open_loop_ptr_->SendOpenloopGoal(goal);
  }

  void ResetActionTaskPermission() { action_ptr_->ResetTaskPermission(); }

  void ResetTrackPathTaskPermission() {
    track_path_ptr_->ResetTaskPermission();
  }

  void ResetOpenloopTaskPermission() { open_loop_ptr_->ResetTaskPermission(); }

  void ResetAllTaskPermission() {
    action_ptr_->ResetTaskPermission();
    track_path_ptr_->ResetTaskPermission();
    open_loop_ptr_->ResetTaskPermission();
  }

  void ResetActionClient() {
    action_ptr_->ResetFinishState();
    action_ptr_->ResetTaskPermission();
    action_ptr_->ResetTaskDone();
  }

  void ResetTrackPathClient() {
    track_path_ptr_->ResetFinishState();
    track_path_ptr_->ResetTaskPermission();
    track_path_ptr_->ResetTaskDone();
  }

  void ResetOpenloopClient() {
    open_loop_ptr_->ResetFinishState();
    open_loop_ptr_->ResetTaskPermission();
    open_loop_ptr_->ResetTaskDone();
  }

  void ResetAllClient() {
    ResetActionClient();
    ResetTrackPathClient();
    ResetOpenloopClient();
  }

  bool ActionClientActive() { return action_ptr_->ActionAccepted(); }

  bool TrackPathClientActive() { return track_path_ptr_->ActionAccepted(); }

  bool OpenloopClientActive() { return open_loop_ptr_->ActionAccepted(); }

  void GetGoal() {}

  bool CancelActionGoal() {
    if (ActionClientActive()) {
      action_ptr_->CancelActionGoal();
      LOG_INFO("Cancle Action goals");
      return true;
    }
    return false;
  }

  bool CancelTrackPathGoal() {
    if (TrackPathClientActive()) {
      track_path_ptr_->CancelTrackPathGoal();
      LOG_INFO("Cancle Track-path goals");
      return true;
    }
    return false;
  }

  bool CancelOpenloopGoal() {
    if (OpenloopClientActive()) {
      open_loop_ptr_->CancelOpenloopGoal();
      LOG_INFO("Cancle open-loop goals");
      return true;
    }
    return false;
  }

  void CancelAllGoal() {
    CancelActionGoal();
    CancelTrackPathGoal();
    CancelOpenloopGoal();
  }

  GoalFinishState TrackPathAndActionFinishState() {
    if (action_ptr_->FinishState() == GoalFinishState::SUCCEEDED &&
        track_path_ptr_->FinishState() == GoalFinishState::SUCCEEDED)
      return GoalFinishState::SUCCEEDED;
    else
      return GoalFinishState::FAILED;
  }

  GoalFinishState ActionClientFinishState() {
    return action_ptr_->FinishState();
  }

  GoalFinishState TrackPathClientFinishState() {
    return track_path_ptr_->FinishState();
  }

  GoalFinishState OpenloopClientFinishState() {
    return open_loop_ptr_->FinishState();
  }

  bool TrackPathSendTaskPermission() {
    return track_path_ptr_->SendTaskPermission();
  }

  bool ActionSendTaskPermission() { return action_ptr_->SendTaskPermission(); }

  bool OpenlooppSendTaskPermission() {
    return open_loop_ptr_->SendTaskPermission();
  }

  bool IsActionClientTaskDone() { return action_ptr_->TaskDone(); }

  bool IsTrackPathClientTaskDone() { return track_path_ptr_->TaskDone(); }

  bool IsOpenloopClientTaskDone() { return open_loop_ptr_->TaskDone(); }

  bool IsActionError() { return action_ptr_->ActionError(); }

  bool IsOpenLoopError() { return open_loop_ptr_->ActionError(); }

  bool IsTrackPathError() { return track_path_ptr_->ActionError(); }

  bool GetCurrentTrackPathMotionType() {
    return track_path_ptr_->ActionMotionType();
  }

 private:
  std::shared_ptr<ActionClient> action_ptr_;
  std::shared_ptr<TrackPathClient> track_path_ptr_;
  std::shared_ptr<OpenloopClient> open_loop_ptr_;
};

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_STEP_MANAGER_H_
