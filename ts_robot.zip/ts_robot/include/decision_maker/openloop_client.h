/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_OPENLOOP_CLIENT_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_OPENLOOP_CLIENT_H_
#include <actionlib/client/simple_action_client.h>

#include <string>

#include "amr_common/log_porting.h"
#include "amr_msgs/openloopAction.h"
#include "decision_maker/decision_maker_enum.h"

namespace decision_maker {

class OpenloopClient {
 public:
  OpenloopClient() = delete;
  explicit OpenloopClient(const std::string action_name, bool flag = true)
      : client_(action_name, flag) {
    finish_state_ = GoalFinishState::FAILED;
    is_client_available_ = false;
    task_done_ = false;
    could_send_task_ = true;
    percent_ = 0;
  }

  void SendOpenloopGoal(amr_msgs::openloopGoal goal) {
    LOG_DEBUG("Waiting for [openloop] server to start.");
    client_.waitForServer();
    LOG_DEBUG("[openloop] server started.");
    client_.sendGoal(goal, boost::bind(&OpenloopClient::doneCb, this, _1, _2),
                     boost::bind(&OpenloopClient::activeCb, this),
                     boost::bind(&OpenloopClient::feedbackCb, this, _1));
    finish_state_ = GoalFinishState::FAILED;
    task_done_ = false;
    could_send_task_ = false;
  }

  void CancelOpenloopGoal() {
    if (is_client_available_) {
      client_.cancelGoal();
      is_client_available_ = false;
    } else {
      LOG_ERROR("[openloop] state error, cancel goal failed!");
    }
  }

  GoalFinishState FinishState() { return finish_state_; }

  bool ActionAccepted() { return is_client_available_; }

  bool TaskDone() { return task_done_; }

  void ResetTaskPermission() { could_send_task_ = true; }

  void ResetFinishState() { finish_state_ = GoalFinishState::FAILED; }

  void ResetTaskDone() { task_done_ = false; }

  // 外部判断任务是否可发的接口
  bool SendTaskPermission() {
    return (!is_client_available_) && could_send_task_ && (!task_done_);
  }

  bool ActionError() { return false; }

 private:
  void doneCb(const actionlib::SimpleClientGoalState& state,
              const amr_msgs::openloopResultConstPtr& result) {
    finish_state_ = static_cast<GoalFinishState>(result->is_finish);
    LOG_INFO_STREAM("[openloop] finish!!! state:" << +result->is_finish);
    state_ = state.state_;
    // TODO(@ssh) 完成时任务该目标已经结束
    task_done_ = true;
    is_client_available_ = false;
  }

  void activeCb() {
    is_client_available_ = true;
    LOG_DEBUG("Goal is active! Begin [openloop].");
  }

  void feedbackCb(const amr_msgs::openloopFeedbackConstPtr& feedback) {
    LOG_DEBUG("[openloop] percent: %d", feedback->percent);
    percent_ = feedback->percent;
  }

  actionlib::SimpleActionClient<amr_msgs::openloopAction> client_;

  actionlib::SimpleClientGoalState::StateEnum state_;

  GoalFinishState finish_state_;
  bool is_client_available_;
  bool could_send_task_;
  bool task_done_;

  uint32_t percent_;
};

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_OPENLOOP_CLIENT_H_
