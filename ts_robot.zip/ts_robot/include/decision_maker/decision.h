/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_DECISION_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_DECISION_H_
#include <ros/ros.h>

#include <memory>
#include <string>
#include <vector>

#include "amr_common/amr_topic_name.h"
#include "amr_common/dongle/dongle.h"
#include "amr_common/dongle/io_dongle.h"
#include "amr_common/dongle/universal_dongle.h"
#include "amr_common/log_porting.h"
#include "amr_common/node_diagnostic_info.h"
#include "amr_common/util/remote_service.h"
#include "amr_msgs/agv_info_request.h"
#include "amr_msgs/bump_reset.h"
#include "amr_msgs/emergency.h"
#include "amr_msgs/fault_report.h"
#include "amr_msgs/pallet_center_feedback.h"
#include "amr_msgs/pallet_fork_io_state.h"
#include "amr_msgs/re_location.h"
#include "amr_msgs/task_control_audio_request.h"
#include "decision_maker/agv_model.h"
#include "decision_maker/agv_state.h"
#include "decision_maker/avoid_planner.h"
#include "decision_maker/client_manager.h"
#include "decision_maker/decision_maker_enum.h"
#include "decision_maker/task_manager.h"

namespace decision_maker {

using DongleData = amr_dongle::DongleData;
using DongleInterface = amr_dongle::DongleInterface;
using IoDongle = amr_dongle::IoDongle;
using Dongle = amr_dongle::Dongle;
using UniversalDongle = amr_dongle::UniversalDongle;
// constexpr int k10A = 100;
// constexpr int kFullCapacity = 90;

struct AudioMixLed {
  CorningLedType led = CorningLedType::LIGHT_OFF;
  AudioType audio = AudioType::NONE;
};

class OdomCollector {
 public:
  void OdomUpdate(const double &v, const double &t, const int &avoid_type) {
    std::unique_lock<std::mutex> lock(mutex_);
    odom_info_.odom += std::fabs(v) * t;
    odom_info_.total_duration += t;
    // TODO(@ssh) 速度小于0.02时均计入避障时间
    if (std::fabs(v) < 0.02) odom_info_.avoid_duration += t;
  }

  OdomInfo GetOdomInfo() { return odom_info_; }

  void ResetOdom() {
    std::unique_lock<std::mutex> lock(mutex_);
    odom_info_.odom = 0.;
    odom_info_.total_duration = 0.;
    odom_info_.avoid_duration = 0.;
  }

 private:
  std::mutex mutex_;
  OdomInfo odom_info_;
};
class Decision {
 public:
  Decision(const std::string actionName, const std::string trackPathName,
           const std::string openloopName, LogicOption option,
           ros::NodeHandle *nh);

  // ~Decision() {}

  // step ptr send goal, update goal, avoid ptr set pose
  void Run();
  // 发送应答响应
  inline ReportType Report() const { return report_; }
  inline IndicatorType IndicatorState() const { return indicator_; }
  inline LedType LedState() const { return led_state_; }
  inline SafetyState GetSafetyState() const { return safety_state_; }
  inline AudioStateType AudioState() const { return audio_state_; }
  inline AvoidLevel SafetyIoState() const { return safety_io_state_; }
  inline bool IsManual() const { return event_ptr_->manual; }
  inline bool IsEmergencyStop() const { return event_ptr_->emergency_stop; }

  inline bool UpdateOption(const LogicOption &option) {
    option_ = option;
    // TODO 校验完 return true
    return true;
  }

  inline bool TaskAvailable() const {
    return task_manager_ptr_->TaskAvailable();
  }

  inline DongleData GetDispatchEncryData() const { return to_dispatch_data_; }

  bool AddTaskData(const amr_msgs::task_request::ConstPtr &task_req) {
    bool receive_state = false;

    // // 加密狗死亡状态 无法接任务
    // if (!indicator_.dongle_alive_state_) {
    //   LOG_WARN_THROTTLE(1, "dongle has died, cant receive task !!!");
    //   return receive_state;
    // }

    if (task_req->step_list.empty() || task_req->step_size <= 0) {
      LOG_ERROR("Task with empty step.");
      return receive_state;
    }

    // 根据车载状态决定任务接受
    switch (state_->State()) {
      case AgvStateType::WAITING:
      case AgvStateType::LOWPOWERMODE:
      case AgvStateType::EMERGENCY_STOP: {
        // 任务会修改task 需上锁确保
        std::unique_lock<std::mutex> lock(task_mutex_);
        receive_state = task_manager_ptr_->AddTaskData(task_req);
        break;
      }
      case AgvStateType::DOING: {
        // 任务会修改task 需上锁确保
        std::unique_lock<std::mutex> lock(task_mutex_);
        receive_state = task_manager_ptr_->MergeTaskData(task_req, false);
        break;
      }
      case AgvStateType::PAUSE: {
        // 暂停状态加新任务会修改task 需上锁确保
        std::unique_lock<std::mutex> lock(task_mutex_);
        receive_state = task_manager_ptr_->MergeTaskData(task_req, true);
        break;
      }
      case AgvStateType::MANUAL: {
        LOG_WARN("manual mode can not add task");
        break;
      }
      case AgvStateType::CHARGING: {
        LOG_WARN("charging mode can not add task");
        break;
      }
      case AgvStateType::FAULT: {
        LOG_WARN("fault mode can not add task");
        break;
      }
      case AgvStateType::EMERGENCY_PAUSE: {
        LOG_WARN("emergency pause mode can not add task");
        break;
      }
      case AgvStateType::POWERON_SHAKING: {
        LOG_WARN("init mode can not add task");
        break;
      }
    }

    response_state_ = receive_state ? ResponseType::TASK_RECEIVED
                                    : ResponseType::TASK_ABNORMAL;
    LOG_INFO("add task state: %d", static_cast<int>(response_state_));
    return receive_state;
  }

  void AddTaskFinishResponseData(
      const amr_msgs::task_response::ConstPtr &task_resp) {
    event_ptr_->task_finish_response.type = task_resp->task_type;
    event_ptr_->task_finish_response.state = task_resp->state;
  }

  void AddMoveFeedbackData(
      const amr_msgs::move_feedback::ConstPtr &move_feedback) {
    feedback_cmd_.velocity = move_feedback->virtual_velocity;  // 车轮实际速度
    feedback_cmd_.omega = move_feedback->actual_omega;
  }

  void AddBatteryData(const amr_msgs::battery::ConstPtr &battery) {
    battery_ = battery->capacity;
    // TODO 无需检测, 根据 charge_state 来判断
    // if (option_.open_current_detection) {
    //   event_ptr_->charging = battery->current > k10A ? true : false;
    // } else {
    //   event_ptr_->charging = charge_do_state_;
    // }
  }

  void AddLoadStateData(const amr_msgs::load_state::ConstPtr &load_state) {
    event_ptr_->load_state = (LoadStateType)load_state->load_state;
    agv_model_ptr_->SetLoadState(load_state->load_state);
  }

  void AddPalletForkData(
      const amr_msgs::pallet_fork_io_state::ConstPtr &feedback) {
    event_ptr_->pallet_fork_state =
        static_cast<ForkStateType>(feedback->fork_up_down_state);
  }

  void AddErrorCodeData(
      const amr_msgs::fault_report::ConstPtr &fault_report) {
    error_node_alive_time_ = ros::Time::now();
    error_code_start_ = true;
    std::unique_lock<std::mutex> lock(error_mutex_);
    error_code_ = *fault_report;
    AddErrorLevelData(static_cast<uint32_t>(AgvErrorType::NONE),
                      error_code_.level);
    // HandleErrorCode();
  }

  bool CheckNodesAlive(const amr_msgs::fault_report &error) {
    bool ret = true;
    // 判断必要节点是否正常存活
    for (const auto &error_state : error.error_code) {
      if (error_state.id == amr_topic::kAvoidDiagnosticTopic &&
          (error_state.error_code ==
           static_cast<uint16_t>(amr_diagnostic::AvoidNodeStatus::NORMAL) +
               999))
        ret = false;

      if (error_state.id == amr_topic::kCommunicateDiagnosticTopic &&
          (error_state.error_code ==
           static_cast<uint16_t>(
               amr_diagnostic::CommunicateNodeStatus::NORMAL) +
               999))
        ret = false;

      if (error_state.id == amr_topic::kEmbeddedDiagnosticTopic &&
          (error_state.error_code ==
           static_cast<uint16_t>(amr_diagnostic::EmbeddedNodeStatus::NORMAL) +
               999))
        ret = false;
    }

    // 判断诊断节点是否存活
    if (ros::Time::now() - error_node_alive_time_ > ros::Duration(1.0))
      ret = false;

    return ret;
  }

  // 错误码处理函数
  void HandleErrorCode() {
    static int match_count = 0;
    bool has_local_warn = false;
    bool has_local_init_warn = false;
    bool has_navi_warn = false;
    bool has_pederstrain_warn = false;
    bool has_avoid_date_timeout_warn = false;
    bool has_shelf_warn = false;
    bool has_pallet_detect_warn = false;
    bool has_embedded_driver_warn = false;
    bool has_weight_check_warn = false;
    bool has_down_tag_loss = false;
    bool has_up_tag_loss = false;
    bool has_docking_time_out_err = false;
    bool has_stabilize_time_out_err = false;
    bool has_action_time_out_err = false;
    bool has_down_qr_camera_err = false;
    bool has_up_qr_camera_err = false;
    bool has_velocity_err = false;
    bool has_pallet_back_limit = false;

    if (!error_code_start_ &&
        (ros::Time::now() - error_node_alive_time_ > ros::Duration(10.))) {
      AddErrorLevelData(static_cast<uint32_t>(AgvErrorType::NONE),
                        static_cast<uint16_t>(AgvErrorLevel::FATAL));
      std::cout << "error_code_start_: " << error_code_start_ << std::endl;
      std::cout  << "time diff: " << ros::Time::now() - error_node_alive_time_ << std::endl;
      std::cout << "now: " << ros::Time::now() << std::endl;
      std::cout << "error_node_alive_time_: " << error_node_alive_time_ << std::endl;
      LOG_ERROR_THROTTLE(1, "Diagnostic_node not alive!!!");
      return;
    }

    if (!error_code_start_) return;

    // 避免多线程读取同一变量
    std::unique_lock<std::mutex> lock(error_mutex_);
    const auto error = error_code_;
    for (const auto &error_state : error.error_code) {
      if (error_state.id == amr_topic::kLocalizerDiagnosticTopic &&
          (error_state.error_code ==
               static_cast<uint16_t>(amr_diagnostic::LocalizerNodeStatus::
                                         ENVIROMENT_MATCH_WARING) ||
           error_state.error_code ==
               static_cast<uint16_t>(
                   amr_diagnostic::LocalizerNodeStatus::SLAM_POSE_ERROR) ||
           error_state.error_code ==
               static_cast<uint16_t>(amr_diagnostic::LocalizerNodeStatus::
                                         LASER_MESSAGE_EMPTY))) {
        has_local_warn = true;
        AddErrorLevelData(static_cast<uint32_t>(AgvErrorType::NONE),
                          static_cast<uint16_t>(AgvErrorLevel::FATAL));
        indicator_.localizer_match_error = true;
      }
      if (error_state.id == amr_topic::kLocalizerDiagnosticTopic &&
          (error_state.error_code ==
               static_cast<uint16_t>(
                   amr_diagnostic::LocalizerNodeStatus::INIT_FAILED) ||
           error_state.error_code ==
               static_cast<uint16_t>(amr_diagnostic::LocalizerNodeStatus::
                                         GET_LANDMARK_MAP_ERROR) ||
           error_state.error_code ==
               static_cast<uint16_t>(amr_diagnostic::LocalizerNodeStatus::
                                         STATIC_LOCALIZER_ERROR) ||
           error_state.error_code ==
               static_cast<uint16_t>(amr_diagnostic::LocalizerNodeStatus::
                                         LOCALIZER_INIT_POSE_ERROR))) {
        has_local_init_warn = true;
        indicator_.localizer_init_error = true;
      }

      // 行人识别
      if (error_state.id == amr_topic::kAvoidDiagnosticTopic &&
          (error_state.error_code ==
           static_cast<uint16_t>(
               amr_diagnostic::AvoidNodeStatus::PEDERSTRAIN_WARING))) {
        has_pederstrain_warn = true;
        indicator_.pederstrain_waring = true;
      }

      if (error_state.id == amr_topic::kAvoidDiagnosticTopic &&
          (error_state.error_code ==
           static_cast<uint16_t>(
               amr_diagnostic::AvoidNodeStatus::DATA_TIME_OUT))) {
        has_avoid_date_timeout_warn = true;
        indicator_.avoid_sensor_timeout_error = true;
        for (auto &info : error_state.error_info) {
          if (info.error_info ==
                  static_cast<float>(AvoidLevel::AVOID_CAMERA_1_TIMEOUT) ||
              info.error_info ==
                  static_cast<float>(AvoidLevel::AVOID_CAMERA_3_TIMEOUT) ||
              info.error_info ==
                  static_cast<float>(AvoidLevel::AVOID_CAMERA_4_TIMEOUT)) {
            AddErrorLevelData(static_cast<uint32_t>(AgvErrorType::NONE),
                              static_cast<uint16_t>(AgvErrorLevel::FATAL));
          }
        }
      }

      // 非法二维码
      if (error_state.id == amr_topic::kLocalizerDiagnosticTopic &&
          (error_state.error_code ==
           static_cast<uint16_t>(
               amr_diagnostic::LocalizerNodeStatus::ILLEGAL_QR_TAG_ERROR))) {
        has_local_warn = true;
        AddErrorLevelData(static_cast<uint32_t>(AgvErrorType::NONE),
                          static_cast<uint16_t>(AgvErrorLevel::FATAL));
        indicator_.localizer_match_error = true;
      }

      // 扫码相机错误
      if (error_state.id == amr_topic::kLocalizerDiagnosticTopic &&
          (error_state.error_code ==
           static_cast<uint16_t>(
               amr_diagnostic::LocalizerNodeStatus::UP_QR_CAMERA_ERROR))) {
        has_up_qr_camera_err = true;
        // AddErrorLevelData(static_cast<uint16_t>(AgvErrorLevel::FATAL));
        indicator_.up_qr_camera_error = true;
      }

      if (error_state.id == amr_topic::kLocalizerDiagnosticTopic &&
          (error_state.error_code ==
           static_cast<uint16_t>(
               amr_diagnostic::LocalizerNodeStatus::DOWN_QR_CAMERA_ERROR))) {
        has_down_qr_camera_err = true;
        // AddErrorLevelData(static_cast<uint16_t>(AgvErrorLevel::FATAL));
        indicator_.down_qr_camera_error = true;
      }

      if (error_state.id == amr_topic::kLocalizerDiagnosticTopic &&
          (error_state.error_code ==
           static_cast<uint16_t>(
               amr_diagnostic::LocalizerNodeStatus::GET_VELOCITY_ERROR))) {
        has_velocity_err = true;
        AddErrorLevelData(static_cast<uint32_t>(AgvErrorType::NONE),
                          static_cast<uint16_t>(AgvErrorLevel::FATAL));
        LOG_ERROR_THROTTLE(0.5, "get_velocity_error!!!");
        indicator_.get_velocity_error = true;
      }

      if (error_state.id == amr_topic::kNavigationDiagnosticTopic &&
          error_state.error_code ==
              static_cast<uint16_t>(
                  amr_diagnostic::NavigationNodeStatus::OUT_OF_THE_ROUTE)) {
        has_navi_warn = true;
        indicator_.navi_error = true;
      }

      if ((error_state.id == amr_topic::kNavigationDiagnosticTopic &&
               error_state.error_code ==
                   static_cast<uint16_t>(
                       amr_diagnostic::NavigationNodeStatus::SHELF_LOSS) ||
           error_state.id == amr_topic::kActionDiagnosticTopic &&
               error_state.error_code ==
                   static_cast<uint16_t>(
                       amr_diagnostic::ActionNodeStatus::SHELF_LOSS))) {
        has_shelf_warn = true;
        indicator_.shelf_loss_error = true;
      }

      if (error_state.id == amr_topic::kNavigationDiagnosticTopic &&
          error_state.error_code ==
              static_cast<uint16_t>(
                  amr_diagnostic::NavigationNodeStatus::DOWN_TAG_LOSS)) {
        indicator_.down_tag_loss_error = true;
        has_down_tag_loss = true;
      }

      if (error_state.id == amr_topic::kNavigationDiagnosticTopic &&
          error_state.error_code ==
              static_cast<uint16_t>(
                  amr_diagnostic::NavigationNodeStatus::UP_TAG_LOSS)) {
        indicator_.up_tag_loss_error = true;
        has_up_tag_loss = true;
      }

      if (error_state.id == amr_topic::kNavigationDiagnosticTopic &&
          error_state.error_code ==
              static_cast<uint16_t>(
                  amr_diagnostic::NavigationNodeStatus::DOCKING_TIMEOUT)) {
        indicator_.docking_time_out_error = true;
        // AddErrorLevelData(static_cast<uint16_t>(AgvErrorLevel::FATAL));
        has_docking_time_out_err = true;
      }

      if (error_state.id == amr_topic::kNavigationDiagnosticTopic &&
          error_state.error_code ==
              static_cast<uint16_t>(
                  amr_diagnostic::NavigationNodeStatus::STABILIZE_TIMEOUT)) {
        indicator_.stabilize_time_out_error = true;
        // AddErrorLevelData(static_cast<uint16_t>(AgvErrorLevel::FATAL));
        has_stabilize_time_out_err = true;
      }

      if (error_state.id == amr_topic::kNavigationDiagnosticTopic &&
          error_state.error_code ==
              static_cast<uint16_t>(
                  amr_diagnostic::NavigationNodeStatus::PALLET_LIMIT_ERROR)) {
        has_pallet_back_limit = true;
        indicator_.pallet_limit_error = true;
      }

      if (error_state.id == amr_topic::kActionDiagnosticTopic &&
          error_state.error_code ==
              static_cast<uint16_t>(
                  amr_diagnostic::ActionNodeStatus::PALLET_DETECT_ERROR)) {
        has_pallet_detect_warn = true;
        indicator_.pallet_detect_error = true;
      }

      if (error_state.id == amr_topic::kActionDiagnosticTopic &&
          error_state.error_code ==
              static_cast<uint16_t>(amr_diagnostic::ActionNodeStatus::
                                        EXCEPTION_NO_PALLET_ERR)) {
        has_pallet_detect_warn = true;
        indicator_.pallet_detect_error = true;
      }

      if (error_state.id == amr_topic::kActionDiagnosticTopic &&
          error_state.error_code ==
              static_cast<uint16_t>(
                  amr_diagnostic::ActionNodeStatus::UP_WEIGHT_CHECK_ERROR)) {
        has_weight_check_warn = true;
        indicator_.up_weight_check_error = true;
      }

      if (error_state.id == amr_topic::kActionDiagnosticTopic &&
          error_state.error_code ==
              static_cast<uint16_t>(
                  amr_diagnostic::ActionNodeStatus::PALLET_LIMIT_ERROR)) {
        has_pallet_back_limit = true;
        indicator_.pallet_limit_error = true;
      }

      if (error_state.id == amr_topic::kActionDiagnosticTopic &&
          error_state.error_code ==
              static_cast<uint16_t>(amr_diagnostic::ActionNodeStatus::
                                        DOWN_WEIGHT_CHECK_ERROR)) {
        has_weight_check_warn = true;
        indicator_.down_weight_check_error = true;
      }

      if (error_state.id == amr_topic::kActionDiagnosticTopic &&
          error_state.error_code ==
              static_cast<uint16_t>(
                  amr_diagnostic::ActionNodeStatus::ACTION_TIME_OUT)) {
        has_action_time_out_err = true;

        indicator_.action_time_out_error = true;
      }

      if (error_state.id == amr_topic::kEmbeddedDiagnosticTopic &&
          error_state.error_code ==
              static_cast<uint16_t>(
                  amr_diagnostic::EmbeddedNodeStatus::DRIVER_NOT_READY)) {
        AddErrorLevelData(static_cast<uint32_t>(AgvErrorType::DRIVER_NOT_READY),
                          static_cast<uint16_t>(AgvErrorLevel::SERIOUS_ERROR));
        has_embedded_driver_warn = true;
        indicator_.embedded_driver_error = true;
      }
    }

    // 判断必要节点是否存活
    if (!CheckNodesAlive(error))
      AddErrorLevelData(static_cast<uint32_t>(AgvErrorType::NONE),
                        static_cast<uint16_t>(AgvErrorLevel::FATAL));

    if (!has_local_warn) indicator_.localizer_match_error = false;

    if (!has_local_init_warn) indicator_.localizer_init_error = false;
    // 没有导航错误 错误清空
    if (!has_navi_warn) indicator_.navi_error = false;

    if (!has_shelf_warn) indicator_.shelf_loss_error = false;

    if (!has_down_tag_loss) indicator_.down_tag_loss_error = false;

    if (!has_up_tag_loss) indicator_.up_tag_loss_error = false;

    if (!has_docking_time_out_err) indicator_.docking_time_out_error = false;
    if (!has_stabilize_time_out_err)
      indicator_.stabilize_time_out_error = false;
    if (!has_action_time_out_err) indicator_.action_time_out_error = false;

    if (!has_down_qr_camera_err) indicator_.down_qr_camera_error = false;

    if (!has_up_qr_camera_err) indicator_.up_qr_camera_error = false;

    if (!has_velocity_err) indicator_.get_velocity_error = false;

    if (!has_pederstrain_warn) indicator_.pederstrain_waring = false;

    if (!has_pallet_detect_warn) indicator_.pallet_detect_error = false;

    if (!has_embedded_driver_warn) {
      indicator_.embedded_driver_error = false;
      AddErrorLevelData(static_cast<uint32_t>(AgvErrorType::DRIVER_NOT_READY),
                        static_cast<uint16_t>(AgvErrorLevel::NONE));
    }

    if (!has_weight_check_warn) indicator_.down_weight_check_error = false;

    if (!has_avoid_date_timeout_warn)
      indicator_.avoid_sensor_timeout_error = false;
    if (!has_pallet_back_limit) indicator_.pallet_limit_error = false;
  }

  void AddErrorLevelData(uint32_t error_type, uint16_t error_level) {
    // FATAL 无法外部恢复 只有手动切换恢复
    if (event_ptr_->agv_error_level == AgvErrorLevel::FATAL ||
        AgvErrorLevel::FATAL == (AgvErrorLevel)error_level) {
      event_ptr_->agv_error_type = 0;
      event_ptr_->agv_error_level = AgvErrorLevel::FATAL;
      return;
    }

    if (AgvErrorLevel::SERIOUS_ERROR == (AgvErrorLevel)error_level) {
      event_ptr_->agv_error_type |= error_type;
      event_ptr_->agv_error_level = (AgvErrorLevel)error_level;
      return;
    }

    if (AgvErrorLevel::SERIOUS_ERROR == event_ptr_->agv_error_level) {
      event_ptr_->agv_error_type &= ~error_type;
      if (0 == event_ptr_->agv_error_type) {
        event_ptr_->agv_error_level = (AgvErrorLevel)error_level;
      }
      return;
    }
    event_ptr_->agv_error_level = (AgvErrorLevel)error_level;
  }

  void AddSafetyStateData(
      const amr_msgs::safety_state::ConstPtr &safety_state) {
    safety_state_.type = (AvoidLevel)safety_state->avoid_type;
    safety_state_.level = (AvoidSpeedLevel)safety_state->avoid_level;
  }

  void AddSafetyIoStateData(
      const amr_msgs::safety_io_state::ConstPtr &safety_io_state) {
    safety_io_state_ = (AvoidLevel)safety_io_state->avoid_io_state;
    static ros::Time bump_start_time;
    if (safety_io_state_ == AvoidLevel::BUMP) {
      indicator_.bummp_error = true;
      bump_start_time = ros::Time::now();
      AddErrorLevelData(static_cast<uint32_t>(AgvErrorType::BUMP),
                        static_cast<uint16_t>(AgvErrorLevel::SERIOUS_ERROR));
    }
    // 防撞条触发错误状态仅维持5s
    if (indicator_.bummp_error &&
        ros::Time::now() - bump_start_time > ros::Duration(5.0)) {
      indicator_.bummp_error = false;
      AddErrorLevelData(static_cast<uint32_t>(AgvErrorType::BUMP),
                        static_cast<uint16_t>(AgvErrorLevel::NONE));
    }
  }

  void AddChargeDoStateData(
      const amr_msgs::charge_do_state::ConstPtr &charge_do_state) {
    charge_do_state_ = charge_do_state->charge_do_state;
    event_ptr_->charging = charge_do_state_;
  }

  void AddControlRequestData(
      const amr_msgs::task_control_request::ConstPtr &control_request) {
    event_ptr_->task_control = (TaskControlType)control_request->control_type;
  }

  void AddControlAudioRequestData(
      const amr_msgs::task_control_audio_request::ConstPtr &control_request) {
    event_ptr_->task_audio.audio_type = (AudioType)control_request->audio_type;
    event_ptr_->task_audio.enable = control_request->enable;
  }

  void AddManualData(const amr_msgs::manual::ConstPtr &manual) {
    event_ptr_->manual = manual->mode;
    if (event_ptr_->manual) event_ptr_->close_check_weight = false;
  }

  void AddEmergencyFlag(const amr_msgs::emergency::ConstPtr &emergency) {
    if (emergency->flag) {
      event_ptr_->emergency_stop = emergency->flag;
    }
  }

  void AddCommunocateStateData(bool state) { communicate_online_ = state; }

  void AddPlateWeightData(uint32_t weight) {
    event_ptr_->load_weight = weight;

    auto weight_option_ = option_.fork_lift_logic_option;
    // event_ptr_->close_check_weight = true;

    if (event_ptr_->close_check_weight && event_ptr_->check_fork_state &&
        (weight_option_.enable_lose_pallet_check &&
         event_ptr_->heap_load_state == LoadStateType::ON_LOAD) &&
        (event_ptr_->load_weight_base - event_ptr_->load_weight >
         static_cast<int>(weight_option_.klost_weighing_threshold))) {
      indicator_.error_code = StateErrorType::LOST_PALLET;
      ErrorData::get()->SetError(ErrorType::LOST_GOODS);
      // event_ptr_->task_control = TaskControlType::EMERGENCY_STOP;
      event_ptr_->agv_error_level = AgvErrorLevel::FATAL;
      LOG_ERROR_STREAM_THROTTLE(
          1, "load_weight_base: "
                 << event_ptr_->load_weight_base << ", load_weight: "
                 << event_ptr_->load_weight << ", klost_weighing_threshold: "
                 << weight_option_.klost_weighing_threshold);
    }
  }

  void AddForkliftHeightData(uint32_t height) {
    event_ptr_->forklift_height = height;
  }

  void AddPalletCenterData(
      const amr_msgs::pallet_center_feedback::ConstPtr &center) {
    event_ptr_->pallet_center.time = ros::Time::now();
    event_ptr_->pallet_center.pallet_center_pose =
        Pose(center->pose.x, center->pose.y, center->pose.theta);
    event_ptr_->pallet_center.height = center->height;
  }

  void AddRelocationData(const amr_msgs::re_location::ConstPtr &re_location) {
    if (!event_ptr_->re_location_state_ptr) return;
    event_ptr_->re_location_state_ptr->set_state(1);
    event_ptr_->re_location_state_ptr->set_start_time(ros::Time::now());
    event_ptr_->re_location_state_ptr->set_trigger(true);
    // TODO(@ssh) Refactor!!!
    indicator_.current_map_id = re_location->map_id;
    indicator_.current_section_id = re_location->section_id;
    ReWriteSectionId2Config(re_location->section_id);
    indicator_.finish_location_request = true;
    indicator_.localizer_init_error = false;
    event_ptr_->agv_error_level = AgvErrorLevel::NONE;
    indicator_.error_code = StateErrorType::NONE;
  }

  void AddWeightBaseData(
      const amr_msgs::weighting_loaded::ConstPtr &weightdc) {
    event_ptr_->close_check_weight = weightdc->close_check_weight;
    event_ptr_->load_weight_base = weightdc->load_weight_base;
    event_ptr_->heap_load_state =
        static_cast<LoadStateType>(weightdc->load_state);
  }

  void AddBumpResetData(const amr_msgs::bump_reset::ConstPtr &bump_reset) {
    if (bump_reset->state) {
      indicator_.bummp_error = false;
      event_ptr_->emergency_stop = false;
      event_ptr_->agv_error_type = 0;
      event_ptr_->agv_error_level = AgvErrorLevel::NONE;
      indicator_.error_code = StateErrorType::NONE;
    }
  }

  void AddQrCodeData(uint64_t num) { event_ptr_->qr_num_ = num; }

  void ResetTimedVariable();

  inline ErrorType GetError() { return ErrorData::get()->error(); }

  void ClearError() { ErrorData::get()->ClearError(); }

  inline const std::shared_ptr<TaskManager> TaskManagerPtr() {
    return task_manager_ptr_;
  }

  OdomInfo GetOdomInfo() {
    OdomInfo odom_info;
    odom_info = odom_collector_.GetOdomInfo();
    // 上报给调度后 需要情况odom数据
    odom_collector_.ResetOdom();
    return odom_info;
  }

 private:
  void ProcessResponse();
  void LedAudioProcess();
  bool ComputeDongleAlive();

  void FlushReport();
  AudioType ChooseAudioAvoidType(const AvoidLevel &avoid_type);

  AudioMixLed AudioAndCorningLed(const bool &need_next_bspline);
  std::shared_ptr<TaskManager> task_manager_ptr_;
  std::shared_ptr<ClientManager> client_manager_ptr_;
  std::shared_ptr<AGVModel> agv_model_ptr_;

  // 只是改变灯的颜色，音乐类型
  // 避障状态
  SafetyState safety_state_;
  // led 颜色
  LedType led_state_;
  // 不同部位避障情况，用于音频
  AvoidLevel safety_io_state_;
  bool communicate_online_;
  // 音乐类型
  AudioStateType audio_state_;
  // 电池电量百分比
  uint8_t battery_;
  // 当前agv运行速度
  Cmd feedback_cmd_;

  bool charge_do_state_;

  // task_request, control_request响应
  ResponseType response_state_;
  // 状态机状态
  std::shared_ptr<AGVState> state_;
  // 内部信号
  IndicatorType indicator_;
  // 外部事件: 手自动信号，控制信号，载货状态，超时时间，结束任务响应
  std::shared_ptr<Event> event_ptr_;
  // 状态机参数
  LogicOption option_;
  // 当前车的信息
  ReportType report_;

  // 添加任务需上锁
  std::mutex task_mutex_;

  // 添加错误需上锁
  std::mutex error_mutex_;
  // 错误码信息

  ros::Time error_node_alive_time_;
  bool error_code_start_;
  amr_msgs::fault_report error_code_;  // 错误码表: 错误编号 + 错误码

  ros::Time count_time_;
  DongleData from_dongle_data_;
  DongleData to_dispatch_data_;
  bool dongle_has_feed_dog_;
  std::shared_ptr<DongleInterface> dongle_ptr_;
  // 超时变量管理容器
  std::vector<std::shared_ptr<TimedManagerState>> timed_state_vec_;

  OdomCollector odom_collector_;
};  // namespace decision_maker

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_DECISION_H_
