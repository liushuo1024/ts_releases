/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_AGV_INTERFACE_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_AGV_INTERFACE_H_
#include "amr_msgs/switch_map.h"
#include "amr_msgs/track_pathAction.h"
#include "decision_maker/action_client.h"
#include "decision_maker/client_manager.h"
#include "decision_maker/decision_maker_enum.h"
#include "decision_maker/logic_options.h"
#include "decision_maker/openloop_client.h"
#include "decision_maker/task_manager.h"
#include "ros/ros.h"

namespace decision_maker {
struct MixGoal {
  GoalType g_type;
  amr_msgs::track_pathGoal t_goal;
  amr_msgs::agv_actionGoal a_goal;
  bool operator==(const MixGoal& goal) {
    if (static_cast<uint32_t>(this->g_type) !=
        static_cast<uint32_t>(goal.g_type))
      return false;
    if (this->t_goal.end_id != goal.t_goal.end_id) return false;

    if (this->a_goal.action_type != goal.a_goal.action_type ||
        this->a_goal.action_value != goal.a_goal.action_value)
      return false;
    return true;
  }
};

class AGVState;
class AGVModel;

class AGVState {
 public:
  explicit AGVState(AgvStateType s) : state_(s) {}
  virtual ~AGVState() {}
  AgvStateType State() { return state_; }

  virtual std::shared_ptr<AGVState> handle(std::shared_ptr<TaskManager> tm,
                                           std::shared_ptr<ClientManager> cm,
                                           std::shared_ptr<AGVModel> am,
                                           std::shared_ptr<Event> event,
                                           IndicatorType* indicate,
                                           const LogicOption option) = 0;

  static bool start_timer_;
  static bool init_state_finish_;

 private:
  AgvStateType state_;
};

class AGVModel {
 public:
  AGVModel() : load_state_(0) {}
  virtual ~AGVModel() {}
  virtual std::shared_ptr<AGVState> LogicHandle(
      std::shared_ptr<TaskManager> tm, std::shared_ptr<ClientManager> cm,
      std::shared_ptr<Event> event, IndicatorType* indicator,
      const LogicOption option) = 0;
  void SetLoadState(uint32_t state) { load_state_ = state; }
  uint32_t GetLoadState() { return load_state_; }
  virtual void ResetState() = 0;
  uint32_t load_state_;
};

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_AGV_INTERFACE_H_
