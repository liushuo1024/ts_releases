/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_AGV_STATE_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_AGV_STATE_H_
#include "amr_msgs/switch_map.h"
#include "amr_msgs/track_pathAction.h"
#include "decision_maker/action_client.h"
#include "decision_maker/agv_interface.h"
#include "decision_maker/client_manager.h"
#include "decision_maker/decision_maker_enum.h"
#include "decision_maker/openloop_client.h"
#include "decision_maker/task_manager.h"
#include "ros/ros.h"

namespace decision_maker {

class Manual;
class Waiting;
class LowPowerMode;
class Doing;
class Finishing;
class Pause;
class Charging;
class Error;
class Fault;
class EmergencyPause;
class PoweronInit;

class Manual : public AGVState {
 public:
  Manual() : AGVState(AgvStateType::MANUAL) {}
  std::shared_ptr<AGVState> handle(std::shared_ptr<TaskManager> tm,
                                   std::shared_ptr<ClientManager> cm,
                                   std::shared_ptr<AGVModel> am,
                                   std::shared_ptr<Event> event,
                                   IndicatorType* indicate,
                                   const LogicOption option) override;
};

class Waiting : public AGVState {
 public:
  Waiting() : AGVState(AgvStateType::WAITING), last_time_(0) {}
  std::shared_ptr<AGVState> handle(std::shared_ptr<TaskManager> tm,
                                   std::shared_ptr<ClientManager> cm,
                                   std::shared_ptr<AGVModel> am,
                                   std::shared_ptr<Event> event,
                                   IndicatorType* indicate,
                                   const LogicOption option) override;

 private:
  ros::Time last_time_;
};

class EmergencyStop : public AGVState {
 public:
  EmergencyStop() : AGVState(AgvStateType::EMERGENCY_STOP), last_time_(0) {}
  std::shared_ptr<AGVState> handle(std::shared_ptr<TaskManager> tm,
                                   std::shared_ptr<ClientManager> cm,
                                   std::shared_ptr<AGVModel> am,
                                   std::shared_ptr<Event> event,
                                   IndicatorType* indicate,
                                   const LogicOption option) override;

 private:
  ros::Time last_time_;
};

class LowPowerMode : public AGVState {
 public:
  LowPowerMode() : AGVState(AgvStateType::LOWPOWERMODE) {}
  std::shared_ptr<AGVState> handle(std::shared_ptr<TaskManager> tm,
                                   std::shared_ptr<ClientManager> cm,
                                   std::shared_ptr<AGVModel> am,
                                   std::shared_ptr<Event> event,
                                   IndicatorType* indicate,
                                   const LogicOption option) override;
};

class Doing : public AGVState {
 public:
  Doing() : AGVState(AgvStateType::DOING), openloop_(false) {}
  std::shared_ptr<AGVState> handle(std::shared_ptr<TaskManager> tm,
                                   std::shared_ptr<ClientManager> cm,
                                   std::shared_ptr<AGVModel> am,
                                   std::shared_ptr<Event> event,
                                   IndicatorType* indicate,
                                   const LogicOption option) override;

 private:
  bool openloop_;
};

class Finishing : public AGVState {
 public:
  Finishing() : AGVState(AgvStateType::FINISHING), last_time_(0) {}
  std::shared_ptr<AGVState> handle(std::shared_ptr<TaskManager> tm,
                                   std::shared_ptr<ClientManager> cm,
                                   std::shared_ptr<AGVModel> am,
                                   std::shared_ptr<Event> event,
                                   IndicatorType* indicate,
                                   const LogicOption option) override;

 private:
  ros::Time last_time_;
};

class Pause : public AGVState {
 public:
  Pause() : AGVState(AgvStateType::PAUSE) {}
  std::shared_ptr<AGVState> handle(std::shared_ptr<TaskManager> tm,
                                   std::shared_ptr<ClientManager> cm,
                                   std::shared_ptr<AGVModel> am,
                                   std::shared_ptr<Event> event,
                                   IndicatorType* indicate,
                                   const LogicOption option) override;
};

class EmergencyPause : public AGVState {
 public:
  EmergencyPause() : AGVState(AgvStateType::EMERGENCY_PAUSE) {}
  std::shared_ptr<AGVState> handle(std::shared_ptr<TaskManager> tm,
                                   std::shared_ptr<ClientManager> cm,
                                   std::shared_ptr<AGVModel> am,
                                   std::shared_ptr<Event> event,
                                   IndicatorType* indicate,
                                   const LogicOption option) override;
};

class Charging : public AGVState {
 public:
  Charging() : AGVState(AgvStateType::CHARGING) {}
  std::shared_ptr<AGVState> handle(std::shared_ptr<TaskManager> tm,
                                   std::shared_ptr<ClientManager> cm,
                                   std::shared_ptr<AGVModel> am,
                                   std::shared_ptr<Event> event,
                                   IndicatorType* indicate,
                                   const LogicOption option) override;
};

class Error : public AGVState {
 public:
  Error() : AGVState(AgvStateType::ERROR) {}
  std::shared_ptr<AGVState> handle(std::shared_ptr<TaskManager> tm,
                                   std::shared_ptr<ClientManager> cm,
                                   std::shared_ptr<AGVModel> am,
                                   std::shared_ptr<Event> event,
                                   IndicatorType* indicate,
                                   const LogicOption option) override;
};

class Fault : public AGVState {
 public:
  Fault() : AGVState(AgvStateType::FAULT) {}
  std::shared_ptr<AGVState> handle(std::shared_ptr<TaskManager> tm,
                                   std::shared_ptr<ClientManager> cm,
                                   std::shared_ptr<AGVModel> am,
                                   std::shared_ptr<Event> event,
                                   IndicatorType* indicate,
                                   const LogicOption option) override;
};

class PoweronInit : public AGVState {
 public:
  PoweronInit()
      : AGVState(AgvStateType::POWERON_SHAKING),
        init_start_time_(ros::Time::now()) {}
  std::shared_ptr<AGVState> handle(std::shared_ptr<TaskManager> tm,
                                   std::shared_ptr<ClientManager> cm,
                                   std::shared_ptr<AGVModel> am,
                                   std::shared_ptr<Event> event,
                                   IndicatorType* indicate,
                                   const LogicOption option) override;

 private:
  ros::Time init_start_time_;
  ros::Time last_time_;
};

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_AGV_STATE_H_
