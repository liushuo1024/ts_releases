/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_STEP_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_STEP_H_
#include <ros/ros.h>

#include <string>

#include "amr_common/geometry/amr_geometry.h"
#include "decision_maker/decision_maker_enum.h"

namespace decision_maker {
using AgvTaskOperationType = dispacth::AgvTaskOperationType;
using NaviType = dispacth::NaviType;
using StepType = dispacth::StepType;
using PathType = dispacth::PathType;
using MoveType = dispacth::MoveType;

using Point = amr_geometry::Point;
using Pose = amr_geometry::Pose;

struct AdjustSpeedPose {
  bool need_adjust;
  double adjust_speed;
  Pose adjust_pose;
  AgvTaskOperationType operation_type;
  AdjustSpeedPose()
      : need_adjust(false),
        adjust_speed(0.0),
        adjust_pose(Pose()),
        operation_type(AgvTaskOperationType::NONE) {}
};

struct HighPrecisionPose {
  bool need;
  Pose high_precision_pose;
  HighPrecisionPose() : need(false), high_precision_pose(Pose()) {}
};

struct NextOperationType {
  bool need;
  AgvTaskOperationType type;
  NextOperationType() : need(false), type(AgvTaskOperationType::NONE) {}
};

class Step {
 public:
  /**
   * \brief default constuctor of step
   */
  Step()
      : sequence_id_(0),
        navi_type_(NaviType::NONE),
        step_type_(StepType::NONE),
        move_type_(MoveType::NONE),
        path_type_(PathType::NONE),
        node_id_("0"),
        point_id_(0),
        point_(Point(0.0, 0.0)),
        point_yaw_(0.0),
        plate_relative_(0),
        plate_angle_(0.0),
        plate_weight_(0.0),
        control_point0_(Point(0.0, 0.0)),
        control_point1_(Point(0.0, 0.0)),
        current_sec_id_(0),
        target_sec_id_(0),
        switch_point_id_(0),
        switch_point_(Point(0.0, 0.0)),
        switch_point_yaw_(0),
        speed_(0),
        odom_(0),
        avoid_strategy_code_(0),
        ultrasonic_obstacle_(0),
        operation_type_(AgvTaskOperationType::REST),
        operation_value_(0),
        adjust_speed_pose_(AdjustSpeedPose()) {}

  /**
   * \brief default setter of private variable
   */
  inline void set_sequence_id(int32_t id) { sequence_id_ = id; }
  inline void set_navi_type(NaviType type) { navi_type_ = type; }
  inline void set_step_type(StepType type) { step_type_ = type; }
  inline void set_move_type(MoveType type) { move_type_ = type; }
  inline void set_path_type(PathType type) { path_type_ = type; }
  inline void set_node_id(std::string node_id) { node_id_ = node_id; }
  inline void set_point_id(int32_t id) { point_id_ = id; }
  inline void set_point(const Point &pt) { point_ = pt; }
  inline void set_point_yaw(float yaw) { point_yaw_ = yaw; }
  inline void set_plate_relative(float relative) { plate_relative_ = relative; }
  inline void set_plate_angle(float angle) { plate_angle_ = angle; }
  inline void set_plate_weight(float weight) { plate_weight_ = weight; }
  void set_control_point(const Point &pt0, const Point &pt1) {
    control_point0_ = pt0;
    control_point1_ = pt1;
  }
  inline void set_current_sec_id(int32_t id) { current_sec_id_ = id; }
  inline void set_target_sec_id(int32_t id) { target_sec_id_ = id; }
  inline void set_switch_point_id(int32_t id) { switch_point_id_ = id; }
  inline void set_switch_point(const Point &pt) { switch_point_ = pt; }
  inline void set_switch_point_yaw(int32_t id) { switch_point_yaw_ = id; }
  inline void set_max_speed(double speed) { speed_ = speed; }
  inline void set_odom(double odom) { odom_ = odom; }
  inline void set_avoid_strategy_code(int32_t code) {
    avoid_strategy_code_ = code;
  }
  inline void set_ultrasonic_obstacle(int32_t code) {
    ultrasonic_obstacle_ = code;
  }

  inline void set_adjust_speed_pose(AdjustSpeedPose pose) {
    adjust_speed_pose_ = pose;
  }

  inline void set_start_pose(const Pose &pose) { start_pose_ = pose; }

  inline void set_high_precision_pose(const HighPrecisionPose &pose) {
    high_precision_pose_ = pose;
  }

  inline void set_remain_distance(const double &dist) {
    remain_distance_ = dist;
  }

  void set_operation(AgvTaskOperationType type, double value) {
    operation_type_ = type;
    operation_value_ = value;
  }

  /**
   * \brief default getter of private variable
   */
  inline int32_t sequence_id() const { return sequence_id_; }
  inline NaviType navi_type() const { return navi_type_; }
  inline StepType step_type() const { return step_type_; }
  inline MoveType move_type() const { return move_type_; }
  inline PathType path_type() const { return path_type_; }
  inline std::string node_id() const { return node_id_; }
  inline int32_t point_id() const { return point_id_; }
  inline const Point &point() const { return point_; }
  inline float point_yaw() const { return point_yaw_; }
  inline int32_t plate_relative() const { return plate_relative_; }
  inline float plate_angle() const { return plate_angle_; }
  inline float plate_weight() const { return plate_weight_; }
  inline const Point control_point_0() const { return control_point0_; }
  inline const Point control_point_1() const { return control_point1_; }
  inline int32_t current_sec_id() const { return current_sec_id_; }
  inline int32_t target_sec_id() const { return target_sec_id_; }
  inline int32_t switch_point_id() const { return switch_point_id_; }
  inline const Point &switch_point() const { return switch_point_; }
  inline float switch_point_yaw() const { return switch_point_yaw_; }
  inline double odom() const { return odom_; }
  inline double speed() const { return speed_; }
  inline int32_t avoid_strategy_code() const { return avoid_strategy_code_; }
  inline int32_t ultrasonic_obstacle() const { return ultrasonic_obstacle_; }
  inline AgvTaskOperationType operation_type() const { return operation_type_; }
  inline double operation_value() const { return operation_value_; }
  inline AdjustSpeedPose adjust_speed_pose() const {
    return adjust_speed_pose_;
  }
  inline Pose start_pose() const { return start_pose_; }
  inline HighPrecisionPose high_precision_pose() const {
    return high_precision_pose_;
  }
  inline double remain_distance() const { return remain_distance_; }

 private:
  int32_t sequence_id_;
  NaviType navi_type_;
  StepType step_type_;
  MoveType move_type_;
  PathType path_type_;
  std::string node_id_;
  int32_t point_id_;
  AdjustSpeedPose adjust_speed_pose_;
  Pose start_pose_;
  double remain_distance_;
  HighPrecisionPose high_precision_pose_;

  Point point_;
  float point_yaw_;
  int32_t plate_relative_;
  float plate_angle_;
  float plate_weight_;
  Point control_point0_;
  Point control_point1_;
  int current_sec_id_;
  int target_sec_id_;
  int switch_point_id_;

  Point switch_point_;
  float switch_point_yaw_;
  double speed_;
  double odom_;
  int32_t avoid_strategy_code_;
  int32_t ultrasonic_obstacle_;
  AgvTaskOperationType operation_type_;
  double operation_value_;
};

struct OperationStep {
  bool vaild;
  Step step;
  OperationStep() : vaild(false) {}
};

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_STEP_H_
