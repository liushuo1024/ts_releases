/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_AGV_MODEL_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_AGV_MODEL_H_
#include <deque>
#include <string>

#include "amr_common/amr_config_helper.h"
#include "amr_common/math.h"
#include "amr_common/util/json11.h"
#include "amr_common/util/local_service.h"
#include "amr_common/util/remote_service.h"
#include "decision_maker/agv_interface.h"

namespace decision_maker {
using MotionType = navigation::MotionType;

// 切换分区时，修改基础配置里的分区id
static bool ReQrWriteSectionId2Config(const int32_t& section_id) {
  std::string config_json_str;
  try {
    config_json_str = BasicConfigHelper::Instance().GetConfig(
        amr_config::ConfigType::AGV_BASIC_CONFIG);
  } catch (std::out_of_range& err) {
    LOG_WARN("invalid config file");
    LOG_WARN_STREAM(err.what()
                    << " file: " << __FILE__ << " line: " << __LINE__);
    return false;
  }
  size_t index = config_json_str.find("current_qr_section_id");
  LOG_WARN("index %d", index);
  bool is_find_symol1 = false;
  bool is_find_symol2 = false;
  bool is_find_symol3 = false;
  size_t section_id_base = 0;
  size_t section_id_offset = 0;
  ros::Time calculate_time = ros::Time::now();
  while (1) {
    // 超时退出循环
    if (ros::Time::now() - calculate_time > ros::Duration(5.0)) break;

    if (!is_find_symol1) {
      index++;
      is_find_symol1 = config_json_str[index] == ':' ? true : false;
      continue;
    }
    if (!is_find_symol2) {
      index++;
      is_find_symol2 = config_json_str[index] != ' ' ? true : false;
      section_id_base = is_find_symol2 == true ? index : section_id_base;
      continue;
    }
    if (!is_find_symol3) {
      index++;
      is_find_symol3 = config_json_str[index] == ',' ? true : false;
      section_id_offset = is_find_symol3 == true ? (index - section_id_base)
                                                 : section_id_offset;
      continue;
    }
    break;
  }
  std::stringstream ss_temp;
  ss_temp << section_id;
  std::string new_section_id_string = ss_temp.str();
  config_json_str.replace(section_id_base, section_id_offset,
                          new_section_id_string);
  LOG_WARN("section_id_base %d ,section_id_offset %d", section_id_base,
           section_id_offset);
  // 保存到本地
  BasicConfigHelper::Instance().SaveLocal(
      amr_config::ConfigType::AGV_BASIC_CONFIG, config_json_str);
}

static bool ReWriteSectionId2Config(const int32_t& section_id) {
  std::string config_json_str;
  try {
    config_json_str = BasicConfigHelper::Instance().GetConfig(
        amr_config::ConfigType::AGV_BASIC_CONFIG);
  } catch (std::out_of_range& err) {
    LOG_WARN("invalid config file");
    LOG_WARN_STREAM(err.what()
                    << " file: " << __FILE__ << " line: " << __LINE__);
    return false;
  }
  size_t index = config_json_str.find("current_reflector_section_id");
  LOG_WARN("index %d", index);
  bool is_find_symol1 = false;
  bool is_find_symol2 = false;
  bool is_find_symol3 = false;
  size_t section_id_base = 0;
  size_t section_id_offset = 0;
  ros::Time calculate_time = ros::Time::now();
  while (1) {
    // 超时退出循环
    if (ros::Time::now() - calculate_time > ros::Duration(5.0)) break;

    if (!is_find_symol1) {
      index++;
      is_find_symol1 = config_json_str[index] == ':' ? true : false;
      continue;
    }
    if (!is_find_symol2) {
      index++;
      is_find_symol2 = config_json_str[index] != ' ' ? true : false;
      section_id_base = is_find_symol2 == true ? index : section_id_base;
      continue;
    }
    if (!is_find_symol3) {
      index++;
      is_find_symol3 = config_json_str[index] == ',' ? true : false;
      section_id_offset = is_find_symol3 == true ? (index - section_id_base)
                                                 : section_id_offset;
      continue;
    }
    break;
  }

  std::stringstream ss_temp;
  ss_temp << section_id;
  std::string new_section_id_string = ss_temp.str();
  config_json_str.replace(section_id_base, section_id_offset,
                          new_section_id_string);
  LOG_WARN("section_id_base %d ,section_id_offset %d", section_id_base,
           section_id_offset);
  // 保存到本地
  BasicConfigHelper::Instance().SaveLocal(
      amr_config::ConfigType::AGV_BASIC_CONFIG, config_json_str);
}

class ForkLiftModel : public AGVModel {
 public:
  ForkLiftModel() : step_processed_(true), init_step_(true) {}
  ~ForkLiftModel() {}
  std::shared_ptr<AGVState> LogicHandle(std::shared_ptr<TaskManager> tm,
                                        std::shared_ptr<ClientManager> cm,
                                        std::shared_ptr<Event> event,
                                        IndicatorType* indicator,
                                        const LogicOption option) override;
  void ResetState() override {
    step_processed_ = true;
    init_step_ = true;
    step_goals_.clear();
  }

 private:
  // 根据next step任务类型生成goals
  bool ProcessStep(std::shared_ptr<TaskManager> tm,
                   std::shared_ptr<Event> event, IndicatorType* indicator,
                   const LogicOption option);

  StepFinishState AchieveNextStep(std::shared_ptr<ClientManager> cm);
  std::deque<MixGoal> step_goals_;
  MixGoal current_goal_;
  bool step_processed_;
  bool init_step_;
  bool carry_pallet_;
};

class XinMeiForkLiftModel : public AGVModel {
 public:
  XinMeiForkLiftModel() : step_processed_(true), init_step_(true) {}
  ~XinMeiForkLiftModel() {}
  std::shared_ptr<AGVState> LogicHandle(std::shared_ptr<TaskManager> tm,
                                        std::shared_ptr<ClientManager> cm,
                                        std::shared_ptr<Event> event,
                                        IndicatorType* indicator,
                                        const LogicOption option) override;
  void ResetState() override {
    step_processed_ = true;
    init_step_ = true;
    step_goals_.clear();
  }

 private:
  // 根据next step任务类型生成goals
  bool ProcessStep(std::shared_ptr<TaskManager> tm,
                   std::shared_ptr<Event> event, IndicatorType* indicator,
                   const LogicOption option);

  StepFinishState AchieveNextStep(std::shared_ptr<ClientManager> cm);
  std::deque<MixGoal> step_goals_;
  MixGoal current_goal_;
  bool step_processed_;
  bool init_step_;
  bool carry_pallet_;
};

class HeapForkLiftModel : public AGVModel {
 public:
  HeapForkLiftModel() { ros::NodeHandle nh; }
  ~HeapForkLiftModel() {}
  std::shared_ptr<AGVState> LogicHandle(std::shared_ptr<TaskManager> tm,
                                        std::shared_ptr<ClientManager> cm,
                                        std::shared_ptr<Event> event,
                                        IndicatorType* indicator,
                                        const LogicOption option) override;
  void ResetState() override {
    step_processed_ = true;
    init_step_ = true;
    step_goals_.clear();
  }

 private:
  StepFinishState AchieveNextStep(std::shared_ptr<ClientManager> cm);
  bool ProcessStep(std::shared_ptr<TaskManager> tm,
                   std::shared_ptr<Event> event, IndicatorType* indicator,
                   const LogicOption option);
  std::deque<MixGoal> step_goals_;
  MixGoal current_goal_;
  bool step_processed_;
  bool init_step_;
};

class ReachForkLiftModel : public AGVModel {
 public:
  ReachForkLiftModel() {}
  ~ReachForkLiftModel() {}
  std::shared_ptr<AGVState> LogicHandle(std::shared_ptr<TaskManager> tm,
                                        std::shared_ptr<ClientManager> cm,
                                        std::shared_ptr<Event> event,
                                        IndicatorType* indicator,
                                        const LogicOption option) override;
  void ResetState() override {
    step_processed_ = true;
    init_step_ = true;
    step_goals_.clear();
  }

 private:
  StepFinishState AchieveNextStep(std::shared_ptr<ClientManager> cm);
  bool ProcessStep(std::shared_ptr<TaskManager> tm,
                   std::shared_ptr<Event> event, IndicatorType* indicator,
                   const LogicOption option);
  std::deque<MixGoal> step_goals_;
  MixGoal current_goal_;
  bool step_processed_;
  bool init_step_;
};

// class ReachForkLiftModel : public AGVModel {
//  public:
//   ReachForkLiftModel() {}
//   ~ReachForkLiftModel() {}
//   std::shared_ptr<AGVState> LogicHandle(std::shared_ptr<TaskManager> tm,
//                                         std::shared_ptr<ClientManager> cm,
//                                         std::shared_ptr<Event> event,
//                                         IndicatorType* indicator,
//                                         const LogicOption option) override;
//   void ResetState() override {}
//   bool carry_pallet_;

//  private:
//   MotionType ParseMotionType(std::shared_ptr<TaskManager> tm);
// };

class JackUpModel : public AGVModel {
 public:
  JackUpModel() : step_processed_(true), init_step_(true) {}
  ~JackUpModel() {}
  std::shared_ptr<AGVState> LogicHandle(std::shared_ptr<TaskManager> tm,
                                        std::shared_ptr<ClientManager> cm,
                                        std::shared_ptr<Event> event,
                                        IndicatorType* indicator,
                                        const LogicOption option) override;
  void ResetState() override {
    step_processed_ = true;
    init_step_ = true;
    step_goals_.clear();
  }

 private:
  // MotionType ParseMotionType(std::shared_ptr<TaskManager> tm);
  // 根据next step任务类型生成goals
  bool ProcessStep(std::shared_ptr<TaskManager> tm,
                   std::shared_ptr<Event> event, IndicatorType* indicator,
                   const LogicOption option);

  StepFinishState AchieveNextStep(std::shared_ptr<ClientManager> cm);
  std::deque<MixGoal> step_goals_;
  MixGoal current_goal_;
  bool step_processed_;
  bool init_step_;
};

class LaserJackUpModel : public AGVModel {
 public:
  LaserJackUpModel() {}
  ~LaserJackUpModel() {}
  std::shared_ptr<AGVState> LogicHandle(std::shared_ptr<TaskManager> tm,
                                        std::shared_ptr<ClientManager> cm,
                                        std::shared_ptr<Event> event,
                                        IndicatorType* indicator,
                                        const LogicOption option) override;
  void ResetState() override {
    step_processed_ = true;
    init_step_ = true;
    step_goals_.clear();
  }

 private:
  MotionType ParseMotionType(std::shared_ptr<TaskManager> tm);
  bool ProcessStep(std::shared_ptr<TaskManager> tm,
                   std::shared_ptr<Event> event, IndicatorType* indicator,
                   const LogicOption option);

  std::deque<MixGoal> step_goals_;
  MixGoal current_goal_;
  bool step_processed_;
  bool init_step_;
};

class TransPlantModel : public AGVModel {
 public:
  TransPlantModel() {}
  ~TransPlantModel() {}

  std::shared_ptr<AGVState> LogicHandle(std::shared_ptr<TaskManager> tm,
                                        std::shared_ptr<ClientManager> cm,
                                        std::shared_ptr<Event> event,
                                        IndicatorType* indicator,
                                        const LogicOption option) override;
  void ResetState() override {
    step_processed_ = true;
    init_step_ = true;
    step_goals_.clear();
  }

 private:
  StepFinishState AchieveNextStep(std::shared_ptr<ClientManager> cm);
  bool ProcessStep(std::shared_ptr<TaskManager> tm,
                   std::shared_ptr<Event> event, IndicatorType* indicator,
                   const LogicOption option);
  std::deque<MixGoal> step_goals_;
  MixGoal current_goal_;
  bool step_processed_;
  bool init_step_;
};

class RollerModel : public AGVModel {
 public:
  RollerModel() : step_processed_(true), init_step_(true) {}
  ~RollerModel() {}
  std::shared_ptr<AGVState> LogicHandle(std::shared_ptr<TaskManager> tm,
                                        std::shared_ptr<ClientManager> cm,
                                        std::shared_ptr<Event> event,
                                        IndicatorType* indicator,
                                        const LogicOption option) override;
  void ResetState() override {
    step_processed_ = true;
    init_step_ = true;
    step_goals_.clear();
  }

 private:
  // MotionType ParseMotionType(std::shared_ptr<TaskManager> tm);
  // 根据next step任务类型生成goals
  bool ProcessStep(std::shared_ptr<TaskManager> tm,
                   std::shared_ptr<Event> event, IndicatorType* indicator,
                   const LogicOption option);

  StepFinishState AchieveNextStep(std::shared_ptr<ClientManager> cm);
  std::deque<MixGoal> step_goals_;
  MixGoal current_goal_;
  bool step_processed_;
  bool init_step_;
};

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_AGV_MODEL_H_
