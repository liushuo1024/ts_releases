/**
 * Copyright (c) 2020 amr Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_TASK_MANAGER_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_TASK_MANAGER_H_
#include <ros/ros.h>

#include <boost/shared_ptr.hpp>
#include <map>
#include <string>
#include <vector>

#include "amr_msgs/task_request.h"
#include "decision_maker/error_data.h"
#include "decision_maker/logic_options.h"
#include "decision_maker/step.h"

namespace decision_maker {

enum class TaskFinishRequestState { NONE = 0, FINISHING_TASK };
enum class TaskResponseState : int32_t {
  NONE = 0,
  ADD_TASK = 1,
  CANCEL_TASK = 2,
  CONTROL_TASK = 3
};

struct NextBsplineStepPair {
  bool vaild = false;
  Step first_step;
  Step second_step;
};

struct DispatchTaskEndpoint {
  bool end_ponit_vaild;
  Pose taks_end_pose;
  AgvTaskOperationType task_end_operation_type;
  double task_end_operation_value;
  DispatchTaskEndpoint()
      : end_ponit_vaild(false),
        task_end_operation_type(AgvTaskOperationType::NONE),
        task_end_operation_value(0.) {}
  void set(const bool& vaild, const Pose& pose,
           const AgvTaskOperationType& type, const double& value) {
    end_ponit_vaild = vaild;
    taks_end_pose = pose;
    task_end_operation_type = type;
    task_end_operation_value = value;
  }
};

class Task : public std::vector<Step> {
 public:
  Task() = delete;

  explicit Task(std::string id, int sequence_num, int step_size)
      : order_id_(id), sequence_num_(sequence_num), step_size_(step_size) {}
  inline std::string order_id() const { return order_id_; }
  inline int sequence_num() const { return sequence_num_; }
  inline void set_sequence_num(int num) { sequence_num_ = num; }

  std::string ToString() const {
    std::stringstream ss;
    ss << std::endl
       << "TASK: orderId: " << order_id_ << " , sequenceNum: " << sequence_num_
       << " , stepSize: " << step_size_ << std::endl;
    for (const auto& step : *this) {
      ss << "Step: { sequenceId: " << step.sequence_id()
         << ", naviType: " << static_cast<int32_t>(step.navi_type())
         << ", stepType: " << static_cast<int32_t>(step.step_type())
         << ", moveType: " << static_cast<int32_t>(step.move_type())
         << ", pathType: " << static_cast<int32_t>(step.path_type())
         << ", point_id: " << static_cast<int32_t>(step.point_id())
         << ", pose: "
         << "(" << step.point().x() << ", " << step.point().y() << ", "
         << step.point_yaw() << ")"
         << ", adjust_speed_pose: "
         << "(" << step.adjust_speed_pose().adjust_pose.x() << ", "
         << step.adjust_speed_pose().adjust_pose.y() << ", "
         << step.adjust_speed_pose().adjust_pose.yaw() << ")"
         << ", plate_relative: " << static_cast<int32_t>(step.plate_relative())
         << ", plate_angle: " << static_cast<float>(step.plate_angle())
         << ", control_point_0: "
         << "(" << static_cast<float>(step.control_point_0().x()) << ", "
         << static_cast<float>(step.control_point_0().y()) << ")"
         << ", control_point_1: "
         << "(" << static_cast<float>(step.control_point_1().x()) << ", "
         << static_cast<float>(step.control_point_1().y()) << ")"
         << ", current_sec_id: " << static_cast<int32_t>(step.current_sec_id())
         << ", target_sec_id: " << static_cast<int32_t>(step.target_sec_id())
         << ", switch_point_id: "
         << static_cast<int32_t>(step.switch_point_id()) << ", switch_point: "
         << "(" << step.switch_point().x() << ", " << step.switch_point().y()
         << ", " << step.switch_point_yaw() << ")"
         << ", odom: " << step.odom() << ", speed: " << step.speed()
         << ", avoid_strategy_code: "
         << static_cast<int32_t>(step.avoid_strategy_code())
         << ", enable_ultrasound: "
         << static_cast<int32_t>(step.ultrasonic_obstacle())
         << ", operationType: " << static_cast<int32_t>(step.operation_type())
         << ", operationValue: " << step.operation_value() << " }" << std::endl;
    }

    return ss.str();
  }

 private:
  std::string order_id_;
  int sequence_num_;
  int step_size_;
};

class TaskManager {
 public:
  explicit TaskManager(const LogicOption& option)
      : task_ptr_(nullptr),
        is_doing_task_(false),
        task_cancle_(false),
        pause_task_(false),
        agv_id_(" "),
        current_order_id_("0"),
        state_(AgvStateType::NONE),
        current_sequence_num_(0),
        appended_(false),
        option_(option) {}

  ~TaskManager() {}

  inline std::string TaskOrderId() { return current_order_id_; }

  inline const Step CurrentStep() const { return current_step_; }
  inline const Step NextStep() const { return next_step_; }
  inline const Step NextNextStep() const { return next_next_step_; }
  inline const Step FinalStep() const { return final_step_; }

  inline std::string order_id() const { return current_order_id_; }
  inline std::string agv_id() const { return agv_id_; }
  inline std::string task_id() const { return current_task_id_; }
  inline int task_type() const { return current_task_type_; }
  inline int sequence_num() const { return current_sequence_num_; }
  inline Cmd feedback_cmd() const { return feedback_cmd_; }
  inline DispatchTaskEndpoint task_endpoint() const { return task_endpoint_; }

  inline void set_agv_id(const std::string& id) { agv_id_ = id; }
  inline void set_order_id(const std::string& id) { current_order_id_ = id; }
  inline void set_task_id(const std::string& id) { current_task_id_ = id; }
  inline void set_task_type(int type) { current_task_type_ = type; }
  inline void set_sequence_num(int num) { current_sequence_num_ = num; }
  inline void set_feedback_cmd(Cmd feed_back) { feedback_cmd_ = feed_back; }

  inline bool UpdateOption(const LogicOption& option) {
    option_ = option;
    return true;
  }

  bool TaskAvailable();

  bool AddTaskData(const amr_msgs::task_request::ConstPtr& task_req);

  bool MergeTaskData(const amr_msgs::task_request::ConstPtr& task_req,
                     bool add_new_task);

  void Moveforward();

  void MoveToOperation();

  void MoveToEnd();

  bool MoveTo(int32_t siteId);

  bool RecoverTask();

  bool PauseTask();

  bool IsPauseTask() const { return pause_task_; }

  bool CancleTask();

  bool GetTaskCancle() const { return task_cancle_; }

  bool FinishTask();

  void FreshStep();

  // 根据任务串提前规划出需调整速度的位置
  AdjustSpeedPose FindAdjustSpeedPose(const std::vector<Step>::iterator& iter,
                                      const std::shared_ptr<Task> task);

  HighPrecisionPose FindHighPrecisionPose(
      const std::vector<Step>::iterator& iter,
      const std::shared_ptr<Task> task);

  double ComuteRemainDistance(const std::vector<Step>::iterator& iter,
                              const std::shared_ptr<Task> task);

  // 搜索下一个动作任务
  OperationStep FindNextOperationStep();

  // 搜索上一个指定动作任务
  OperationStep FindLastTargetOperationStep(
      const AgvTaskOperationType& target_operation);

  NextBsplineStepPair FindNextBsplineStep();

  DirectionType NextStepDirection() const;

  DirectionType NextNextStepDirection() const;

  DirectionType NextBsplineDirection();

  bool IsNextStepTerminal() const;

  bool IsNextStepFinal() const;

  bool IsNextStepRotation() const;

  bool IsNextLineNeedRotation() const;

  bool IsCurrentStepTerminal() const;

  bool IsCurrentStepFinal() const;

  bool IsNextNextStepFinal() const;

  bool IsNextNextStepOperation() const;

  bool IsNextNextStepCharge() const;

  bool IsNextNextStepCurve() const;

  bool IsNextStepStartPoint() const;

  bool IsNextNextStepRotation() const;

  bool IsAppended() const;

  bool IsDispatchTaskEndpointVaild() const {
    return task_endpoint_.end_ponit_vaild;
  }

  AdjustSpeedPose IsNextStepAdjustSpeed(const Step& cur_step,
                                        const Step& next_step,
                                        const Step& next_next_step) const;

  HighPrecisionPose IsNextStepHighPrecision(const Step& cur_step,
                                            const Step& next_step,
                                            const Step& next_next_step) const;

  OperationStep IsNextStepOperationType(const Step& cur_step,
                                        const Step& next_step,
                                        const Step& next_next_step) const;

  bool IsVelocityReserve() const;

  inline void SetAgvState(const AgvStateType& state) { state_ = state; }

  inline void SetAppended(const bool& state) { appended_ = state; }

 private:
  bool AddSteps(std::shared_ptr<Task> task, bool append,
                std::vector<Step>::iterator* cur,
                const amr_msgs::task_request::ConstPtr& task_req);

  DirectionType ComputeStepDirection(const Step& current_step,
                                     const Step& next_step) const;

  bool StartTask();

  LogicOption option_;

  std::vector<Step>::iterator iter_;
  std::shared_ptr<Task> task_ptr_;
  Step current_step_;
  Step next_step_;
  Step next_next_step_;
  Step need_stop_step_;
  Step final_step_;

  AgvStateType state_;

  Cmd feedback_cmd_;
  bool appended_;
  bool pause_task_;
  bool task_cancle_;
  bool is_doing_task_;
  std::string agv_id_;
  std::string current_order_id_;
  std::string current_task_id_;
  DispatchTaskEndpoint task_endpoint_;
  int current_task_type_;
  int current_sequence_num_;
};

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_TASK_MANAGER_H_
